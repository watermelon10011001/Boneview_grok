import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Repeat, c as Layers, d as ChevronUp, f as ChevronDown, i as RotateCcw, l as Image, m as Bone, n as Upload, o as Play, p as Camera, s as Pause, t as X, u as FileJson } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as require_lib } from "../_libs/jszip+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-cAlF-qmE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium transition-colors duration-200 disabled:pointer-events-none disabled:opacity-40 select-none active:opacity-90", {
	variants: {
		variant: {
			primary: "bg-steel text-steel-ink hover:bg-ink",
			secondary: "bg-panel text-ink border border-line hover:bg-raised",
			ghost: "text-mute hover:text-ink hover:bg-panel",
			danger: "bg-danger/15 text-danger hover:bg-danger/25"
		},
		size: {
			md: "h-11 px-4 rounded-md text-sm",
			sm: "h-9 px-3 rounded-sm text-xs",
			icon: "size-11 rounded-md",
			"icon-sm": "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var ACCEPT_ALL = ".json,.skel,.atlas,.png,.jpg,.jpeg,.webp,.txt,.bytes,.zip,image/png,image/jpeg,application/json,application/zip,application/octet-stream";
function FilePicker({ onFiles, directory = false, variant = "secondary", size = "md", accept = ACCEPT_ALL, children, className, label, multiple = true }) {
	const ref = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref,
		type: "file",
		className: "sr-only",
		multiple: directory ? false : multiple,
		accept: directory ? void 0 : accept,
		"aria-label": label,
		...directory ? { webkitdirectory: "" } : {},
		onChange: (event) => {
			const list = Array.from(event.target.files ?? []);
			event.target.value = "";
			if (list.length) onFiles(list);
		}
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		variant,
		size,
		className,
		onClick: () => ref.current?.click(),
		children
	})] });
}
var DEMOS = [{
	id: "spineboy",
	title: "Spineboy",
	blurb: "官方 4.2 示例，含 walk / run / jump / shoot",
	version: "4.2",
	files: [
		{
			name: "spineboy-pro.json",
			url: "/demos/spineboy/spineboy-pro.json"
		},
		{
			name: "spineboy-pma.atlas",
			url: "/demos/spineboy/spineboy-pma.atlas"
		},
		{
			name: "spineboy-pma.png",
			url: "/demos/spineboy/spineboy-pma.png"
		}
	]
}];
async function fetchDemoFiles(demo) {
	const files = [];
	for (const item of demo.files) {
		const res = await fetch(item.url);
		if (!res.ok) throw new Error(`演示资源加载失败：${item.name}`);
		const blob = await res.blob();
		files.push(new File([blob], item.name, { type: blob.type || guessType(item.name) }));
	}
	return files;
}
function guessType(name) {
	if (name.endsWith(".json")) return "application/json";
	if (name.endsWith(".png")) return "image/png";
	if (name.endsWith(".atlas") || name.endsWith(".txt")) return "text/plain";
	return "application/octet-stream";
}
var PIECES = [
	{
		key: "skeleton",
		icon: FileJson,
		label: "骨骼",
		hint: ".skel / .json",
		accept: ".json,.skel,.bytes,application/json,application/octet-stream"
	},
	{
		key: "atlas",
		icon: Layers,
		label: "图集",
		hint: ".atlas",
		accept: ".atlas,.txt,text/plain"
	},
	{
		key: "texture",
		icon: Image,
		label: "贴图",
		hint: ".png",
		accept: "image/png,image/jpeg,.png,.jpg,.jpeg,.webp"
	}
];
function DropZone({ onFiles, onDemo, onRestore, onClearDraft, loading, error, dragging, pieces, hasLastPack }) {
	const skeletonName = pieces?.skeleton?.name;
	const atlasName = pieces?.atlas?.name;
	const textureName = pieces?.textures[0]?.name;
	const filled = {
		skeleton: Boolean(skeletonName),
		atlas: Boolean(atlasName),
		texture: Boolean(textureName)
	};
	const labels = {
		skeleton: skeletonName ?? "点此选择",
		atlas: atlasName ?? "点此选择",
		texture: textureName ?? (pieces?.missingTextures[0] ? `缺 ${pieces.missingTextures[0]}` : "点此选择")
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col items-center justify-center overflow-y-auto px-5 py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("w-full max-w-lg rounded-xl bg-raised p-5 shadow-border sm:p-7", dragging && "bg-panel"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-faint uppercase",
					children: "三件套"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-balance text-2xl font-semibold tracking-tight text-ink sm:text-3xl",
					children: "导入 Spine 导出文件"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-md text-pretty text-sm leading-normal text-mute",
					children: "手机上可以点格子分三次选齐骨骼、图集和贴图；也能一次多选，或导入 zip。"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 grid grid-cols-3 gap-2",
					children: PIECES.map((piece) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilePicker, {
						onFiles,
						accept: piece.accept,
						variant: "ghost",
						multiple: false,
						label: `选择${piece.label}`,
						className: cn("h-auto w-full flex-col rounded-lg bg-panel px-2 py-4 text-center hover:bg-canvas", filled[piece.key] && "text-ink"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(piece.icon, {
								className: "size-5 text-steel",
								strokeWidth: 1.75
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium text-ink",
								children: piece.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-full truncate font-mono text-xs text-faint",
								children: labels[piece.key]
							})
						]
					}) }, piece.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-2 sm:flex-row",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePicker, {
							onFiles,
							variant: "primary",
							className: "flex-1",
							label: "一次多选文件",
							children: "一次多选"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePicker, {
							onFiles,
							accept: ".zip,application/zip",
							variant: "secondary",
							className: "flex-1",
							multiple: false,
							label: "导入 zip",
							children: "导入 zip"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePicker, {
							onFiles,
							directory: true,
							variant: "secondary",
							className: "hidden flex-1 md:inline-flex",
							label: "选择文件夹",
							children: "选择文件夹"
						})
					]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-md bg-danger/12 px-3 py-2 text-sm leading-normal text-danger",
					children: error
				}) : null,
				loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-mute",
					children: "正在读取文件…"
				}) : null,
				hasLastPack && onRestore ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					className: "mt-3 w-full",
					onClick: onRestore,
					disabled: loading,
					children: "打开上次导入"
				}) : null,
				pieces && onClearDraft ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					className: "mt-1 w-full text-mute",
					onClick: onClearDraft,
					disabled: loading,
					children: "清除已选文件"
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 w-full max-w-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium tracking-wide text-faint uppercase",
				children: "演示"
			}), DEMOS.map((demo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "secondary",
				className: "h-auto w-full justify-between py-3",
				onClick: () => onDemo(demo.id),
				disabled: loading,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex flex-col items-start gap-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: demo.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-normal text-mute",
						children: demo.blurb
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-faint",
					children: demo.version
				})]
			}, demo.id))]
		})]
	});
}
var SPINE_MAJORS = [
	"4.3",
	"4.2",
	"4.1",
	"4.0"
];
var DEFAULT_DEBUG = {
	bones: false,
	regions: false,
	meshes: false,
	bounds: false,
	paths: false,
	clipping: false,
	points: false,
	hulls: false
};
var TEXTURE_RE = /\.(png|jpe?g|webp|avif)$/i;
var ATLAS_RE = /(\.atlas(\.txt)?$)|(\.txt$)/i;
var JSON_RE = /\.json$/i;
var SKEL_RE = /\.(skel|bytes)$/i;
var ZIP_RE = /\.zip$/i;
var IGNORE_RE = /\.(meta|DS_Store|md|txt)$/i;
function basename(path) {
	return path.replace(/\\/g, "/").split("/").pop() ?? path;
}
function lower(name) {
	return basename(name).toLowerCase();
}
async function expandIncomingFiles(files) {
	const out = [];
	for (const file of files) if (ZIP_RE.test(file.name)) {
		const zip = await import_lib.default.loadAsync(file);
		const entries = Object.values(zip.files);
		for (const entry of entries) {
			if (entry.dir) continue;
			const name = basename(entry.name);
			if (!name || name.startsWith(".")) continue;
			if (IGNORE_RE.test(name) && !ATLAS_RE.test(name)) continue;
			const blob = await entry.async("blob");
			out.push(new File([blob], name, { type: blob.type }));
		}
	} else out.push(file);
	return out;
}
function looksLikeAtlas(text) {
	return /^\s*pma\s*:/im.test(text) || /^\s*size\s*:/im.test(text) || /^\s*filter\s*:/im.test(text);
}
function looksLikeSpineJson(text) {
	try {
		const data = JSON.parse(text);
		return Boolean(data && (data.skeleton || data.bones));
	} catch {
		return false;
	}
}
function parseAtlasPageEntries(atlasText) {
	const pages = [];
	const seen = /* @__PURE__ */ new Set();
	for (const raw of atlasText.split(/\r?\n/)) {
		const line = raw.trim();
		if (!line || line.includes(":")) continue;
		if (!TEXTURE_RE.test(line)) continue;
		const base = basename(line);
		const key = base.toLowerCase();
		if (seen.has(key)) continue;
		seen.add(key);
		pages.push({
			raw: line,
			base
		});
	}
	return pages;
}
function parseAtlasPages(atlasText) {
	return parseAtlasPageEntries(atlasText).map((page) => page.base);
}
function atlasHasPma(atlasText) {
	const m = atlasText.match(/^\s*pma\s*:\s*(true|false)/im);
	if (m) return m[1].toLowerCase() === "true";
	if (/-pma\b/i.test(atlasText)) return true;
	return null;
}
function applyAtlasPma(atlasText, pma) {
	if (/^\s*pma\s*:/im.test(atlasText)) return atlasText.replace(/^\s*pma\s*:\s*(true|false)/gim, (line) => line.replace(/true|false/i, String(pma)));
	const lines = atlasText.split(/\r?\n/);
	const idx = lines.findIndex((line) => {
		const t = line.trim();
		return Boolean(t) && !t.includes(":") && TEXTURE_RE.test(t);
	});
	if (idx >= 0) {
		lines.splice(idx + 1, 0, `\tpma: ${pma}`);
		return lines.join("\n");
	}
	return `pma: ${pma}\n${atlasText}`;
}
function flattenAtlasPages(atlasText) {
	return atlasText.split(/\r?\n/).map((line) => {
		const t = line.trim();
		if (!t || t.includes(":")) return line;
		if (TEXTURE_RE.test(t)) return basename(t);
		return line;
	}).join("\n");
}
async function sniffSkeletonKind(file) {
	const head = new Uint8Array(await file.slice(0, 16).arrayBuffer());
	if (head[0] === 123 || head[0] === 239) return "json";
	if (JSON_RE.test(file.name)) return "json";
	return "binary";
}
async function detectSpineVersion(file, kind) {
	if (kind === "json") try {
		const data = JSON.parse(await file.text());
		return data.skeleton?.spine ?? data.spine ?? null;
	} catch {
		return null;
	}
	const bytes = new Uint8Array(await file.slice(0, 192).arrayBuffer());
	const match = new TextDecoder("latin1").decode(bytes).match(/(3\.[6-8]|4\.[0-3])\.\d+/);
	return match ? match[0] : null;
}
function majorFromVersion(raw) {
	if (!raw) return null;
	const m = raw.match(/^(\d+)\.(\d+)/);
	if (!m) return null;
	const major = `${m[1]}.${m[2]}`;
	if (SPINE_MAJORS.includes(major)) return major;
	return null;
}
async function peekSkeletonMeta(file, kind) {
	const versionRaw = await detectSpineVersion(file, kind);
	if (kind !== "json") return {
		versionRaw,
		animations: [],
		skins: [],
		boneCount: 0,
		slotCount: 0
	};
	try {
		const data = JSON.parse(await file.text());
		return {
			versionRaw,
			animations: data.animations ? Object.keys(data.animations).map((name) => ({
				name,
				duration: 0
			})) : [],
			skins: Array.isArray(data.skins) ? data.skins.map((s) => s.name).filter((name) => Boolean(name)) : data.skins ? Object.keys(data.skins) : [],
			boneCount: Array.isArray(data.bones) ? data.bones.length : 0,
			slotCount: Array.isArray(data.slots) ? data.slots.length : 0
		};
	} catch {
		return {
			versionRaw,
			animations: [],
			skins: [],
			boneCount: 0,
			slotCount: 0
		};
	}
}
function virtualSkeletonName(original, kind) {
	const base = basename(original).replace(/\.(json|skel|bytes)$/i, "");
	return kind === "json" ? `${base}.json` : `${base}.skel`;
}
function virtualAtlasName(original) {
	const name = basename(original);
	if (/\.atlas(\.txt)?$/i.test(name)) return name.replace(/\.txt$/i, "");
	return `${name.replace(/\.(txt|atlas)$/i, "")}.atlas`;
}
async function collectPieces(files) {
	const unique = /* @__PURE__ */ new Map();
	for (const file of files) unique.set(basename(file.name), file);
	const list = [...unique.values()];
	const jsonCandidates = [];
	const skelCandidates = [];
	const atlasCandidates = [];
	const textureCandidates = [];
	const extra = [];
	for (const file of list) {
		const name = file.name;
		if (TEXTURE_RE.test(name)) {
			textureCandidates.push(file);
			continue;
		}
		if (JSON_RE.test(name)) {
			jsonCandidates.push(file);
			continue;
		}
		if (SKEL_RE.test(name)) {
			skelCandidates.push(file);
			continue;
		}
		if (/\.atlas(\.txt)?$/i.test(name)) {
			atlasCandidates.push(file);
			continue;
		}
		extra.push(name);
	}
	if (!atlasCandidates.length) for (const file of list) {
		if (!/\.txt$/i.test(file.name)) continue;
		if (looksLikeAtlas(await file.text())) atlasCandidates.push(file);
	}
	let skeletonFile;
	let skeletonKind;
	for (const file of jsonCandidates) if (looksLikeSpineJson(await file.text())) {
		skeletonFile = file;
		skeletonKind = "json";
		break;
	}
	if (!skeletonFile && skelCandidates.length) {
		skeletonFile = skelCandidates[0];
		skeletonKind = await sniffSkeletonKind(skeletonFile);
	}
	const atlasFile = atlasCandidates[0];
	let missingTextures = [];
	const textures = [];
	if (atlasFile) {
		const atlasText = await atlasFile.text();
		const wantedPages = looksLikeAtlas(atlasText) ? parseAtlasPages(atlasText) : [];
		const textureMap = new Map(textureCandidates.map((f) => [lower(f.name), f]));
		const pages = wantedPages.length ? wantedPages : textureCandidates.map((f) => basename(f.name));
		for (const page of pages) {
			const hit = textureMap.get(page.toLowerCase());
			if (hit) textures.push({
				name: page,
				file: hit
			});
			else missingTextures.push(page);
		}
		if (!pages.length) missingTextures = ["png"];
	} else if (textureCandidates.length) for (const file of textureCandidates) textures.push({
		name: basename(file.name),
		file
	});
	return {
		skeleton: skeletonFile ? {
			name: basename(skeletonFile.name),
			file: skeletonFile
		} : void 0,
		atlas: atlasFile ? {
			name: basename(atlasFile.name),
			file: atlasFile
		} : void 0,
		textures,
		missingTextures,
		skeletonKind,
		extraFiles: extra
	};
}
function kitMissing(pieces) {
	const missing = [];
	if (!pieces.skeleton) missing.push("骨骼 .skel / .json");
	if (!pieces.atlas) missing.push("图集 .atlas");
	if (!pieces.textures.length || pieces.missingTextures.length) missing.push(pieces.missingTextures.length ? `贴图 ${pieces.missingTextures.join("、")}` : "贴图 .png");
	return missing;
}
async function matchSpinePack(files) {
	if (!files.length) throw new Error("没有读到文件。请选择 .skel/.json、.atlas 和 .png。");
	const pieces = await collectPieces(files);
	const missing = kitMissing(pieces);
	if (missing.length) throw new Error(`还差：${missing.join("，")}。可以分三次选，也可以一次多选或导入 zip。`);
	const atlasFile = pieces.atlas.file;
	if (!looksLikeAtlas(await atlasFile.text())) throw new Error(`无法解析图集：${basename(atlasFile.name)}。请确认这是 Spine 导出的 .atlas。`);
	return {
		skeleton: pieces.skeleton,
		atlas: pieces.atlas,
		textures: pieces.textures,
		missingTextures: pieces.missingTextures,
		skeletonKind: pieces.skeletonKind ?? "json",
		extraFiles: pieces.extraFiles
	};
}
function fileToDataURI(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result));
		reader.onerror = () => reject(reader.error ?? /* @__PURE__ */ new Error("读取文件失败"));
		reader.readAsDataURL(file);
	});
}
async function packToRawDataURIs(pack, pma) {
	const skeletonName = virtualSkeletonName(pack.skeleton.name, pack.skeletonKind);
	const atlasName = virtualAtlasName(pack.atlas.name);
	let atlasText = await pack.atlas.file.text();
	atlasText = flattenAtlasPages(atlasText);
	if (typeof pma === "boolean") atlasText = applyAtlasPma(atlasText, pma);
	const atlasBlob = new Blob([atlasText], { type: "text/plain" });
	const rawDataURIs = {
		[skeletonName]: await fileToDataURI(pack.skeleton.file),
		[atlasName]: await fileToDataURI(atlasBlob),
		[pack.skeleton.name]: await fileToDataURI(pack.skeleton.file),
		[pack.atlas.name]: await fileToDataURI(atlasBlob)
	};
	for (const tex of pack.textures) {
		const uri = await fileToDataURI(tex.file);
		rawDataURIs[tex.name] = uri;
		rawDataURIs[basename(tex.file.name)] = uri;
	}
	return {
		skeletonName,
		atlasName,
		rawDataURIs
	};
}
function formatBytes(n) {
	if (n < 1024) return `${n} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
	return `${(n / 1048576).toFixed(2)} MB`;
}
function mergeFiles(existing, incoming) {
	const map = /* @__PURE__ */ new Map();
	for (const file of existing) map.set(basename(file.name), file);
	for (const file of incoming) map.set(basename(file.name), file);
	return [...map.values()];
}
var runtimeCache = /* @__PURE__ */ new Map();
async function loadPlayerCtor(major) {
	const hit = runtimeCache.get(major);
	if (hit) return hit;
	let ctor;
	switch (major) {
		case "4.3":
			ctor = (await import("../_libs/@esotericsoftware/spine-player+[...].mjs").then((n) => n.t)).SpinePlayer;
			break;
		case "4.2":
			ctor = (await import("../_libs/spine-player-42.mjs").then((n) => n.t)).SpinePlayer;
			break;
		case "4.1":
			ctor = (await import("../_libs/spine-player-41.mjs").then((n) => n.t)).SpinePlayer;
			break;
		case "4.0":
			ctor = (await import("../_libs/spine-player-40.mjs").then((n) => n.t)).SpinePlayer;
			break;
		default: throw new Error(`不支持的运行时 ${major}`);
	}
	runtimeCache.set(major, ctor);
	return ctor;
}
async function bootSpinePlayer(parent, options) {
	const { skeletonName, atlasName, rawDataURIs } = await packToRawDataURIs(options.pack, options.pma);
	const Ctor = await loadPlayerCtor(options.major);
	const isJson = options.pack.skeletonKind === "json";
	const config = {
		skeleton: skeletonName,
		skelUrl: isJson ? void 0 : skeletonName,
		jsonUrl: isJson ? skeletonName : void 0,
		binaryUrl: isJson ? void 0 : skeletonName,
		atlas: atlasName,
		atlasUrl: atlasName,
		rawDataURIs,
		showControls: false,
		showLoading: true,
		alpha: options.alpha,
		preserveDrawingBuffer: true,
		backgroundColor: options.alpha ? "00000000" : options.backgroundHex.replace("#", ""),
		premultipliedAlpha: options.pma,
		defaultMix: options.mix,
		mipmaps: true,
		interactive: false,
		controlBones: [],
		debug: options.debug,
		viewport: {
			padLeft: "10%",
			padRight: "10%",
			padTop: "8%",
			padBottom: "10%"
		},
		success: options.success,
		error: (_player, msg) => options.error(msg),
		frame: options.frame
	};
	if (options.animation) config.animation = options.animation;
	if (options.skin) config.skin = options.skin;
	return new Ctor(parent, config);
}
function asRecordList(value) {
	if (!value) return [];
	if (Array.isArray(value)) return value.filter((item) => item && typeof item === "object");
	if (typeof value === "object") {
		const rec = value;
		if (typeof rec.toArray === "function") return asRecordList(rec.toArray());
		if (typeof rec.length === "number") try {
			return Array.from(value).filter((item) => item && typeof item === "object");
		} catch {}
		return Object.values(value).filter((item) => item && typeof item === "object");
	}
	return [];
}
function pickDefaultAnimation(anims) {
	if (!anims.length) return null;
	for (const name of [
		"idle",
		"walk",
		"run",
		"animation",
		"stand"
	]) {
		const hit = anims.find((a) => a.name.toLowerCase() === name);
		if (hit) return hit.name;
	}
	return anims.find((a) => a.duration > 0)?.name ?? anims[0]?.name ?? null;
}
function pickDefaultSkin(skins) {
	if (!skins.length) return null;
	for (const name of ["default", "normal"]) {
		const hit = skins.find((s) => s.toLowerCase() === name);
		if (hit) return hit;
	}
	return skins[0] ?? null;
}
function readPlayerMeta(player) {
	const skel = player.skeleton;
	const state = player.animationState;
	const data = skel?.data ?? state?.data?.skeletonData;
	return {
		animations: asRecordList(data?.animations).map((a) => ({
			name: typeof a.name === "string" ? a.name : "",
			duration: typeof a.duration === "number" ? a.duration : 0
		})).filter((a) => a.name),
		skins: asRecordList(data?.skins).map((s) => typeof s.name === "string" ? s.name : "").filter(Boolean),
		boneCount: asRecordList(data?.bones).length,
		slotCount: asRecordList(data?.slots).length
	};
}
function setPlayerSkin(player, name) {
	const skel = player.skeleton;
	if (!skel) return;
	if (typeof skel.setSkinByName === "function") skel.setSkinByName(name);
	else if (typeof skel.setSkin === "function") {
		const skin = skel.data?.findSkin?.(name);
		if (skin) skel.setSkin(skin);
		else skel.setSkin(name);
	}
	skel.setToSetupPose?.();
	skel.setupPose?.();
	skel.setSlotsToSetupPose?.();
	skel.setupPoseSlots?.();
}
function getTrack(player) {
	return player.animationState?.getCurrent?.(0) ?? null;
}
function seekPlayer(player, time) {
	const track = getTrack(player);
	if (!track) return;
	const duration = track.animation?.duration ?? 0;
	const next = duration > 0 ? Math.min(Math.max(time, 0), duration) : Math.max(time, 0);
	track.trackTime = next;
	track.animationLast = next;
	const state = player.animationState;
	if (state?.apply && player.skeleton) state.apply(player.skeleton);
}
function setPlayerLoop(player, animation, loop) {
	const time = getTrack(player)?.trackTime ?? 0;
	player.setAnimation(animation, loop);
	const next = getTrack(player);
	if (next) {
		next.trackTime = time;
		next.loop = loop;
	}
}
function setDefaultMix(player, mix) {
	const state = player.animationState;
	if (state?.data) state.data.defaultMix = mix;
}
function captureFrame(player) {
	const canvas = player.canvas;
	if (!canvas) return null;
	try {
		return canvas.toDataURL("image/png");
	} catch {
		return null;
	}
}
var useStudio = create((set) => ({
	pack: null,
	draftFiles: [],
	loadError: null,
	loading: false,
	runtimeMode: "auto",
	meta: null,
	ready: false,
	currentAnimation: null,
	currentSkin: null,
	playing: true,
	looping: true,
	speed: 1,
	mix: .2,
	pma: true,
	bg: "checker",
	debug: { ...DEFAULT_DEBUG },
	inspectorTab: "anims",
	inspectorPeek: false,
	setPack: (pack) => set({
		pack,
		ready: false,
		loadError: null,
		currentAnimation: null,
		currentSkin: null,
		playing: true,
		looping: true,
		...pack ? { draftFiles: [] } : {}
	}),
	setDraftFiles: (draftFiles) => set({ draftFiles }),
	setLoadError: (loadError) => set({
		loadError,
		loading: false
	}),
	setLoading: (loading) => set({ loading }),
	setRuntimeMode: (runtimeMode) => set({ runtimeMode }),
	setMeta: (meta) => set({ meta }),
	patchMeta: (patch) => set((s) => ({ meta: s.meta ? {
		...s.meta,
		...patch
	} : patch })),
	setReady: (ready) => set({ ready }),
	setCurrentAnimation: (currentAnimation) => set({ currentAnimation }),
	setCurrentSkin: (currentSkin) => set({ currentSkin }),
	setPlaying: (playing) => set({ playing }),
	setLooping: (looping) => set({ looping }),
	setSpeed: (speed) => set({ speed }),
	setMix: (mix) => set({ mix }),
	setPma: (pma) => set({ pma }),
	setBg: (bg) => set({ bg }),
	setDebug: (patch) => set((s) => ({ debug: {
		...s.debug,
		...patch
	} })),
	setInspectorTab: (inspectorTab) => set({
		inspectorTab,
		inspectorPeek: false
	}),
	setInspectorPeek: (inspectorPeek) => set({ inspectorPeek }),
	resetSession: () => set({
		pack: null,
		draftFiles: [],
		loadError: null,
		loading: false,
		meta: null,
		ready: false,
		currentAnimation: null,
		currentSkin: null,
		playing: true,
		looping: true,
		inspectorTab: "anims",
		inspectorPeek: false
	})
}));
var BG_HEX = {
	checker: "00000000",
	black: "0c0c0e",
	gray: "3f3f46",
	white: "f4f4f5"
};
var playerApiRef = { current: null };
var timelineRef = {
	slider: null,
	elapsed: null,
	duration: null,
	fps: null
};
function bindTimelineEls(els) {
	Object.assign(timelineRef, els);
}
function getPlayerApi() {
	return playerApiRef.current;
}
function PlayerStage({ major }) {
	const hostRef = (0, import_react.useRef)(null);
	const layerRef = (0, import_react.useRef)(null);
	const playerRef = (0, import_react.useRef)(null);
	const debugRef = (0, import_react.useRef)(useStudio.getState().debug);
	const xfRef = (0, import_react.useRef)({
		x: 0,
		y: 0,
		s: 1
	});
	const pack = useStudio((s) => s.pack);
	const pma = useStudio((s) => s.pma);
	const mix = useStudio((s) => s.mix);
	const bg = useStudio((s) => s.bg);
	const debug = useStudio((s) => s.debug);
	const speed = useStudio((s) => s.speed);
	(0, import_react.useEffect)(() => {
		Object.assign(debugRef.current, debug);
	}, [debug]);
	(0, import_react.useEffect)(() => {
		const player = playerRef.current;
		if (!player) return;
		player.speed = speed;
	}, [speed]);
	(0, import_react.useEffect)(() => {
		const player = playerRef.current;
		if (!player) return;
		setDefaultMix(player, mix);
	}, [mix]);
	(0, import_react.useEffect)(() => {
		const player = playerRef.current;
		if (!player) return;
		const hex = bg === "checker" ? "00000000" : BG_HEX[bg];
		player.bg.setFromString(hex);
	}, [bg]);
	(0, import_react.useEffect)(() => {
		const layer = layerRef.current;
		if (!layer) return;
		const xf = xfRef.current;
		const pointers = /* @__PURE__ */ new Map();
		let lastTap = 0;
		let pinch = null;
		const apply = () => {
			layer.style.transform = `translate(${xf.x}px, ${xf.y}px) scale(${xf.s})`;
		};
		const reset = () => {
			xf.x = 0;
			xf.y = 0;
			xf.s = 1;
			apply();
		};
		const onPointerDown = (event) => {
			if (event.pointerType === "mouse" && event.button !== 0) return;
			layer.setPointerCapture(event.pointerId);
			pointers.set(event.pointerId, {
				x: event.clientX,
				y: event.clientY
			});
			if (pointers.size === 2) {
				const pts = [...pointers.values()];
				const first = pts[0];
				const second = pts[1];
				if (!first || !second) return;
				pinch = {
					dist: Math.hypot(second.x - first.x, second.y - first.y),
					s: xf.s,
					x: xf.x,
					y: xf.y
				};
			}
			const now = Date.now();
			if (pointers.size === 1 && now - lastTap < 280) {
				reset();
				lastTap = 0;
			} else if (pointers.size === 1) lastTap = now;
		};
		const onPointerMove = (event) => {
			const prev = pointers.get(event.pointerId);
			if (!prev) return;
			const next = {
				x: event.clientX,
				y: event.clientY
			};
			pointers.set(event.pointerId, next);
			if (pointers.size === 2 && pinch) {
				const pts = [...pointers.values()];
				const first = pts[0];
				const second = pts[1];
				if (!first || !second) return;
				const dist = Math.hypot(second.x - first.x, second.y - first.y);
				if (pinch.dist > 0) {
					xf.s = Math.min(5, Math.max(.4, pinch.s * (dist / pinch.dist)));
					apply();
				}
				return;
			}
			if (pointers.size === 1 && xf.s > 1.02) {
				xf.x += next.x - prev.x;
				xf.y += next.y - prev.y;
				apply();
			}
		};
		const onPointerUp = (event) => {
			pointers.delete(event.pointerId);
			if (pointers.size < 2) pinch = null;
		};
		const onWheel = (event) => {
			event.preventDefault();
			const delta = event.deltaY > 0 ? .92 : 1.08;
			xf.s = Math.min(5, Math.max(.4, xf.s * delta));
			if (xf.s <= 1.02) {
				xf.s = 1;
				xf.x = 0;
				xf.y = 0;
			}
			apply();
		};
		layer.addEventListener("pointerdown", onPointerDown);
		layer.addEventListener("pointermove", onPointerMove);
		layer.addEventListener("pointerup", onPointerUp);
		layer.addEventListener("pointercancel", onPointerUp);
		layer.addEventListener("wheel", onWheel, { passive: false });
		reset();
		return () => {
			layer.removeEventListener("pointerdown", onPointerDown);
			layer.removeEventListener("pointermove", onPointerMove);
			layer.removeEventListener("pointerup", onPointerUp);
			layer.removeEventListener("pointercancel", onPointerUp);
			layer.removeEventListener("wheel", onWheel);
		};
	}, [pack]);
	(0, import_react.useEffect)(() => {
		if (!pack || !hostRef.current) return;
		const host = hostRef.current;
		host.innerHTML = "";
		let cancelled = false;
		const store = useStudio.getState();
		store.setReady(false);
		store.setLoadError(null);
		const debugState = { ...store.debug };
		debugRef.current = debugState;
		bootSpinePlayer(host, {
			pack,
			major,
			mix: store.mix,
			pma: store.pma,
			debug: debugState,
			backgroundHex: BG_HEX[store.bg],
			alpha: store.bg === "checker",
			animation: store.currentAnimation ?? void 0,
			skin: store.currentSkin ?? void 0,
			error: (message) => {
				if (!cancelled) useStudio.getState().setLoadError(message);
			},
			frame: (player) => {
				const track = getTrack(player);
				const duration = track?.animation?.duration ?? 0;
				const time = track?.trackTime ?? 0;
				const wrapped = duration > 0 ? time % duration : time;
				if (timelineRef.slider && document.activeElement !== timelineRef.slider) {
					timelineRef.slider.max = String(duration || 0);
					timelineRef.slider.value = String(wrapped);
				}
				if (timelineRef.elapsed) timelineRef.elapsed.textContent = formatClock(wrapped);
				if (timelineRef.duration) timelineRef.duration.textContent = formatClock(duration);
				if (timelineRef.fps && player.time?.delta) {
					const fps = player.time.delta > 0 ? Math.round(1 / player.time.delta) : 0;
					timelineRef.fps.textContent = `${fps} fps`;
				}
			},
			success: (player) => {
				if (cancelled) {
					player.dispose();
					return;
				}
				playerRef.current = player;
				const runtime = readPlayerMeta(player);
				const prev = useStudio.getState().meta;
				const animations = runtime.animations.length ? runtime.animations : prev?.animations ?? [];
				const skins = runtime.skins.length ? runtime.skins : prev?.skins ?? [];
				const firstAnim = pickDefaultAnimation(animations);
				const firstSkin = pickDefaultSkin(skins);
				const current = useStudio.getState();
				const anim = current.currentAnimation && animations.some((a) => a.name === current.currentAnimation) ? current.currentAnimation : firstAnim;
				const skin = current.currentSkin && skins.includes(current.currentSkin) ? current.currentSkin : firstSkin;
				if (anim) player.setAnimation(anim, current.looping);
				if (skin) setPlayerSkin(player, skin);
				player.speed = current.speed;
				if (current.playing) player.play();
				else player.pause();
				playerApiRef.current = {
					play: () => player.play(),
					pause: () => player.pause(),
					setAnimation: (name, loop) => {
						player.setAnimation(name, loop);
					},
					setSkin: (name) => setPlayerSkin(player, name),
					setSpeed: (value) => {
						player.speed = value;
					},
					setLoop: (loop) => {
						const name = useStudio.getState().currentAnimation;
						if (name) setPlayerLoop(player, name, loop);
					},
					seek: (time) => seekPlayer(player, time),
					setMix: (value) => setDefaultMix(player, value),
					capture: () => captureFrame(player)
				};
				useStudio.getState().patchMeta({
					animations,
					skins,
					boneCount: runtime.boneCount || prev?.boneCount || 0,
					slotCount: runtime.slotCount || prev?.slotCount || 0
				});
				useStudio.getState().setCurrentAnimation(anim);
				useStudio.getState().setCurrentSkin(skin);
				useStudio.getState().setReady(true);
			}
		}).then((player) => {
			if (cancelled) player.dispose();
		}).catch((err) => {
			if (!cancelled) useStudio.getState().setLoadError(err instanceof Error ? err.message : "播放器启动失败");
		});
		return () => {
			cancelled = true;
			playerApiRef.current = null;
			try {
				playerRef.current?.dispose();
			} catch {}
			playerRef.current = null;
			host.innerHTML = "";
		};
	}, [
		pack,
		major,
		pma
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative h-full min-h-0 w-full overflow-hidden touch-none", bg === "checker" && "stage-checker", bg === "black" && "bg-canvas", bg === "gray" && "bg-ash", bg === "white" && "bg-paper"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: layerRef,
			className: "absolute inset-0 origin-center will-change-transform",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: hostRef,
				className: "absolute inset-0"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute top-3 left-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-sm bg-canvas/70 px-2 py-1 font-mono text-xs text-mute tabular-nums",
				ref: (node) => {
					timelineRef.fps = node;
				},
				children: "fps"
			})
		})]
	});
}
function formatClock(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) seconds = 0;
	const m = Math.floor(seconds / 60);
	const s = seconds - m * 60;
	return `${String(m).padStart(2, "0")}:${s.toFixed(2).padStart(5, "0")}`;
}
var TABS = [
	{
		id: "anims",
		label: "动画"
	},
	{
		id: "skins",
		label: "皮肤"
	},
	{
		id: "stage",
		label: "舞台"
	},
	{
		id: "debug",
		label: "调试"
	}
];
var BACKGROUNDS = [
	{
		id: "checker",
		label: "棋盘"
	},
	{
		id: "black",
		label: "黑"
	},
	{
		id: "gray",
		label: "灰"
	},
	{
		id: "white",
		label: "白"
	}
];
var DEBUG_ITEMS = [
	{
		key: "bones",
		label: "骨骼"
	},
	{
		key: "regions",
		label: "区域"
	},
	{
		key: "meshes",
		label: "网格"
	},
	{
		key: "hulls",
		label: "轮廓"
	},
	{
		key: "bounds",
		label: "包围盒"
	},
	{
		key: "paths",
		label: "路径"
	},
	{
		key: "clipping",
		label: "裁剪"
	},
	{
		key: "points",
		label: "点"
	}
];
function Inspector() {
	const tab = useStudio((s) => s.inspectorTab);
	const peek = useStudio((s) => s.inspectorPeek);
	const meta = useStudio((s) => s.meta);
	const pack = useStudio((s) => s.pack);
	const currentAnimation = useStudio((s) => s.currentAnimation);
	const currentSkin = useStudio((s) => s.currentSkin);
	const looping = useStudio((s) => s.looping);
	const mix = useStudio((s) => s.mix);
	const pma = useStudio((s) => s.pma);
	const bg = useStudio((s) => s.bg);
	const debug = useStudio((s) => s.debug);
	const [query, setQuery] = (0, import_react.useState)("");
	const animations = (meta?.animations ?? []).filter((a) => a.name.toLowerCase().includes(query.trim().toLowerCase()));
	const skins = (meta?.skins ?? []).filter((s) => s.toLowerCase().includes(query.trim().toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex h-full min-h-0 flex-col bg-raised",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex shrink-0 items-center gap-1 overflow-x-auto px-2 pt-1 md:pt-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "flex h-11 min-w-11 items-center justify-center rounded-sm text-mute md:hidden",
				"aria-label": peek ? "展开面板" : "收起面板",
				onClick: () => useStudio.getState().setInspectorPeek(!peek),
				children: peek ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
			}), TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => useStudio.getState().setInspectorTab(item.id),
				className: cn("h-11 min-w-11 rounded-sm px-3 text-sm transition-colors duration-200 md:h-9", tab === item.id ? "bg-panel text-ink" : "text-mute hover:text-ink"),
				children: item.label
			}, item.id))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("min-h-0 flex-1 overflow-y-auto p-3", peek && "hidden md:block"),
			children: [
				tab === "anims" || tab === "skins" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: tab === "anims" ? "筛选动画" : "筛选皮肤",
					className: "mb-3 h-11 w-full rounded-sm bg-canvas px-3 text-sm text-ink outline-none placeholder:text-faint md:h-10"
				}) : null,
				tab === "anims" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-1",
					children: animations.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "px-2 py-6 text-center text-sm text-mute",
						children: "没有动画"
					}) : animations.map((anim) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							useStudio.getState().setCurrentAnimation(anim.name);
							useStudio.getState().setPlaying(true);
							getPlayerApi()?.setAnimation(anim.name, looping);
							getPlayerApi()?.play();
						},
						className: cn("flex h-11 w-full items-center justify-between rounded-sm px-3 text-left text-sm", currentAnimation === anim.name ? "bg-panel text-ink" : "text-mute hover:bg-panel/70 hover:text-ink"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: anim.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 font-mono text-xs text-faint tabular-nums",
							children: anim.duration > 0 ? `${anim.duration.toFixed(2)}s` : ""
						})]
					}) }, anim.name))
				}) : null,
				tab === "skins" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-1",
					children: skins.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "px-2 py-6 text-center text-sm text-mute",
						children: "没有皮肤"
					}) : skins.map((skin) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							useStudio.getState().setCurrentSkin(skin);
							getPlayerApi()?.setSkin(skin);
						},
						className: cn("flex h-11 w-full items-center rounded-sm px-3 text-left text-sm", currentSkin === skin ? "bg-panel text-ink" : "text-mute hover:bg-panel/70 hover:text-ink"),
						children: skin
					}) }, skin))
				}) : null,
				tab === "stage" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mb-2 text-xs font-medium tracking-wide text-faint uppercase",
							children: "背景"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-4 gap-1",
							children: BACKGROUNDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => useStudio.getState().setBg(item.id),
								className: cn("h-11 rounded-sm text-xs", bg === item.id ? "bg-panel text-ink" : "text-mute hover:bg-panel/70 hover:text-ink"),
								children: item.label
							}, item.id))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "mb-2 text-xs font-medium tracking-wide text-faint uppercase",
							children: [
								"混合 ",
								mix.toFixed(2),
								"s"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "range",
							min: 0,
							max: 1,
							step: .05,
							value: mix,
							onChange: (event) => {
								const value = Number(event.currentTarget.value);
								useStudio.getState().setMix(value);
								getPlayerApi()?.setMix(value);
							},
							className: "scrub",
							"aria-label": "动画混合时间"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm text-ink",
								children: "预乘 Alpha"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-mute",
								children: "贴图发黑或发白时切换"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								variant: pma ? "primary" : "secondary",
								onClick: () => useStudio.getState().setPma(!pma),
								children: pma ? "PMA 开" : "PMA 关"
							})]
						}),
						pack ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-md bg-panel p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mb-2 text-xs font-medium tracking-wide text-faint uppercase",
									children: "文件"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "space-y-1 font-mono text-xs text-mute",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											"骨骼 ",
											pack.skeleton.name,
											" · ",
											formatBytes(pack.skeleton.file.size)
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											"图集 ",
											pack.atlas.name,
											" · ",
											formatBytes(pack.atlas.file.size)
										] }),
										pack.textures.map((tex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											"贴图 ",
											tex.name,
											" · ",
											formatBytes(tex.file.size)
										] }, tex.name))
									]
								}),
								meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 font-mono text-xs text-faint",
									children: [
										meta.versionRaw ?? "未知版本",
										" · ",
										meta.boneCount,
										" bones · ",
										meta.slotCount,
										" slots"
									]
								}) : null,
								pack.missingTextures.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs text-danger",
									children: ["缺少贴图：", pack.missingTextures.join("、")]
								}) : null
							]
						}) : null
					]
				}) : null,
				tab === "debug" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-2 gap-1",
					children: DEBUG_ITEMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => useStudio.getState().setDebug({ [item.key]: !debug[item.key] }),
						className: cn("flex h-11 w-full items-center justify-center rounded-sm text-sm", debug[item.key] ? "bg-panel text-ink" : "text-mute hover:bg-panel/70 hover:text-ink"),
						children: item.label
					}) }, item.key))
				}) : null
			]
		})]
	});
}
var SPEEDS = [
	.25,
	.5,
	1,
	1.5,
	2
];
function Transport() {
	const playing = useStudio((s) => s.playing);
	const looping = useStudio((s) => s.looping);
	const speed = useStudio((s) => s.speed);
	const ready = useStudio((s) => s.ready);
	const currentAnimation = useStudio((s) => s.currentAnimation);
	const pack = useStudio((s) => s.pack);
	function togglePlay() {
		const api = getPlayerApi();
		if (!api) return;
		if (playing) {
			api.pause();
			useStudio.getState().setPlaying(false);
		} else {
			api.play();
			useStudio.getState().setPlaying(true);
		}
	}
	function restart() {
		const api = getPlayerApi();
		if (!api || !currentAnimation) return;
		api.setAnimation(currentAnimation, looping);
		api.play();
		useStudio.getState().setPlaying(true);
	}
	function toggleLoop() {
		const next = !looping;
		useStudio.getState().setLooping(next);
		getPlayerApi()?.setLoop(next);
	}
	async function snapshot() {
		const dataUrl = getPlayerApi()?.capture();
		if (!dataUrl) return;
		const name = `${pack?.skeleton.name.replace(/\.(json|skel|bytes)$/i, "") ?? "spine"}-${currentAnimation ?? "frame"}.png`;
		try {
			const blob = await (await fetch(dataUrl)).blob();
			const file = new File([blob], name, { type: "image/png" });
			const nav = navigator;
			if (nav.share && nav.canShare?.({ files: [file] })) {
				await nav.share({
					files: [file],
					title: name
				});
				return;
			}
		} catch {}
		const link = document.createElement("a");
		link.href = dataUrl;
		link.download = name;
		link.click();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "safe-transport flex flex-col gap-2 bg-raised px-3 py-2.5 sm:flex-row sm:items-center sm:gap-4 sm:px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon-sm",
						onClick: togglePlay,
						disabled: !ready,
						"aria-label": playing ? "暂停" : "播放",
						children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 ml-px" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon-sm",
						onClick: restart,
						disabled: !ready,
						"aria-label": "重播",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon-sm",
						onClick: toggleLoop,
						disabled: !ready,
						"aria-label": "循环",
						className: cn(looping && "bg-panel text-ink"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon-sm",
						onClick: () => void snapshot(),
						disabled: !ready,
						"aria-label": "截图",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-14 shrink-0 font-mono text-xs text-mute tabular-nums",
						ref: (node) => bindTimelineEls({ elapsed: node }),
						children: "00:00.00"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						className: "scrub min-w-0 flex-1",
						min: 0,
						max: 1,
						step: .001,
						defaultValue: 0,
						disabled: !ready,
						"aria-label": "时间轴",
						ref: (node) => bindTimelineEls({ slider: node }),
						onPointerDown: () => getPlayerApi()?.pause(),
						onChange: (event) => {
							const t = Number(event.currentTarget.value);
							getPlayerApi()?.seek(t);
							useStudio.getState().setPlaying(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-14 shrink-0 text-right font-mono text-xs text-mute tabular-nums",
						ref: (node) => bindTimelineEls({ duration: node }),
						children: "00:00.00"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center gap-1 overflow-x-auto",
				children: SPEEDS.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: !ready,
					onClick: () => {
						useStudio.getState().setSpeed(value);
						getPlayerApi()?.setSpeed(value);
					},
					className: cn("h-8 rounded-sm px-2 font-mono text-xs text-mute transition-colors duration-200", value === speed ? "bg-panel text-ink" : "hover:text-ink"),
					children: [value, "x"]
				}, value))
			})
		]
	});
}
var DB_NAME = "boneview";
var STORE = "kv";
var LAST_KEY = "last-pack";
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("IndexedDB 打开失败"));
	});
}
async function saveLastPack(files) {
	if (typeof indexedDB === "undefined" || !files.length) return;
	const stored = {
		savedAt: Date.now(),
		files: await Promise.all(files.map(async (file) => ({
			name: file.name,
			type: file.type,
			buffer: await file.arrayBuffer()
		})))
	};
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(stored, LAST_KEY);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
async function loadLastPack() {
	if (typeof indexedDB === "undefined") return null;
	try {
		const db = await openDb();
		const stored = await new Promise((resolve, reject) => {
			const req = db.transaction(STORE, "readonly").objectStore(STORE).get(LAST_KEY);
			req.onsuccess = () => resolve(req.result);
			req.onerror = () => reject(req.error);
		});
		if (!stored?.files?.length) return null;
		return stored.files.map((item) => new File([item.buffer], item.name, { type: item.type }));
	} catch {
		return null;
	}
}
function Studio() {
	const pack = useStudio((s) => s.pack);
	const draftFiles = useStudio((s) => s.draftFiles);
	const loading = useStudio((s) => s.loading);
	const loadError = useStudio((s) => s.loadError);
	const runtimeMode = useStudio((s) => s.runtimeMode);
	const meta = useStudio((s) => s.meta);
	const ready = useStudio((s) => s.ready);
	const inspectorPeek = useStudio((s) => s.inspectorPeek);
	const [dragging, setDragging] = (0, import_react.useState)(false);
	const [hasLastPack, setHasLastPack] = (0, import_react.useState)(false);
	const [pieces, setPieces] = (0, import_react.useState)(null);
	const resolvedMajor = (0, import_react.useMemo)(() => {
		if (runtimeMode !== "auto") return runtimeMode;
		return meta?.major ?? null;
	}, [runtimeMode, meta?.major]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		loadLastPack().then((files) => {
			if (!cancelled) setHasLastPack(Boolean(files?.length));
		});
		return () => {
			cancelled = true;
		};
	}, [pack]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		if (!draftFiles.length) {
			setPieces(null);
			return;
		}
		collectPieces(draftFiles).then((next) => {
			if (!cancelled) setPieces(next);
		});
		return () => {
			cancelled = true;
		};
	}, [draftFiles]);
	const commitPack = (0, import_react.useCallback)(async (next) => {
		const store = useStudio.getState();
		const versionRaw = await peekSkeletonMeta(next.skeleton.file, next.skeletonKind);
		const major = majorFromVersion(versionRaw.versionRaw);
		const pma = atlasHasPma(await next.atlas.file.text());
		const firstAnim = pickDefaultAnimation(versionRaw.animations);
		const firstSkin = pickDefaultSkin(versionRaw.skins);
		store.setPack(next);
		store.setPma(pma ?? true);
		store.setMeta({
			versionRaw: versionRaw.versionRaw,
			major,
			animations: versionRaw.animations,
			skins: versionRaw.skins,
			boneCount: versionRaw.boneCount,
			slotCount: versionRaw.slotCount,
			pma: pma ?? true
		});
		store.setCurrentAnimation(firstAnim);
		store.setCurrentSkin(firstSkin);
		store.setInspectorPeek(false);
		saveLastPack([
			next.skeleton.file,
			next.atlas.file,
			...next.textures.map((t) => t.file)
		]);
		setHasLastPack(true);
		if (!major && store.runtimeMode === "auto") {
			if (versionRaw.versionRaw && versionRaw.versionRaw.startsWith("3.")) store.setLoadError(`这份导出是 Spine ${versionRaw.versionRaw}。当前支持 4.0–4.3，请用 4.x 重新导出，或在顶栏手动选择运行时试播。`);
		}
	}, []);
	const ingest = (0, import_react.useCallback)(async (incoming, replace = false) => {
		const store = useStudio.getState();
		store.setLoading(true);
		store.setLoadError(null);
		try {
			const expanded = await expandIncomingFiles(incoming);
			const combined = replace || store.pack ? expanded : mergeFiles(store.draftFiles, expanded);
			if (kitMissing(await collectPieces(combined)).length) {
				store.setDraftFiles(combined);
				store.setLoadError(null);
				return;
			}
			const next = await matchSpinePack(combined);
			await commitPack(next);
		} catch (err) {
			store.setLoadError(err instanceof Error ? err.message : "导入失败");
		} finally {
			store.setLoading(false);
		}
	}, [commitPack]);
	const loadDemo = (0, import_react.useCallback)(async (id) => {
		const demo = DEMOS.find((item) => item.id === id);
		if (!demo) return;
		useStudio.getState().setLoading(true);
		try {
			const files = await fetchDemoFiles(demo);
			await ingest(files, true);
		} catch (err) {
			useStudio.getState().setLoadError(err instanceof Error ? err.message : "演示加载失败");
		}
	}, [ingest]);
	const restoreLast = (0, import_react.useCallback)(async () => {
		const files = await loadLastPack();
		if (!files?.length) {
			setHasLastPack(false);
			return;
		}
		await ingest(files, true);
	}, [ingest]);
	function onDragOver(event) {
		event.preventDefault();
		event.dataTransfer.dropEffect = "copy";
		setDragging(true);
	}
	function onDragLeave(event) {
		if (event.currentTarget.contains(event.relatedTarget)) return;
		setDragging(false);
	}
	function onDrop(event) {
		event.preventDefault();
		setDragging(false);
		const files = Array.from(event.dataTransfer.files);
		if (files.length) ingest(files);
	}
	const unsupported = Boolean(pack && runtimeMode === "auto" && !meta?.major);
	const playMajor = resolvedMajor ?? "4.2";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-dvh flex-col bg-canvas text-ink",
		onDragOver,
		onDragLeave,
		onDrop,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "safe-header flex shrink-0 items-center gap-3 px-3 py-2 sm:px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-9 items-center justify-center rounded-sm bg-panel",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bone, {
							className: "size-4 text-steel",
							strokeWidth: 1.75
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-semibold tracking-tight",
							children: "Boneview"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs text-mute",
							children: pack ? pack.skeleton.name : "Spine 三件套预览"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only sm:not-sr-only sm:text-xs sm:text-faint",
								children: "运行时"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: runtimeMode,
								onChange: (event) => {
									const value = event.currentTarget.value;
									useStudio.getState().setRuntimeMode(value);
								},
								className: "h-9 max-w-28 rounded-sm bg-panel px-2 font-mono text-xs text-ink outline-none sm:max-w-none",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: "auto",
									children: ["自动", meta?.versionRaw ? ` (${meta.versionRaw})` : ""]
								}), SPINE_MAJORS.map((major) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: major,
									children: major
								}, major))]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilePicker, {
							onFiles: (files) => void ingest(files, true),
							variant: "secondary",
							size: "sm",
							label: "导入文件",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "导入"
							})]
						}),
						pack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon-sm",
							"aria-label": "关闭预览",
							onClick: () => useStudio.getState().resetSession(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						}) : null
					]
				})]
			}),
			dragging ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 z-20 flex items-center justify-center bg-canvas/70",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-lg bg-raised px-5 py-3 text-sm text-ink shadow-border",
					children: "松开以导入三件套"
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("flex min-h-0 flex-1 flex-col", pack && "md:flex-row"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-0 min-w-0 flex-1 flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "relative min-h-0 flex-1",
						children: [!pack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropZone, {
							onFiles: (files) => void ingest(files),
							onDemo: (id) => void loadDemo(id),
							onRestore: () => void restoreLast(),
							onClearDraft: () => {
								useStudio.getState().setDraftFiles([]);
								useStudio.getState().setLoadError(null);
							},
							loading,
							error: loadError,
							dragging,
							pieces,
							hasLastPack
						}) : unsupported && !ready && runtimeMode === "auto" && meta?.versionRaw?.startsWith("3.") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-full flex-col items-center justify-center gap-3 px-6 text-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-sm text-sm leading-normal text-mute",
								children: loadError
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerStage, { major: playMajor }), pack && loadError && ready === false && resolvedMajor ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-x-4 bottom-4 rounded-md bg-canvas/90 px-3 py-2 text-sm text-danger",
							children: loadError
						}) : null]
					}), pack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transport, {}) : null]
				}), pack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("inspector-dock", inspectorPeek && "is-peek"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inspector, {})
				}) : null]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
