import { n as __exportAll } from "../../_runtime.mjs";
import { $a as Physics, $o as PhysicsConstraintDampingTimeline, $s as Vector2, Aa as ToRotate, Ao as AnimationStateData, As as isConstraintTimeline, Ba as SlotData, Bo as ConstraintTimeline1, Bs as TextureAtlasPage, Ca as FromRotate, Co as PointAttachment, Cs as SlotCurveTimeline, Da as FromX, Do as AssetCache, Ds as TranslateXTimeline, Ea as FromShearY, Eo as BoundingBoxAttachment, Es as TranslateTimeline, Fa as ToY, Fo as AlphaTimeline, Fs as RegionAttachment, Ga as Slider$1, Go as DrawOrderTimeline, Gs as TextureWrap, Ha as SkinEntry, Ho as CurveTimeline1, Hs as Texture, Ia as TransformConstraintData, Io as Animation, Is as MeshAttachment, Ja as PhysicsConstraint, Jo as InheritTimeline, Js as MathUtils, Ka as SliderPose, Ko as EventTimeline, Ks as Color, La as TransformConstraint, Lo as AttachmentTimeline, Ls as Attachment, Ma as ToScaleY, Mo as EventQueue, Ms as Sequence, Na as ToShearY, No as EventType, Ns as SequenceMode, Oa as FromY, Oo as AssetManagerBase, Os as TranslateYTimeline, Pa as ToX, Po as TrackEntry, Ps as SequenceModeValues, Qa as PhysicsConstraintPose, Qo as PathConstraintSpacingTimeline, Qs as Utils, Ra as TransformConstraintPose, Ro as BoneTimeline1, Rs as VertexAttachment, Sa as FromProperty, So as AtlasAttachmentLoader, Ss as SliderTimeline, Ta as FromScaleY, To as ClippingAttachment, Ts as TransformConstraintTimeline, Ua as SkeletonData, Uo as DeformTimeline, Us as TextureFilter, Va as Skin, Vo as CurveTimeline, Vs as TextureAtlasRegion, Wa as SliderData, Wo as DrawOrderFolderTimeline, Ws as TextureRegion, Xa as Slot, Xo as PathConstraintMixTimeline, Xs as StringSet, Ya as Skeleton, Yo as MixFrom, Ys as Pool, Za as SlotPose, Zo as PathConstraintPositionTimeline, Zs as TimeKeeper, _a as SkeletonClipping, _o as Posed, _s as SequenceTimeline, ao as PathConstraintPose, as as PhysicsConstraintStrengthTimeline, ba as BinaryInput, bo as Inherit, bs as ShearYTimeline, co as IkConstraintPose, cs as Property, do as ConstraintData, ds as RGBATimeline, eo as PathConstraint, es as PhysicsConstraintGravityTimeline, fo as ScaleYMode, fs as RGBTimeline, ga as SkeletonJson, go as PosedActive, gs as ScaleYTimeline, ho as Bone, hs as ScaleXTimeline, io as SpacingMode, is as PhysicsConstraintResetTimeline, ja as ToScaleX, jo as AnimationState, js as isSlotTimeline, ka as ToProperty, ko as Downloader, ks as isBoneTimeline, lo as EventData, ls as RGB2Timeline, mo as Constraint, ms as ScaleTimeline, no as PositionMode, ns as PhysicsConstraintMassTimeline, oo as IkConstraintData, os as PhysicsConstraintTimeline, po as DrawOrder, ps as RotateTimeline, qa as PhysicsConstraintData, qo as IkConstraintTimeline, qs as Interpolation, ro as RotateMode, rs as PhysicsConstraintMixTimeline, so as IkConstraint, ss as PhysicsConstraintWindTimeline, to as PathConstraintData, ts as PhysicsConstraintInertiaTimeline, uo as Event, us as RGBA2Timeline, va as Triangulator, vo as BonePose, vs as ShearTimeline, wa as FromScaleX, wo as PathAttachment, ws as Timeline, xa as SkeletonBinary, xo as PosedData, xs as SliderMixTimeline, ya as SkeletonBounds, yo as BoneData, ys as ShearXTimeline, za as BlendMode, zo as BoneTimeline2, zs as TextureAtlas } from "../esotericsoftware__spine-core.mjs";
//#region node_modules/@esotericsoftware/spine-webgl/dist/WebGL.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var ManagedWebGLRenderingContext = class {
	canvas;
	gl;
	restorables = [];
	constructor(canvasOrContext, contextConfig = { alpha: true }) {
		if (!(canvasOrContext instanceof WebGLRenderingContext || typeof WebGL2RenderingContext !== "undefined" && canvasOrContext instanceof WebGL2RenderingContext)) {
			const canvas = canvasOrContext;
			this.gl = canvas.getContext("webgl2", contextConfig) || canvas.getContext("webgl", contextConfig);
			this.canvas = canvas;
			canvas.addEventListener("webglcontextlost", this.contextLostHandler);
			canvas.addEventListener("webglcontextrestored", this.contextRestoredHandler);
		} else {
			this.gl = canvasOrContext;
			this.canvas = this.gl.canvas;
		}
	}
	contextLostHandler = (e) => {
		if (e) e.preventDefault();
	};
	contextRestoredHandler = () => {
		this.restore();
	};
	restore() {
		for (let i = 0, n = this.restorables.length; i < n; i++) this.restorables[i].restore();
	}
	dispose() {
		this.canvas.removeEventListener("webglcontextlost", this.contextLostHandler);
		this.canvas.removeEventListener("webglcontextrestored", this.contextRestoredHandler);
	}
	addRestorable(restorable) {
		this.restorables.push(restorable);
	}
	removeRestorable(restorable) {
		const index = this.restorables.indexOf(restorable);
		if (index > -1) this.restorables.splice(index, 1);
	}
};
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/GLTexture.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var GLTexture = class GLTexture extends Texture {
	context;
	texture = null;
	boundUnit = 0;
	pma;
	useMipMaps;
	constructor(context, image, pma, useMipMaps = false) {
		super(image);
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		this.pma = pma;
		this.useMipMaps = useMipMaps;
		this.restore();
		this.context.addRestorable(this);
	}
	setFilters(minFilter, magFilter) {
		const gl = this.context.gl;
		this.bind();
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, minFilter);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, GLTexture.validateMagFilter(magFilter));
		this.useMipMaps = GLTexture.usesMipMaps(minFilter);
		if (this.useMipMaps) gl.generateMipmap(gl.TEXTURE_2D);
	}
	static validateMagFilter(magFilter) {
		switch (magFilter) {
			case TextureFilter.MipMapLinearLinear:
			case TextureFilter.MipMapLinearNearest:
			case TextureFilter.MipMapNearestLinear:
			case TextureFilter.MipMapNearestNearest: return TextureFilter.Linear;
			default: return magFilter;
		}
	}
	static usesMipMaps(filter) {
		switch (filter) {
			case TextureFilter.MipMapLinearLinear:
			case TextureFilter.MipMapLinearNearest:
			case TextureFilter.MipMapNearestLinear:
			case TextureFilter.MipMapNearestNearest: return true;
			default: return false;
		}
	}
	setWraps(uWrap, vWrap) {
		const gl = this.context.gl;
		this.bind();
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, uWrap);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, vWrap);
	}
	update(useMipMaps) {
		const gl = this.context.gl;
		if (!this.texture) this.texture = this.context.gl.createTexture();
		this.bind();
		const previousUnpackPmaValue = gl.getParameter(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL);
		gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !this.pma);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this._image);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, useMipMaps ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
		if (useMipMaps) gl.generateMipmap(gl.TEXTURE_2D);
		gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, previousUnpackPmaValue);
	}
	restore() {
		this.texture = null;
		this.update(this.useMipMaps);
	}
	bind(unit = 0) {
		const gl = this.context.gl;
		this.boundUnit = unit;
		gl.activeTexture(gl.TEXTURE0 + unit);
		gl.bindTexture(gl.TEXTURE_2D, this.texture);
	}
	unbind() {
		const gl = this.context.gl;
		gl.activeTexture(gl.TEXTURE0 + this.boundUnit);
		gl.bindTexture(gl.TEXTURE_2D, null);
	}
	dispose() {
		this.context.removeRestorable(this);
		this.context.gl.deleteTexture(this.texture);
	}
};
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/AssetManager.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var AssetManager = class extends AssetManagerBase {
	constructor(context, pathPrefix = "", downloader = new Downloader()) {
		super((image, pma = false) => new GLTexture(context, image, pma), pathPrefix, downloader);
	}
};
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/Vector3.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Vector3 = class {
	x = 0;
	y = 0;
	z = 0;
	constructor(x = 0, y = 0, z = 0) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	setFrom(v) {
		this.x = v.x;
		this.y = v.y;
		this.z = v.z;
		return this;
	}
	set(x, y, z) {
		this.x = x;
		this.y = y;
		this.z = z;
		return this;
	}
	add(v) {
		this.x += v.x;
		this.y += v.y;
		this.z += v.z;
		return this;
	}
	sub(v) {
		this.x -= v.x;
		this.y -= v.y;
		this.z -= v.z;
		return this;
	}
	scale(s) {
		this.x *= s;
		this.y *= s;
		this.z *= s;
		return this;
	}
	normalize() {
		let len = this.length();
		if (len === 0) return this;
		len = 1 / len;
		this.x *= len;
		this.y *= len;
		this.z *= len;
		return this;
	}
	cross(v) {
		return this.set(this.y * v.z - this.z * v.y, this.z * v.x - this.x * v.z, this.x * v.y - this.y * v.x);
	}
	multiply(matrix) {
		const l_mat = matrix.values;
		return this.set(this.x * l_mat[0] + this.y * l_mat[4] + this.z * l_mat[8] + l_mat[12], this.x * l_mat[1] + this.y * l_mat[5] + this.z * l_mat[9] + l_mat[13], this.x * l_mat[2] + this.y * l_mat[6] + this.z * l_mat[10] + l_mat[14]);
	}
	project(matrix) {
		const l_mat = matrix.values;
		const l_w = 1 / (this.x * l_mat[3] + this.y * l_mat[7] + this.z * l_mat[11] + l_mat[15]);
		return this.set((this.x * l_mat[0] + this.y * l_mat[4] + this.z * l_mat[8] + l_mat[12]) * l_w, (this.x * l_mat[1] + this.y * l_mat[5] + this.z * l_mat[9] + l_mat[13]) * l_w, (this.x * l_mat[2] + this.y * l_mat[6] + this.z * l_mat[10] + l_mat[14]) * l_w);
	}
	dot(v) {
		return this.x * v.x + this.y * v.y + this.z * v.z;
	}
	length() {
		return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
	}
	distance(v) {
		const a = v.x - this.x;
		const b = v.y - this.y;
		const c = v.z - this.z;
		return Math.sqrt(a * a + b * b + c * c);
	}
};
var Matrix4 = class Matrix4 {
	temp = /* @__PURE__ */ new Float32Array(16);
	values = /* @__PURE__ */ new Float32Array(16);
	static xAxis = new Vector3();
	static yAxis = new Vector3();
	static zAxis = new Vector3();
	static tmpMatrix = new Matrix4();
	constructor() {
		const v = this.values;
		v[0] = 1;
		v[5] = 1;
		v[10] = 1;
		v[15] = 1;
	}
	set(values) {
		this.values.set(values);
		return this;
	}
	transpose() {
		const t = this.temp;
		const v = this.values;
		t[0] = v[0];
		t[4] = v[1];
		t[8] = v[2];
		t[12] = v[3];
		t[1] = v[4];
		t[5] = v[5];
		t[9] = v[6];
		t[13] = v[7];
		t[2] = v[8];
		t[6] = v[9];
		t[10] = v[10];
		t[14] = v[11];
		t[3] = v[12];
		t[7] = v[13];
		t[11] = v[14];
		t[15] = v[15];
		return this.set(t);
	}
	identity() {
		const v = this.values;
		v[0] = 1;
		v[4] = 0;
		v[8] = 0;
		v[12] = 0;
		v[1] = 0;
		v[5] = 1;
		v[9] = 0;
		v[13] = 0;
		v[2] = 0;
		v[6] = 0;
		v[10] = 1;
		v[14] = 0;
		v[3] = 0;
		v[7] = 0;
		v[11] = 0;
		v[15] = 1;
		return this;
	}
	invert() {
		const v = this.values;
		const t = this.temp;
		const l_det = v[3] * v[6] * v[9] * v[12] - v[2] * v[7] * v[9] * v[12] - v[3] * v[5] * v[10] * v[12] + v[1] * v[7] * v[10] * v[12] + v[2] * v[5] * v[11] * v[12] - v[1] * v[6] * v[11] * v[12] - v[3] * v[6] * v[8] * v[13] + v[2] * v[7] * v[8] * v[13] + v[3] * v[4] * v[10] * v[13] - v[0] * v[7] * v[10] * v[13] - v[2] * v[4] * v[11] * v[13] + v[0] * v[6] * v[11] * v[13] + v[3] * v[5] * v[8] * v[14] - v[1] * v[7] * v[8] * v[14] - v[3] * v[4] * v[9] * v[14] + v[0] * v[7] * v[9] * v[14] + v[1] * v[4] * v[11] * v[14] - v[0] * v[5] * v[11] * v[14] - v[2] * v[5] * v[8] * v[15] + v[1] * v[6] * v[8] * v[15] + v[2] * v[4] * v[9] * v[15] - v[0] * v[6] * v[9] * v[15] - v[1] * v[4] * v[10] * v[15] + v[0] * v[5] * v[10] * v[15];
		if (l_det === 0) throw new Error("non-invertible matrix");
		const inv_det = 1 / l_det;
		t[0] = v[9] * v[14] * v[7] - v[13] * v[10] * v[7] + v[13] * v[6] * v[11] - v[5] * v[14] * v[11] - v[9] * v[6] * v[15] + v[5] * v[10] * v[15];
		t[4] = v[12] * v[10] * v[7] - v[8] * v[14] * v[7] - v[12] * v[6] * v[11] + v[4] * v[14] * v[11] + v[8] * v[6] * v[15] - v[4] * v[10] * v[15];
		t[8] = v[8] * v[13] * v[7] - v[12] * v[9] * v[7] + v[12] * v[5] * v[11] - v[4] * v[13] * v[11] - v[8] * v[5] * v[15] + v[4] * v[9] * v[15];
		t[12] = v[12] * v[9] * v[6] - v[8] * v[13] * v[6] - v[12] * v[5] * v[10] + v[4] * v[13] * v[10] + v[8] * v[5] * v[14] - v[4] * v[9] * v[14];
		t[1] = v[13] * v[10] * v[3] - v[9] * v[14] * v[3] - v[13] * v[2] * v[11] + v[1] * v[14] * v[11] + v[9] * v[2] * v[15] - v[1] * v[10] * v[15];
		t[5] = v[8] * v[14] * v[3] - v[12] * v[10] * v[3] + v[12] * v[2] * v[11] - v[0] * v[14] * v[11] - v[8] * v[2] * v[15] + v[0] * v[10] * v[15];
		t[9] = v[12] * v[9] * v[3] - v[8] * v[13] * v[3] - v[12] * v[1] * v[11] + v[0] * v[13] * v[11] + v[8] * v[1] * v[15] - v[0] * v[9] * v[15];
		t[13] = v[8] * v[13] * v[2] - v[12] * v[9] * v[2] + v[12] * v[1] * v[10] - v[0] * v[13] * v[10] - v[8] * v[1] * v[14] + v[0] * v[9] * v[14];
		t[2] = v[5] * v[14] * v[3] - v[13] * v[6] * v[3] + v[13] * v[2] * v[7] - v[1] * v[14] * v[7] - v[5] * v[2] * v[15] + v[1] * v[6] * v[15];
		t[6] = v[12] * v[6] * v[3] - v[4] * v[14] * v[3] - v[12] * v[2] * v[7] + v[0] * v[14] * v[7] + v[4] * v[2] * v[15] - v[0] * v[6] * v[15];
		t[10] = v[4] * v[13] * v[3] - v[12] * v[5] * v[3] + v[12] * v[1] * v[7] - v[0] * v[13] * v[7] - v[4] * v[1] * v[15] + v[0] * v[5] * v[15];
		t[14] = v[12] * v[5] * v[2] - v[4] * v[13] * v[2] - v[12] * v[1] * v[6] + v[0] * v[13] * v[6] + v[4] * v[1] * v[14] - v[0] * v[5] * v[14];
		t[3] = v[9] * v[6] * v[3] - v[5] * v[10] * v[3] - v[9] * v[2] * v[7] + v[1] * v[10] * v[7] + v[5] * v[2] * v[11] - v[1] * v[6] * v[11];
		t[7] = v[4] * v[10] * v[3] - v[8] * v[6] * v[3] + v[8] * v[2] * v[7] - v[0] * v[10] * v[7] - v[4] * v[2] * v[11] + v[0] * v[6] * v[11];
		t[11] = v[8] * v[5] * v[3] - v[4] * v[9] * v[3] - v[8] * v[1] * v[7] + v[0] * v[9] * v[7] + v[4] * v[1] * v[11] - v[0] * v[5] * v[11];
		t[15] = v[4] * v[9] * v[2] - v[8] * v[5] * v[2] + v[8] * v[1] * v[6] - v[0] * v[9] * v[6] - v[4] * v[1] * v[10] + v[0] * v[5] * v[10];
		v[0] = t[0] * inv_det;
		v[4] = t[4] * inv_det;
		v[8] = t[8] * inv_det;
		v[12] = t[12] * inv_det;
		v[1] = t[1] * inv_det;
		v[5] = t[5] * inv_det;
		v[9] = t[9] * inv_det;
		v[13] = t[13] * inv_det;
		v[2] = t[2] * inv_det;
		v[6] = t[6] * inv_det;
		v[10] = t[10] * inv_det;
		v[14] = t[14] * inv_det;
		v[3] = t[3] * inv_det;
		v[7] = t[7] * inv_det;
		v[11] = t[11] * inv_det;
		v[15] = t[15] * inv_det;
		return this;
	}
	determinant() {
		const v = this.values;
		return v[3] * v[6] * v[9] * v[12] - v[2] * v[7] * v[9] * v[12] - v[3] * v[5] * v[10] * v[12] + v[1] * v[7] * v[10] * v[12] + v[2] * v[5] * v[11] * v[12] - v[1] * v[6] * v[11] * v[12] - v[3] * v[6] * v[8] * v[13] + v[2] * v[7] * v[8] * v[13] + v[3] * v[4] * v[10] * v[13] - v[0] * v[7] * v[10] * v[13] - v[2] * v[4] * v[11] * v[13] + v[0] * v[6] * v[11] * v[13] + v[3] * v[5] * v[8] * v[14] - v[1] * v[7] * v[8] * v[14] - v[3] * v[4] * v[9] * v[14] + v[0] * v[7] * v[9] * v[14] + v[1] * v[4] * v[11] * v[14] - v[0] * v[5] * v[11] * v[14] - v[2] * v[5] * v[8] * v[15] + v[1] * v[6] * v[8] * v[15] + v[2] * v[4] * v[9] * v[15] - v[0] * v[6] * v[9] * v[15] - v[1] * v[4] * v[10] * v[15] + v[0] * v[5] * v[10] * v[15];
	}
	translate(x, y, z) {
		const v = this.values;
		v[12] += x;
		v[13] += y;
		v[14] += z;
		return this;
	}
	copy() {
		return new Matrix4().set(this.values);
	}
	projection(near, far, fovy, aspectRatio) {
		this.identity();
		const l_fd = 1 / Math.tan(fovy * (Math.PI / 180) / 2);
		const l_a1 = (far + near) / (near - far);
		const l_a2 = 2 * far * near / (near - far);
		const v = this.values;
		v[0] = l_fd / aspectRatio;
		v[1] = 0;
		v[2] = 0;
		v[3] = 0;
		v[4] = 0;
		v[5] = l_fd;
		v[6] = 0;
		v[7] = 0;
		v[8] = 0;
		v[9] = 0;
		v[10] = l_a1;
		v[11] = -1;
		v[12] = 0;
		v[13] = 0;
		v[14] = l_a2;
		v[15] = 0;
		return this;
	}
	ortho2d(x, y, width, height) {
		return this.ortho(x, x + width, y, y + height, 0, 1);
	}
	ortho(left, right, bottom, top, near, far) {
		this.identity();
		const x_orth = 2 / (right - left);
		const y_orth = 2 / (top - bottom);
		const z_orth = -2 / (far - near);
		const tx = -(right + left) / (right - left);
		const ty = -(top + bottom) / (top - bottom);
		const tz = -(far + near) / (far - near);
		const v = this.values;
		v[0] = x_orth;
		v[1] = 0;
		v[2] = 0;
		v[3] = 0;
		v[4] = 0;
		v[5] = y_orth;
		v[6] = 0;
		v[7] = 0;
		v[8] = 0;
		v[9] = 0;
		v[10] = z_orth;
		v[11] = 0;
		v[12] = tx;
		v[13] = ty;
		v[14] = tz;
		v[15] = 1;
		return this;
	}
	multiply(matrix) {
		const t = this.temp;
		const v = this.values;
		const m = matrix.values;
		t[0] = v[0] * m[0] + v[4] * m[1] + v[8] * m[2] + v[12] * m[3];
		t[4] = v[0] * m[4] + v[4] * m[5] + v[8] * m[6] + v[12] * m[7];
		t[8] = v[0] * m[8] + v[4] * m[9] + v[8] * m[10] + v[12] * m[11];
		t[12] = v[0] * m[12] + v[4] * m[13] + v[8] * m[14] + v[12] * m[15];
		t[1] = v[1] * m[0] + v[5] * m[1] + v[9] * m[2] + v[13] * m[3];
		t[5] = v[1] * m[4] + v[5] * m[5] + v[9] * m[6] + v[13] * m[7];
		t[9] = v[1] * m[8] + v[5] * m[9] + v[9] * m[10] + v[13] * m[11];
		t[13] = v[1] * m[12] + v[5] * m[13] + v[9] * m[14] + v[13] * m[15];
		t[2] = v[2] * m[0] + v[6] * m[1] + v[10] * m[2] + v[14] * m[3];
		t[6] = v[2] * m[4] + v[6] * m[5] + v[10] * m[6] + v[14] * m[7];
		t[10] = v[2] * m[8] + v[6] * m[9] + v[10] * m[10] + v[14] * m[11];
		t[14] = v[2] * m[12] + v[6] * m[13] + v[10] * m[14] + v[14] * m[15];
		t[3] = v[3] * m[0] + v[7] * m[1] + v[11] * m[2] + v[15] * m[3];
		t[7] = v[3] * m[4] + v[7] * m[5] + v[11] * m[6] + v[15] * m[7];
		t[11] = v[3] * m[8] + v[7] * m[9] + v[11] * m[10] + v[15] * m[11];
		t[15] = v[3] * m[12] + v[7] * m[13] + v[11] * m[14] + v[15] * m[15];
		return this.set(this.temp);
	}
	multiplyLeft(matrix) {
		const t = this.temp;
		const v = this.values;
		const m = matrix.values;
		t[0] = m[0] * v[0] + m[4] * v[1] + m[8] * v[2] + m[12] * v[3];
		t[4] = m[0] * v[4] + m[4] * v[5] + m[8] * v[6] + m[12] * v[7];
		t[8] = m[0] * v[8] + m[4] * v[9] + m[8] * v[10] + m[12] * v[11];
		t[12] = m[0] * v[12] + m[4] * v[13] + m[8] * v[14] + m[12] * v[15];
		t[1] = m[1] * v[0] + m[5] * v[1] + m[9] * v[2] + m[13] * v[3];
		t[5] = m[1] * v[4] + m[5] * v[5] + m[9] * v[6] + m[13] * v[7];
		t[9] = m[1] * v[8] + m[5] * v[9] + m[9] * v[10] + m[13] * v[11];
		t[13] = m[1] * v[12] + m[5] * v[13] + m[9] * v[14] + m[13] * v[15];
		t[2] = m[2] * v[0] + m[6] * v[1] + m[10] * v[2] + m[14] * v[3];
		t[6] = m[2] * v[4] + m[6] * v[5] + m[10] * v[6] + m[14] * v[7];
		t[10] = m[2] * v[8] + m[6] * v[9] + m[10] * v[10] + m[14] * v[11];
		t[14] = m[2] * v[12] + m[6] * v[13] + m[10] * v[14] + m[14] * v[15];
		t[3] = m[3] * v[0] + m[7] * v[1] + m[11] * v[2] + m[15] * v[3];
		t[7] = m[3] * v[4] + m[7] * v[5] + m[11] * v[6] + m[15] * v[7];
		t[11] = m[3] * v[8] + m[7] * v[9] + m[11] * v[10] + m[15] * v[11];
		t[15] = m[3] * v[12] + m[7] * v[13] + m[11] * v[14] + m[15] * v[15];
		return this.set(this.temp);
	}
	lookAt(position, direction, up) {
		const xAxis = Matrix4.xAxis, yAxis = Matrix4.yAxis, zAxis = Matrix4.zAxis;
		zAxis.setFrom(direction).normalize();
		xAxis.setFrom(direction).normalize();
		xAxis.cross(up).normalize();
		yAxis.setFrom(xAxis).cross(zAxis).normalize();
		this.identity();
		const val = this.values;
		val[0] = xAxis.x;
		val[4] = xAxis.y;
		val[8] = xAxis.z;
		val[1] = yAxis.x;
		val[5] = yAxis.y;
		val[9] = yAxis.z;
		val[2] = -zAxis.x;
		val[6] = -zAxis.y;
		val[10] = -zAxis.z;
		Matrix4.tmpMatrix.identity();
		Matrix4.tmpMatrix.values[12] = -position.x;
		Matrix4.tmpMatrix.values[13] = -position.y;
		Matrix4.tmpMatrix.values[14] = -position.z;
		this.multiply(Matrix4.tmpMatrix);
		return this;
	}
};
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/Camera.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var OrthoCamera = class {
	position = new Vector3(0, 0, 0);
	direction = new Vector3(0, 0, -1);
	up = new Vector3(0, 1, 0);
	near = 0;
	far = 100;
	zoom = 1;
	viewportWidth = 0;
	viewportHeight = 0;
	projectionView = new Matrix4();
	inverseProjectionView = new Matrix4();
	projection = new Matrix4();
	view = new Matrix4();
	constructor(viewportWidth, viewportHeight) {
		this.viewportWidth = viewportWidth;
		this.viewportHeight = viewportHeight;
		this.update();
	}
	update() {
		const projection = this.projection;
		const view = this.view;
		const projectionView = this.projectionView;
		const inverseProjectionView = this.inverseProjectionView;
		const zoom = this.zoom, viewportWidth = this.viewportWidth, viewportHeight = this.viewportHeight;
		projection.ortho(zoom * (-viewportWidth / 2), zoom * (viewportWidth / 2), zoom * (-viewportHeight / 2), zoom * (viewportHeight / 2), this.near, this.far);
		view.lookAt(this.position, this.direction, this.up);
		projectionView.set(projection.values);
		projectionView.multiply(view);
		inverseProjectionView.set(projectionView.values).invert();
	}
	screenToWorld(screenCoords, screenWidth, screenHeight) {
		const x = screenCoords.x, y = screenHeight - screenCoords.y - 1;
		screenCoords.x = 2 * x / screenWidth - 1;
		screenCoords.y = 2 * y / screenHeight - 1;
		screenCoords.z = 2 * screenCoords.z - 1;
		screenCoords.project(this.inverseProjectionView);
		return screenCoords;
	}
	worldToScreen(worldCoords, screenWidth, screenHeight) {
		worldCoords.project(this.projectionView);
		worldCoords.x = screenWidth * (worldCoords.x + 1) / 2;
		worldCoords.y = screenHeight * (worldCoords.y + 1) / 2;
		worldCoords.z = (worldCoords.z + 1) / 2;
		return worldCoords;
	}
	setViewport(viewportWidth, viewportHeight) {
		this.viewportWidth = viewportWidth;
		this.viewportHeight = viewportHeight;
	}
};
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/Input.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Input = class {
	element;
	mouseX = 0;
	mouseY = 0;
	buttonDown = false;
	touch0 = null;
	touch1 = null;
	initialPinchDistance = 0;
	listeners = [];
	autoPreventDefault;
	isTouch = false;
	callbacks;
	constructor(element, autoPreventDefault = true) {
		this.element = element;
		this.autoPreventDefault = autoPreventDefault;
		this.callbacks = this.setupCallbacks(element);
	}
	setupCallbacks(element) {
		const mouseDown = (ev) => {
			if (ev instanceof MouseEvent && !this.isTouch) {
				const rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.buttonDown = true;
				this.listeners.map((listener) => {
					if (listener.down) listener.down(this.mouseX, this.mouseY, ev);
				});
			}
		};
		const mouseMove = (ev) => {
			if (ev instanceof MouseEvent && !this.isTouch) {
				const rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.listeners.map((listener) => {
					if (this.buttonDown) {
						if (listener.dragged) listener.dragged(this.mouseX, this.mouseY, ev);
					} else if (listener.moved) listener.moved(this.mouseX, this.mouseY, ev);
				});
			}
		};
		const mouseUp = (ev) => {
			if (ev instanceof MouseEvent && !this.isTouch) {
				const rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.buttonDown = false;
				this.listeners.map((listener) => {
					if (listener.up) listener.up(this.mouseX, this.mouseY, ev);
				});
			}
		};
		const mouseWheel = (ev) => {
			if (this.autoPreventDefault) ev.preventDefault();
			let deltaY = ev.deltaY;
			if (ev.deltaMode === WheelEvent.DOM_DELTA_LINE) deltaY *= 8;
			if (ev.deltaMode === WheelEvent.DOM_DELTA_PAGE) deltaY *= 24;
			this.listeners.map((listener) => {
				if (listener.wheel) listener.wheel(deltaY, ev);
			});
		};
		const touchStart = (ev) => {
			this.isTouch = true;
			if (!this.touch0 || !this.touch1) {
				const nativeTouch = ev.changedTouches.item(0);
				if (!nativeTouch) return;
				const rect = element.getBoundingClientRect();
				const x = nativeTouch.clientX - rect.left;
				const y = nativeTouch.clientY - rect.top;
				const touch = new Touch(nativeTouch.identifier, x, y);
				this.mouseX = x;
				this.mouseY = y;
				this.buttonDown = true;
				if (!this.touch0) {
					this.touch0 = touch;
					this.listeners.map((listener) => {
						if (listener.down) listener.down(touch.x, touch.y, ev);
					});
				} else if (!this.touch1) {
					this.touch1 = touch;
					const dx = this.touch1.x - this.touch0.x;
					const dy = this.touch1.x - this.touch0.x;
					this.initialPinchDistance = Math.sqrt(dx * dx + dy * dy);
					this.listeners.map((listener) => {
						if (listener.zoom) listener.zoom(this.initialPinchDistance, this.initialPinchDistance, ev);
					});
				}
			}
			if (this.autoPreventDefault) ev.preventDefault();
		};
		const touchMove = (ev) => {
			this.isTouch = true;
			if (this.touch0) {
				const touches = ev.changedTouches;
				const rect = element.getBoundingClientRect();
				for (let i = 0; i < touches.length; i++) {
					const nativeTouch = touches[i];
					const x = nativeTouch.clientX - rect.left;
					const y = nativeTouch.clientY - rect.top;
					if (this.touch0.identifier === nativeTouch.identifier) {
						this.touch0.x = this.mouseX = x;
						this.touch0.y = this.mouseY = y;
						this.listeners.map((listener) => {
							if (listener.dragged) listener.dragged(x, y, ev);
						});
					}
					if (this.touch1 && this.touch1.identifier === nativeTouch.identifier) {
						this.touch1.x = this.mouseX = x;
						this.touch1.y = this.mouseY = y;
					}
				}
				if (this.touch0 && this.touch1) {
					const dx = this.touch1.x - this.touch0.x;
					const dy = this.touch1.x - this.touch0.x;
					const distance = Math.sqrt(dx * dx + dy * dy);
					this.listeners.map((listener) => {
						if (listener.zoom) listener.zoom(this.initialPinchDistance, distance, ev);
					});
				}
			}
			if (this.autoPreventDefault) ev.preventDefault();
		};
		const touchEnd = (ev) => {
			this.isTouch = true;
			const touch0 = this.touch0;
			if (touch0) {
				const touches = ev.changedTouches;
				const rect = element.getBoundingClientRect();
				for (let i = 0; i < touches.length; i++) {
					const nativeTouch = touches[i];
					const x = nativeTouch.clientX - rect.left;
					const y = nativeTouch.clientY - rect.top;
					if (touch0.identifier === nativeTouch.identifier) {
						this.touch0 = null;
						this.mouseX = x;
						this.mouseY = y;
						this.listeners.map((listener) => {
							if (listener.up) listener.up(x, y, ev);
						});
						if (!this.touch1) {
							this.buttonDown = false;
							break;
						} else {
							const touch0 = this.touch0 = this.touch1;
							this.touch1 = null;
							this.mouseX = touch0.x;
							this.mouseY = touch0.y;
							this.buttonDown = true;
							this.listeners.map((listener) => {
								if (listener.down) listener.down(touch0.x, touch0.y, ev);
							});
						}
					}
					if (this.touch1?.identifier) this.touch1 = null;
				}
			}
			if (this.autoPreventDefault) ev.preventDefault();
		};
		element.addEventListener("mousedown", mouseDown, true);
		element.addEventListener("mousemove", mouseMove, true);
		element.addEventListener("mouseup", mouseUp, true);
		element.addEventListener("wheel", mouseWheel, true);
		element.addEventListener("touchstart", touchStart, {
			passive: false,
			capture: false
		});
		element.addEventListener("touchmove", touchMove, {
			passive: false,
			capture: false
		});
		element.addEventListener("touchend", touchEnd, {
			passive: false,
			capture: false
		});
		element.addEventListener("touchcancel", touchEnd);
		return {
			mouseDown,
			mouseMove,
			mouseUp,
			mouseWheel,
			touchStart,
			touchMove,
			touchEnd
		};
	}
	dispose() {
		const element = this.element;
		element.removeEventListener("mousedown", this.callbacks.mouseDown, true);
		element.removeEventListener("mousemove", this.callbacks.mouseMove, true);
		element.removeEventListener("mouseup", this.callbacks.mouseUp, true);
		element.removeEventListener("wheel", this.callbacks.mouseWheel, true);
		element.removeEventListener("touchstart", this.callbacks.touchStart, { capture: false });
		element.removeEventListener("touchmove", this.callbacks.touchMove, { capture: false });
		element.removeEventListener("touchend", this.callbacks.touchEnd, { capture: false });
		element.removeEventListener("touchcancel", this.callbacks.touchEnd);
		this.listeners.length = 0;
	}
	addListener(listener) {
		this.listeners.push(listener);
	}
	removeListener(listener) {
		const idx = this.listeners.indexOf(listener);
		if (idx > -1) this.listeners.splice(idx, 1);
	}
};
var Touch = class {
	identifier;
	x;
	y;
	constructor(identifier, x, y) {
		this.identifier = identifier;
		this.x = x;
		this.y = y;
	}
};
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/Shader.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Shader = class Shader {
	vertexShader;
	fragmentShader;
	static MVP_MATRIX = "u_projTrans";
	static POSITION = "a_position";
	static COLOR = "a_color";
	static COLOR2 = "a_color2";
	static TEXCOORDS = "a_texCoords";
	static SAMPLER = "u_texture";
	context;
	vs = null;
	vsSource;
	fs = null;
	fsSource;
	program = null;
	tmp2x2 = /* @__PURE__ */ new Float32Array(4);
	tmp3x3 = /* @__PURE__ */ new Float32Array(9);
	tmp4x4 = /* @__PURE__ */ new Float32Array(16);
	getProgram() {
		return this.program;
	}
	getVertexShader() {
		return this.vertexShader;
	}
	getFragmentShader() {
		return this.fragmentShader;
	}
	getVertexShaderSource() {
		return this.vsSource;
	}
	getFragmentSource() {
		return this.fsSource;
	}
	constructor(context, vertexShader, fragmentShader) {
		this.vertexShader = vertexShader;
		this.fragmentShader = fragmentShader;
		this.vsSource = vertexShader;
		this.fsSource = fragmentShader;
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		this.context.addRestorable(this);
		this.compile();
	}
	compile() {
		const gl = this.context.gl;
		try {
			this.vs = this.compileShader(gl.VERTEX_SHADER, this.vertexShader);
			if (!this.vs) throw new Error("Couldn't compile vertex shader.");
			this.fs = this.compileShader(gl.FRAGMENT_SHADER, this.fragmentShader);
			if (!this.fs) throw new Error("Couldn#t compile fragment shader.");
			this.program = this.compileProgram(this.vs, this.fs);
		} catch (e) {
			this.dispose();
			throw e;
		}
	}
	compileShader(type, source) {
		const gl = this.context.gl;
		const shader = gl.createShader(type);
		if (!shader) throw new Error("Couldn't create shader.");
		gl.shaderSource(shader, source);
		gl.compileShader(shader);
		if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
			const error = `Couldn't compile shader: ${gl.getShaderInfoLog(shader)}`;
			gl.deleteShader(shader);
			if (!gl.isContextLost()) throw new Error(error);
		}
		return shader;
	}
	compileProgram(vs, fs) {
		const gl = this.context.gl;
		const program = gl.createProgram();
		if (!program) throw new Error("Couldn't compile program.");
		gl.attachShader(program, vs);
		gl.attachShader(program, fs);
		gl.linkProgram(program);
		if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
			const error = `Couldn't compile shader program: ${gl.getProgramInfoLog(program)}`;
			gl.deleteProgram(program);
			if (!gl.isContextLost()) throw new Error(error);
		}
		return program;
	}
	restore() {
		this.compile();
	}
	bind() {
		this.context.gl.useProgram(this.program);
	}
	unbind() {
		this.context.gl.useProgram(null);
	}
	setUniformi(uniform, value) {
		this.context.gl.uniform1i(this.getUniformLocation(uniform), value);
	}
	setUniformf(uniform, value) {
		this.context.gl.uniform1f(this.getUniformLocation(uniform), value);
	}
	setUniform2f(uniform, value, value2) {
		this.context.gl.uniform2f(this.getUniformLocation(uniform), value, value2);
	}
	setUniform3f(uniform, value, value2, value3) {
		this.context.gl.uniform3f(this.getUniformLocation(uniform), value, value2, value3);
	}
	setUniform4f(uniform, value, value2, value3, value4) {
		this.context.gl.uniform4f(this.getUniformLocation(uniform), value, value2, value3, value4);
	}
	setUniform2x2f(uniform, value) {
		const gl = this.context.gl;
		this.tmp2x2.set(value);
		gl.uniformMatrix2fv(this.getUniformLocation(uniform), false, this.tmp2x2);
	}
	setUniform3x3f(uniform, value) {
		const gl = this.context.gl;
		this.tmp3x3.set(value);
		gl.uniformMatrix3fv(this.getUniformLocation(uniform), false, this.tmp3x3);
	}
	setUniform4x4f(uniform, value) {
		const gl = this.context.gl;
		this.tmp4x4.set(value);
		gl.uniformMatrix4fv(this.getUniformLocation(uniform), false, this.tmp4x4);
	}
	getUniformLocation(uniform) {
		const gl = this.context.gl;
		if (!this.program) throw new Error("Shader not compiled.");
		const location = gl.getUniformLocation(this.program, uniform);
		if (!location && !gl.isContextLost()) throw new Error(`Couldn't find location for uniform ${uniform}`);
		return location;
	}
	getAttributeLocation(attribute) {
		const gl = this.context.gl;
		if (!this.program) throw new Error("Shader not compiled.");
		const location = gl.getAttribLocation(this.program, attribute);
		if (location === -1 && !gl.isContextLost()) throw new Error(`Couldn't find location for attribute ${attribute}`);
		return location;
	}
	dispose() {
		this.context.removeRestorable(this);
		const gl = this.context.gl;
		if (this.vs) {
			gl.deleteShader(this.vs);
			this.vs = null;
		}
		if (this.fs) {
			gl.deleteShader(this.fs);
			this.fs = null;
		}
		if (this.program) {
			gl.deleteProgram(this.program);
			this.program = null;
		}
	}
	static newColoredTextured(context) {
		const vs = `
attribute vec4 ${Shader.POSITION};
attribute vec4 ${Shader.COLOR};
attribute vec2 ${Shader.TEXCOORDS};
uniform mat4 ${Shader.MVP_MATRIX};
varying vec4 v_color;
varying vec2 v_texCoords;

void main () {
	v_color = ${Shader.COLOR};
	v_texCoords = ${Shader.TEXCOORDS};
	gl_Position = ${Shader.MVP_MATRIX} * ${Shader.POSITION};
}
`;
		return new Shader(context, vs, `
#ifdef GL_ES
	#define LOWP lowp
	precision mediump float;
#else
	#define LOWP
#endif
varying LOWP vec4 v_color;
varying vec2 v_texCoords;
uniform sampler2D u_texture;

void main () {
	gl_FragColor = v_color * texture2D(u_texture, v_texCoords);
}
`);
	}
	static newTwoColoredTextured(context) {
		const vs = `
attribute vec4 ${Shader.POSITION};
attribute vec4 ${Shader.COLOR};
attribute vec4 ${Shader.COLOR2};
attribute vec2 ${Shader.TEXCOORDS};
uniform mat4 ${Shader.MVP_MATRIX};
varying vec4 v_light;
varying vec4 v_dark;
varying vec2 v_texCoords;

void main () {
	v_light = ${Shader.COLOR};
	v_dark = ${Shader.COLOR2};
	v_texCoords = ${Shader.TEXCOORDS};
	gl_Position = ${Shader.MVP_MATRIX} * ${Shader.POSITION};
}
`;
		return new Shader(context, vs, `
#ifdef GL_ES
	#define LOWP lowp
	precision mediump float;
#else
	#define LOWP
#endif
varying LOWP vec4 v_light;
varying LOWP vec4 v_dark;
varying vec2 v_texCoords;
uniform sampler2D u_texture;

void main () {
	vec4 texColor = texture2D(u_texture, v_texCoords);
	gl_FragColor.a = texColor.a * v_light.a;
	gl_FragColor.rgb = ((texColor.a - 1.0) * v_dark.a + 1.0 - texColor.rgb) * v_dark.rgb + texColor.rgb * v_light.rgb;
}
`);
	}
	static newColored(context) {
		const vs = `
attribute vec4 ${Shader.POSITION};
attribute vec4 ${Shader.COLOR};
uniform mat4 ${Shader.MVP_MATRIX};
varying vec4 v_color;

void main () {
	v_color = ${Shader.COLOR};
	gl_Position = ${Shader.MVP_MATRIX} * ${Shader.POSITION};
}
`;
		return new Shader(context, vs, `
#ifdef GL_ES
	#define LOWP lowp
	precision mediump float;
#else
	#define LOWP
#endif
varying LOWP vec4 v_color;

void main () {
	gl_FragColor = v_color;
}
`);
	}
};
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/Mesh.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Mesh = class {
	attributes;
	context;
	vertices;
	verticesBuffer = null;
	verticesLength = 0;
	dirtyVertices = false;
	indices;
	indicesBuffer = null;
	indicesLength = 0;
	dirtyIndices = false;
	elementsPerVertex = 0;
	getAttributes() {
		return this.attributes;
	}
	maxVertices() {
		return this.vertices.length / this.elementsPerVertex;
	}
	numVertices() {
		return this.verticesLength / this.elementsPerVertex;
	}
	setVerticesLength(length) {
		this.dirtyVertices = true;
		this.verticesLength = length;
	}
	getVertices() {
		return this.vertices;
	}
	maxIndices() {
		return this.indices.length;
	}
	numIndices() {
		return this.indicesLength;
	}
	setIndicesLength(length) {
		this.dirtyIndices = true;
		this.indicesLength = length;
	}
	getIndices() {
		return this.indices;
	}
	getVertexSizeInFloats() {
		let size = 0;
		for (let i = 0; i < this.attributes.length; i++) {
			const attribute = this.attributes[i];
			size += attribute.numElements;
		}
		return size;
	}
	constructor(context, attributes, maxVertices, maxIndices) {
		this.attributes = attributes;
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		this.elementsPerVertex = 0;
		for (let i = 0; i < attributes.length; i++) this.elementsPerVertex += attributes[i].numElements;
		this.vertices = new Float32Array(maxVertices * this.elementsPerVertex);
		this.indices = new Uint16Array(maxIndices);
		this.context.addRestorable(this);
	}
	setVertices(vertices) {
		this.dirtyVertices = true;
		if (vertices.length > this.vertices.length) throw Error(`Mesh can't store more than ${this.maxVertices()} vertices`);
		this.vertices.set(vertices, 0);
		this.verticesLength = vertices.length;
	}
	setIndices(indices) {
		this.dirtyIndices = true;
		if (indices.length > this.indices.length) throw Error(`Mesh can't store more than ${this.maxIndices()} indices`);
		this.indices.set(indices, 0);
		this.indicesLength = indices.length;
	}
	draw(shader, primitiveType) {
		this.drawWithOffset(shader, primitiveType, 0, this.indicesLength > 0 ? this.indicesLength : this.verticesLength / this.elementsPerVertex);
	}
	drawWithOffset(shader, primitiveType, offset, count) {
		const gl = this.context.gl;
		if (this.dirtyVertices || this.dirtyIndices) this.update();
		this.bind(shader);
		if (this.indicesLength > 0) gl.drawElements(primitiveType, count, gl.UNSIGNED_SHORT, offset * 2);
		else gl.drawArrays(primitiveType, offset, count);
		this.unbind(shader);
	}
	bind(shader) {
		const gl = this.context.gl;
		gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);
		let offset = 0;
		for (let i = 0; i < this.attributes.length; i++) {
			const attrib = this.attributes[i];
			const location = shader.getAttributeLocation(attrib.name);
			gl.enableVertexAttribArray(location);
			gl.vertexAttribPointer(location, attrib.numElements, gl.FLOAT, false, this.elementsPerVertex * 4, offset * 4);
			offset += attrib.numElements;
		}
		if (this.indicesLength > 0) gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indicesBuffer);
	}
	unbind(shader) {
		const gl = this.context.gl;
		for (let i = 0; i < this.attributes.length; i++) {
			const attrib = this.attributes[i];
			const location = shader.getAttributeLocation(attrib.name);
			gl.disableVertexAttribArray(location);
		}
		gl.bindBuffer(gl.ARRAY_BUFFER, null);
		if (this.indicesLength > 0) gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null);
	}
	update() {
		const gl = this.context.gl;
		if (this.dirtyVertices) {
			if (!this.verticesBuffer) this.verticesBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);
			gl.bufferData(gl.ARRAY_BUFFER, this.vertices.subarray(0, this.verticesLength), gl.DYNAMIC_DRAW);
			this.dirtyVertices = false;
		}
		if (this.dirtyIndices) {
			if (!this.indicesBuffer) this.indicesBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indicesBuffer);
			gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.indices.subarray(0, this.indicesLength), gl.DYNAMIC_DRAW);
			this.dirtyIndices = false;
		}
	}
	restore() {
		this.verticesBuffer = null;
		this.indicesBuffer = null;
		this.update();
	}
	dispose() {
		this.context.removeRestorable(this);
		const gl = this.context.gl;
		gl.deleteBuffer(this.verticesBuffer);
		gl.deleteBuffer(this.indicesBuffer);
	}
};
var VertexAttribute = class {
	name;
	type;
	numElements;
	constructor(name, type, numElements) {
		this.name = name;
		this.type = type;
		this.numElements = numElements;
	}
};
var Position2Attribute = class extends VertexAttribute {
	constructor() {
		super(Shader.POSITION, VertexAttributeType.Float, 2);
	}
};
var TexCoordAttribute = class extends VertexAttribute {
	constructor(unit = 0) {
		super(Shader.TEXCOORDS + (unit === 0 ? "" : unit), VertexAttributeType.Float, 2);
	}
};
var ColorAttribute = class extends VertexAttribute {
	constructor() {
		super(Shader.COLOR, VertexAttributeType.Float, 4);
	}
};
var Color2Attribute = class extends VertexAttribute {
	constructor() {
		super(Shader.COLOR2, VertexAttributeType.Float, 4);
	}
};
var VertexAttributeType;
(function(VertexAttributeType) {
	VertexAttributeType[VertexAttributeType["Float"] = 0] = "Float";
})(VertexAttributeType || (VertexAttributeType = {}));
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/PolygonBatcher.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var GL_ONE = 1;
var GL_ONE_MINUS_SRC_COLOR = 769;
var GL_ONE_MINUS_SRC_ALPHA = 771;
var GL_DST_COLOR = 774;
var PolygonBatcher = class PolygonBatcher {
	static disableCulling = false;
	context;
	drawCalls = 0;
	static globalDrawCalls = 0;
	isDrawing = false;
	mesh;
	shader = null;
	lastTexture = null;
	verticesLength = 0;
	indicesLength = 0;
	srcColorBlend;
	srcAlphaBlend;
	dstBlend;
	cullWasEnabled = false;
	constructor(context, twoColorTint = true, maxVertices = 10920) {
		if (maxVertices > 10920) throw new Error(`Can't have more than 10920 triangles per batch: ${maxVertices}`);
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		const attributes = twoColorTint ? [
			new Position2Attribute(),
			new ColorAttribute(),
			new TexCoordAttribute(),
			new Color2Attribute()
		] : [
			new Position2Attribute(),
			new ColorAttribute(),
			new TexCoordAttribute()
		];
		this.mesh = new Mesh(context, attributes, maxVertices, maxVertices * 3);
		const gl = this.context.gl;
		this.srcColorBlend = gl.SRC_ALPHA;
		this.srcAlphaBlend = gl.ONE;
		this.dstBlend = gl.ONE_MINUS_SRC_ALPHA;
	}
	begin(shader) {
		if (this.isDrawing) throw new Error("PolygonBatch is already drawing. Call PolygonBatch.end() before calling PolygonBatch.begin()");
		this.drawCalls = 0;
		this.shader = shader;
		this.lastTexture = null;
		this.isDrawing = true;
		const gl = this.context.gl;
		gl.enable(gl.BLEND);
		gl.blendFuncSeparate(this.srcColorBlend, this.dstBlend, this.srcAlphaBlend, this.dstBlend);
		if (PolygonBatcher.disableCulling) {
			this.cullWasEnabled = gl.isEnabled(gl.CULL_FACE);
			if (this.cullWasEnabled) gl.disable(gl.CULL_FACE);
		}
	}
	static blendModesGL = [
		{
			srcRgbPma: GL_ONE,
			dstRgb: GL_ONE_MINUS_SRC_ALPHA,
			srcAlpha: GL_ONE
		},
		{
			srcRgbPma: GL_ONE,
			dstRgb: GL_ONE,
			srcAlpha: GL_ONE
		},
		{
			srcRgbPma: GL_DST_COLOR,
			dstRgb: GL_ONE_MINUS_SRC_ALPHA,
			srcAlpha: GL_ONE
		},
		{
			srcRgbPma: GL_ONE,
			dstRgb: GL_ONE_MINUS_SRC_COLOR,
			srcAlpha: GL_ONE
		}
	];
	setBlendMode(blendMode) {
		const blendModeGL = PolygonBatcher.blendModesGL[blendMode];
		const srcColorBlend = blendModeGL.srcRgbPma;
		const srcAlphaBlend = blendModeGL.srcAlpha;
		const dstBlend = blendModeGL.dstRgb;
		if (this.srcColorBlend === srcColorBlend && this.srcAlphaBlend === srcAlphaBlend && this.dstBlend === dstBlend) return;
		this.srcColorBlend = srcColorBlend;
		this.srcAlphaBlend = srcAlphaBlend;
		this.dstBlend = dstBlend;
		if (this.isDrawing) this.flush();
		this.context.gl.blendFuncSeparate(srcColorBlend, dstBlend, srcAlphaBlend, dstBlend);
	}
	draw(texture, vertices, indices) {
		if (texture !== this.lastTexture) {
			this.flush();
			this.lastTexture = texture;
		} else if (this.verticesLength + vertices.length > this.mesh.getVertices().length || this.indicesLength + indices.length > this.mesh.getIndices().length) this.flush();
		const indexStart = this.mesh.numVertices();
		this.mesh.getVertices().set(vertices, this.verticesLength);
		this.verticesLength += vertices.length;
		this.mesh.setVerticesLength(this.verticesLength);
		const indicesArray = this.mesh.getIndices();
		for (let i = this.indicesLength, j = 0; j < indices.length; i++, j++) indicesArray[i] = indices[j] + indexStart;
		this.indicesLength += indices.length;
		this.mesh.setIndicesLength(this.indicesLength);
	}
	flush() {
		if (this.verticesLength === 0) return;
		if (!this.lastTexture) throw new Error("No texture set.");
		if (!this.shader) throw new Error("No shader set.");
		this.lastTexture.bind();
		this.mesh.draw(this.shader, this.context.gl.TRIANGLES);
		this.verticesLength = 0;
		this.indicesLength = 0;
		this.mesh.setVerticesLength(0);
		this.mesh.setIndicesLength(0);
		this.drawCalls++;
		PolygonBatcher.globalDrawCalls++;
	}
	end() {
		if (!this.isDrawing) throw new Error("PolygonBatch is not drawing. Call PolygonBatch.begin() before calling PolygonBatch.end()");
		if (this.verticesLength > 0 || this.indicesLength > 0) this.flush();
		this.shader = null;
		this.lastTexture = null;
		this.isDrawing = false;
		const gl = this.context.gl;
		gl.disable(gl.BLEND);
		if (PolygonBatcher.disableCulling) {
			if (this.cullWasEnabled) gl.enable(gl.CULL_FACE);
		}
	}
	getDrawCalls() {
		return this.drawCalls;
	}
	static getAndResetGlobalDrawCalls() {
		const result = PolygonBatcher.globalDrawCalls;
		PolygonBatcher.globalDrawCalls = 0;
		return result;
	}
	dispose() {
		this.mesh.dispose();
	}
};
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/ShapeRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var ShapeRenderer = class {
	context;
	isDrawing = false;
	mesh;
	shapeType = ShapeType.Filled;
	color = new Color(1, 1, 1, 1);
	shader = null;
	vertexIndex = 0;
	tmp = new Vector2();
	srcColorBlend;
	srcAlphaBlend;
	dstBlend;
	constructor(context, maxVertices = 10920) {
		if (maxVertices > 10920) throw new Error(`Can't have more than 10920 triangles per batch: ${maxVertices}`);
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		this.mesh = new Mesh(context, [new Position2Attribute(), new ColorAttribute()], maxVertices, 0);
		const gl = this.context.gl;
		this.srcColorBlend = gl.SRC_ALPHA;
		this.srcAlphaBlend = gl.ONE;
		this.dstBlend = gl.ONE_MINUS_SRC_ALPHA;
	}
	begin(shader) {
		if (this.isDrawing) throw new Error("ShapeRenderer.begin() has already been called");
		this.shader = shader;
		this.vertexIndex = 0;
		this.isDrawing = true;
		const gl = this.context.gl;
		gl.enable(gl.BLEND);
		gl.blendFuncSeparate(this.srcColorBlend, this.dstBlend, this.srcAlphaBlend, this.dstBlend);
	}
	setBlendMode(srcColorBlend, srcAlphaBlend, dstBlend) {
		this.srcColorBlend = srcColorBlend;
		this.srcAlphaBlend = srcAlphaBlend;
		this.dstBlend = dstBlend;
		if (this.isDrawing) {
			this.flush();
			this.context.gl.blendFuncSeparate(srcColorBlend, dstBlend, srcAlphaBlend, dstBlend);
		}
	}
	setColor(color) {
		this.color.setFromColor(color);
	}
	setColorWith(r, g, b, a) {
		this.color.set(r, g, b, a);
	}
	point(x, y, color) {
		this.check(ShapeType.Point, 1);
		if (!color) color = this.color;
		this.vertex(x, y, color);
	}
	line(x, y, x2, y2, color) {
		this.check(ShapeType.Line, 2);
		if (!color) color = this.color;
		this.vertex(x, y, color);
		this.vertex(x2, y2, color);
	}
	triangle(filled, x, y, x2, y2, x3, y3, color, color2, color3) {
		this.check(filled ? ShapeType.Filled : ShapeType.Line, 3);
		if (!color) color = this.color;
		if (!color2) color2 = this.color;
		if (!color3) color3 = this.color;
		if (filled) {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
		} else {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x2, y2, color);
			this.vertex(x3, y3, color2);
			this.vertex(x3, y3, color);
			this.vertex(x, y, color2);
		}
	}
	quad(filled, x, y, x2, y2, x3, y3, x4, y4, color, color2, color3, color4) {
		this.check(filled ? ShapeType.Filled : ShapeType.Line, 3);
		if (!color) color = this.color;
		if (!color2) color2 = this.color;
		if (!color3) color3 = this.color;
		if (!color4) color4 = this.color;
		if (filled) {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
			this.vertex(x3, y3, color3);
			this.vertex(x4, y4, color4);
			this.vertex(x, y, color);
		} else {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
			this.vertex(x3, y3, color3);
			this.vertex(x4, y4, color4);
			this.vertex(x4, y4, color4);
			this.vertex(x, y, color);
		}
	}
	rect(filled, x, y, width, height, color) {
		this.quad(filled, x, y, x + width, y, x + width, y + height, x, y + height, color, color, color, color);
	}
	rectLine(filled, x1, y1, x2, y2, width, color) {
		this.check(filled ? ShapeType.Filled : ShapeType.Line, 8);
		if (!color) color = this.color;
		const t = this.tmp.set(y2 - y1, x1 - x2);
		t.normalize();
		width *= .5;
		const tx = t.x * width;
		const ty = t.y * width;
		if (!filled) {
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
		} else {
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
		}
	}
	x(x, y, size) {
		this.line(x - size, y - size, x + size, y + size);
		this.line(x - size, y + size, x + size, y - size);
	}
	polygon(polygonVertices, offset, count, color) {
		if (count < 3) throw new Error("Polygon must contain at least 3 vertices");
		this.check(ShapeType.Line, count * 2);
		if (!color) color = this.color;
		offset <<= 1;
		count <<= 1;
		const firstX = polygonVertices[offset];
		const firstY = polygonVertices[offset + 1];
		const last = offset + count;
		for (let i = offset, n = offset + count - 2; i < n; i += 2) {
			const x1 = polygonVertices[i];
			const y1 = polygonVertices[i + 1];
			let x2 = 0;
			let y2 = 0;
			if (i + 2 >= last) {
				x2 = firstX;
				y2 = firstY;
			} else {
				x2 = polygonVertices[i + 2];
				y2 = polygonVertices[i + 3];
			}
			this.vertex(x1, y1, color);
			this.vertex(x2, y2, color);
		}
	}
	circle(filled, x, y, radius, color, segments = 0) {
		if (segments === 0) segments = Math.max(1, 6 * MathUtils.cbrt(radius) | 0);
		if (segments <= 0) throw new Error("segments must be > 0.");
		if (!color) color = this.color;
		const angle = 2 * MathUtils.PI / segments;
		const cos = Math.cos(angle);
		const sin = Math.sin(angle);
		let cx = radius, cy = 0;
		if (!filled) {
			this.check(ShapeType.Line, segments * 2 + 2);
			for (let i = 0; i < segments; i++) {
				this.vertex(x + cx, y + cy, color);
				const temp = cx;
				cx = cos * cx - sin * cy;
				cy = sin * temp + cos * cy;
				this.vertex(x + cx, y + cy, color);
			}
			this.vertex(x + cx, y + cy, color);
		} else {
			this.check(ShapeType.Filled, segments * 3 + 3);
			segments--;
			for (let i = 0; i < segments; i++) {
				this.vertex(x, y, color);
				this.vertex(x + cx, y + cy, color);
				const temp = cx;
				cx = cos * cx - sin * cy;
				cy = sin * temp + cos * cy;
				this.vertex(x + cx, y + cy, color);
			}
			this.vertex(x, y, color);
			this.vertex(x + cx, y + cy, color);
		}
		cx = radius;
		cy = 0;
		this.vertex(x + cx, y + cy, color);
	}
	curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color) {
		this.check(ShapeType.Line, segments * 2 + 2);
		if (!color) color = this.color;
		const subdiv_step = 1 / segments;
		const subdiv_step2 = subdiv_step * subdiv_step;
		const subdiv_step3 = subdiv_step * subdiv_step * subdiv_step;
		const pre1 = 3 * subdiv_step;
		const pre2 = 3 * subdiv_step2;
		const pre4 = 6 * subdiv_step2;
		const pre5 = 6 * subdiv_step3;
		const tmp1x = x1 - cx1 * 2 + cx2;
		const tmp1y = y1 - cy1 * 2 + cy2;
		const tmp2x = (cx1 - cx2) * 3 - x1 + x2;
		const tmp2y = (cy1 - cy2) * 3 - y1 + y2;
		let fx = x1;
		let fy = y1;
		let dfx = (cx1 - x1) * pre1 + tmp1x * pre2 + tmp2x * subdiv_step3;
		let dfy = (cy1 - y1) * pre1 + tmp1y * pre2 + tmp2y * subdiv_step3;
		let ddfx = tmp1x * pre4 + tmp2x * pre5;
		let ddfy = tmp1y * pre4 + tmp2y * pre5;
		const dddfx = tmp2x * pre5;
		const dddfy = tmp2y * pre5;
		while (segments-- > 0) {
			this.vertex(fx, fy, color);
			fx += dfx;
			fy += dfy;
			dfx += ddfx;
			dfy += ddfy;
			ddfx += dddfx;
			ddfy += dddfy;
			this.vertex(fx, fy, color);
		}
		this.vertex(fx, fy, color);
		this.vertex(x2, y2, color);
	}
	vertex(x, y, color) {
		let idx = this.vertexIndex;
		const vertices = this.mesh.getVertices();
		vertices[idx++] = x;
		vertices[idx++] = y;
		vertices[idx++] = color.r;
		vertices[idx++] = color.g;
		vertices[idx++] = color.b;
		vertices[idx++] = color.a;
		this.vertexIndex = idx;
	}
	end() {
		if (!this.isDrawing) throw new Error("ShapeRenderer.begin() has not been called");
		this.flush();
		const gl = this.context.gl;
		gl.disable(gl.BLEND);
		this.isDrawing = false;
	}
	flush() {
		if (this.vertexIndex === 0) return;
		if (!this.shader) throw new Error("No shader set.");
		this.mesh.setVerticesLength(this.vertexIndex);
		this.mesh.draw(this.shader, this.shapeType);
		this.vertexIndex = 0;
	}
	check(shapeType, numVertices) {
		if (!this.isDrawing) throw new Error("ShapeRenderer.begin() has not been called");
		if (this.shapeType === shapeType) {
			if (this.mesh.maxVertices() - this.mesh.numVertices() < numVertices) this.flush();
			else return;
		} else {
			this.flush();
			this.shapeType = shapeType;
		}
	}
	dispose() {
		this.mesh.dispose();
	}
};
var ShapeType;
(function(ShapeType) {
	ShapeType[ShapeType["Point"] = 0] = "Point";
	ShapeType[ShapeType["Line"] = 1] = "Line";
	ShapeType[ShapeType["Filled"] = 4] = "Filled";
})(ShapeType || (ShapeType = {}));
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/SkeletonDebugRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var SkeletonDebugRenderer = class SkeletonDebugRenderer {
	boneLineColor = new Color(1, 0, 0, 1);
	boneOriginColor = new Color(0, 1, 0, 1);
	attachmentLineColor = new Color(0, 0, 1, .5);
	triangleLineColor = new Color(1, .64, 0, .5);
	pathColor = new Color().setFromString("FF7F00");
	clipColor = new Color(.8, 0, 0, 2);
	aabbColor = new Color(0, 1, 0, .5);
	drawBones = true;
	drawRegionAttachments = true;
	drawBoundingBoxes = true;
	drawMeshHull = true;
	drawMeshTriangles = true;
	drawPaths = true;
	drawSkeletonXY = false;
	drawClipping = true;
	scale = 1;
	boneWidth = 2;
	context;
	bounds = new SkeletonBounds();
	temp = [];
	vertices = Utils.newFloatArray(2048);
	static LIGHT_GRAY = new Color(192 / 255, 192 / 255, 192 / 255, 1);
	static GREEN = new Color(0, 1, 0, 1);
	constructor(context) {
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
	}
	draw(shapes, skeleton, ignoredBones) {
		const skeletonX = skeleton.x;
		const skeletonY = skeleton.y;
		const gl = this.context.gl;
		shapes.setBlendMode(gl.ONE, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
		const bones = skeleton.bones;
		if (this.drawBones) {
			shapes.setColor(this.boneLineColor);
			for (let i = 0, n = bones.length; i < n; i++) {
				const bone = bones[i];
				if (ignoredBones && ignoredBones.indexOf(bone.data.name) > -1) continue;
				if (!bone.parent) continue;
				const boneApplied = bone.appliedPose;
				const x = bone.data.length * boneApplied.a + boneApplied.worldX;
				const y = bone.data.length * boneApplied.c + boneApplied.worldY;
				shapes.rectLine(true, boneApplied.worldX, boneApplied.worldY, x, y, this.boneWidth * this.scale);
			}
			if (this.drawSkeletonXY) shapes.x(skeletonX, skeletonY, 4 * this.scale);
		}
		if (this.drawRegionAttachments) {
			shapes.setColor(this.attachmentLineColor);
			const slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				const slot = slots[i];
				if (!slot.bone.active) continue;
				const attachment = slot.appliedPose.attachment;
				if (attachment instanceof RegionAttachment) {
					const vertices = this.vertices;
					attachment.computeWorldVertices(slot, attachment.getOffsets(slot.appliedPose), vertices, 0, 2);
					shapes.line(vertices[0], vertices[1], vertices[2], vertices[3]);
					shapes.line(vertices[2], vertices[3], vertices[4], vertices[5]);
					shapes.line(vertices[4], vertices[5], vertices[6], vertices[7]);
					shapes.line(vertices[6], vertices[7], vertices[0], vertices[1]);
				}
			}
		}
		if (this.drawMeshHull || this.drawMeshTriangles) {
			const slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				const slot = slots[i];
				if (!slot.bone.active) continue;
				const attachment = slot.appliedPose.attachment;
				if (!(attachment instanceof MeshAttachment)) continue;
				const vertices = this.vertices;
				attachment.computeWorldVertices(skeleton, slot, 0, attachment.worldVerticesLength, vertices, 0, 2);
				const triangles = attachment.triangles;
				let hullLength = attachment.hullLength;
				if (this.drawMeshTriangles) {
					shapes.setColor(this.triangleLineColor);
					for (let ii = 0, nn = triangles.length; ii < nn; ii += 3) {
						const v1 = triangles[ii] * 2, v2 = triangles[ii + 1] * 2, v3 = triangles[ii + 2] * 2;
						shapes.triangle(false, vertices[v1], vertices[v1 + 1], vertices[v2], vertices[v2 + 1], vertices[v3], vertices[v3 + 1]);
					}
				}
				if (this.drawMeshHull && hullLength > 0) {
					shapes.setColor(this.attachmentLineColor);
					hullLength = (hullLength >> 1) * 2;
					let lastX = vertices[hullLength - 2], lastY = vertices[hullLength - 1];
					for (let ii = 0, nn = hullLength; ii < nn; ii += 2) {
						const x = vertices[ii], y = vertices[ii + 1];
						shapes.line(x, y, lastX, lastY);
						lastX = x;
						lastY = y;
					}
				}
			}
		}
		if (this.drawBoundingBoxes) {
			const bounds = this.bounds;
			bounds.update(skeleton, true);
			shapes.setColor(this.aabbColor);
			shapes.rect(false, bounds.minX, bounds.minY, bounds.getWidth(), bounds.getHeight());
			const polygons = bounds.polygons;
			const boxes = bounds.boundingBoxes;
			for (let i = 0, n = polygons.length; i < n; i++) {
				const polygon = polygons[i];
				shapes.setColor(boxes[i].color);
				shapes.polygon(polygon, 0, polygon.length);
			}
		}
		if (this.drawPaths) {
			const slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				const slot = slots[i];
				if (!slot.bone.active) continue;
				const attachment = slot.appliedPose.attachment;
				if (!(attachment instanceof PathAttachment)) continue;
				let nn = attachment.worldVerticesLength;
				const world = this.temp = Utils.setArraySize(this.temp, nn, 0);
				attachment.computeWorldVertices(skeleton, slot, 0, nn, world, 0, 2);
				const color = this.pathColor;
				let x1 = world[2], y1 = world[3], x2 = 0, y2 = 0;
				if (attachment.closed) {
					shapes.setColor(color);
					const cx1 = world[0], cy1 = world[1], cx2 = world[nn - 2], cy2 = world[nn - 1];
					x2 = world[nn - 4];
					y2 = world[nn - 3];
					shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, 32);
					shapes.setColor(SkeletonDebugRenderer.LIGHT_GRAY);
					shapes.line(x1, y1, cx1, cy1);
					shapes.line(x2, y2, cx2, cy2);
				}
				nn -= 4;
				for (let ii = 4; ii < nn; ii += 6) {
					const cx1 = world[ii], cy1 = world[ii + 1], cx2 = world[ii + 2], cy2 = world[ii + 3];
					x2 = world[ii + 4];
					y2 = world[ii + 5];
					shapes.setColor(color);
					shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, 32);
					shapes.setColor(SkeletonDebugRenderer.LIGHT_GRAY);
					shapes.line(x1, y1, cx1, cy1);
					shapes.line(x2, y2, cx2, cy2);
					x1 = x2;
					y1 = y2;
				}
			}
		}
		if (this.drawBones) {
			shapes.setColor(this.boneOriginColor);
			for (let i = 0, n = bones.length; i < n; i++) {
				const bone = bones[i];
				if (ignoredBones && ignoredBones.indexOf(bone.data.name) > -1) continue;
				const boneApplied = bone.appliedPose;
				shapes.circle(true, boneApplied.worldX, boneApplied.worldY, 3 * this.scale, this.boneOriginColor, 8);
			}
		}
		if (this.drawClipping) {
			const slots = skeleton.slots;
			shapes.setColor(this.clipColor);
			for (let i = 0, n = slots.length; i < n; i++) {
				const slot = slots[i];
				if (!slot.bone.active) continue;
				const attachment = slot.appliedPose.attachment;
				if (!(attachment instanceof ClippingAttachment)) continue;
				const nn = attachment.worldVerticesLength;
				const world = this.temp = Utils.setArraySize(this.temp, nn, 0);
				attachment.computeWorldVertices(skeleton, slot, 0, nn, world, 0, 2);
				for (let i = 0, n = world.length; i < n; i += 2) {
					const x = world[i];
					const y = world[i + 1];
					const x2 = world[(i + 2) % world.length];
					const y2 = world[(i + 3) % world.length];
					shapes.line(x, y, x2, y2);
				}
			}
		}
	}
	dispose() {}
};
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/SkeletonRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Renderable = class {
	vertices;
	numVertices;
	numFloats;
	constructor(vertices, numVertices, numFloats) {
		this.vertices = vertices;
		this.numVertices = numVertices;
		this.numFloats = numFloats;
	}
};
var SkeletonRenderer = class SkeletonRenderer {
	static QUAD_TRIANGLES = [
		0,
		1,
		2,
		2,
		3,
		0
	];
	tempColor = new Color();
	tempColor2 = new Color();
	vertices;
	vertexSize = 8;
	twoColorTint = false;
	renderable = new Renderable([], 0, 0);
	clipper = new SkeletonClipping();
	/**
	* Batches additive slots together with normal slots by rendering additive slots with premultiplied alpha RGB and zero alpha,
	* while using normal PMA blending. This reduces draw calls for normal/additive/normal sequences with the same texture.
	* Disable this if rendering to a transparent target and the accumulated destination alpha from additive blending must be preserved.
	*/
	pmaAdditiveBatching = true;
	constructor(context, twoColorTint = true) {
		this.twoColorTint = twoColorTint;
		if (twoColorTint) this.vertexSize += 4;
		this.vertices = Utils.newFloatArray(this.vertexSize * 1024);
	}
	draw(batcher, skeleton, slotRangeStart = -1, slotRangeEnd = -1, transformer = null) {
		const clipper = this.clipper;
		const twoColorTint = this.twoColorTint;
		let blendMode = null;
		const renderable = this.renderable;
		let uvs;
		let triangles;
		const drawOrder = skeleton.drawOrder.appliedPose;
		let attachmentColor;
		const skeletonColor = skeleton.color;
		const vertexSize = twoColorTint ? 12 : 8;
		let inRange = false;
		if (slotRangeStart === -1) inRange = true;
		for (let i = 0, n = drawOrder.length; i < n; i++) {
			const slot = drawOrder[i];
			if (!slot.bone.active) {
				clipper.clipEnd(slot);
				continue;
			}
			if (slotRangeStart >= 0 && slotRangeStart === slot.data.index) inRange = true;
			if (!inRange) {
				clipper.clipEnd(slot);
				continue;
			}
			if (slotRangeEnd >= 0 && slotRangeEnd === slot.data.index) inRange = false;
			const pose = slot.appliedPose;
			const attachment = pose.attachment;
			let texture;
			if (attachment instanceof RegionAttachment) {
				renderable.vertices = this.vertices;
				renderable.numVertices = 4;
				renderable.numFloats = vertexSize << 2;
				const sequence = attachment.sequence;
				const sequenceIndex = sequence.resolveIndex(pose);
				attachment.computeWorldVertices(slot, attachment.getOffsets(pose), renderable.vertices, 0, vertexSize);
				triangles = SkeletonRenderer.QUAD_TRIANGLES;
				uvs = sequence.getUVs(sequenceIndex);
				texture = sequence.regions[sequenceIndex]?.texture;
				attachmentColor = attachment.color;
			} else if (attachment instanceof MeshAttachment) {
				renderable.vertices = this.vertices;
				renderable.numVertices = attachment.worldVerticesLength >> 1;
				renderable.numFloats = renderable.numVertices * vertexSize;
				if (renderable.numFloats > renderable.vertices.length) renderable.vertices = this.vertices = Utils.newFloatArray(renderable.numFloats);
				attachment.computeWorldVertices(skeleton, slot, 0, attachment.worldVerticesLength, renderable.vertices, 0, vertexSize);
				triangles = attachment.triangles;
				const sequence = attachment.sequence;
				const sequenceIndex = sequence.resolveIndex(pose);
				texture = sequence.regions[sequenceIndex]?.texture;
				uvs = sequence.getUVs(sequenceIndex);
				attachmentColor = attachment.color;
			} else if (attachment instanceof ClippingAttachment) {
				clipper.clipEnd(slot);
				clipper.clipStart(skeleton, slot, attachment);
				continue;
			} else {
				clipper.clipEnd(slot);
				continue;
			}
			if (texture) {
				const slotColor = pose.color;
				const finalColor = this.tempColor;
				const alpha = skeletonColor.a * slotColor.a * attachmentColor.a;
				finalColor.r = skeletonColor.r * slotColor.r * attachmentColor.r * alpha;
				finalColor.g = skeletonColor.g * slotColor.g * attachmentColor.g * alpha;
				finalColor.b = skeletonColor.b * slotColor.b * attachmentColor.b * alpha;
				const slotBlendMode = slot.data.blendMode;
				const additiveBlend = this.pmaAdditiveBatching && slotBlendMode === BlendMode.Additive;
				finalColor.a = additiveBlend ? 0 : alpha;
				const darkColor = this.tempColor2;
				if (!pose.darkColor) darkColor.set(0, 0, 0, 1);
				else {
					darkColor.r = pose.darkColor.r * alpha;
					darkColor.g = pose.darkColor.g * alpha;
					darkColor.b = pose.darkColor.b * alpha;
					darkColor.a = 1;
				}
				const batchBlendMode = additiveBlend ? BlendMode.Normal : slotBlendMode;
				if (batchBlendMode !== blendMode) {
					blendMode = batchBlendMode;
					batcher.setBlendMode(blendMode);
				}
				if (clipper.isClipping() && clipper.clipTriangles(renderable.vertices, triangles, triangles.length, uvs, finalColor, darkColor, twoColorTint, vertexSize)) {
					const clippedVertices = new Float32Array(clipper.clippedVertices);
					const clippedTriangles = clipper.clippedTriangles;
					if (transformer) transformer(clippedVertices, clippedVertices.length, vertexSize);
					batcher.draw(texture, clippedVertices, clippedTriangles);
				} else {
					const verts = renderable.vertices;
					if (!twoColorTint) for (let v = 2, u = 0, n = renderable.numFloats; v < n; v += vertexSize, u += 2) {
						verts[v] = finalColor.r;
						verts[v + 1] = finalColor.g;
						verts[v + 2] = finalColor.b;
						verts[v + 3] = finalColor.a;
						verts[v + 4] = uvs[u];
						verts[v + 5] = uvs[u + 1];
					}
					else for (let v = 2, u = 0, n = renderable.numFloats; v < n; v += vertexSize, u += 2) {
						verts[v] = finalColor.r;
						verts[v + 1] = finalColor.g;
						verts[v + 2] = finalColor.b;
						verts[v + 3] = finalColor.a;
						verts[v + 4] = uvs[u];
						verts[v + 5] = uvs[u + 1];
						verts[v + 6] = darkColor.r;
						verts[v + 7] = darkColor.g;
						verts[v + 8] = darkColor.b;
						verts[v + 9] = darkColor.a;
					}
					const view = renderable.vertices.subarray(0, renderable.numFloats);
					if (transformer) transformer(renderable.vertices, renderable.numFloats, vertexSize);
					batcher.draw(texture, view, triangles);
				}
			}
			clipper.clipEnd(slot);
		}
		clipper.clipEnd();
	}
	/** Returns the {@link SkeletonClipping} used by this renderer for use with e.g. {@link Skeleton.getBounds} **/
	getSkeletonClipping() {
		return this.clipper;
	}
};
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/SceneRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var quad = [
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0
];
var QUAD_TRIANGLES = [
	0,
	1,
	2,
	2,
	3,
	0
];
var WHITE = new Color(1, 1, 1, 1);
var SceneRenderer = class {
	context;
	canvas;
	camera;
	batcher;
	twoColorTint = false;
	batcherShader;
	shapes;
	shapesShader;
	activeRenderer = null;
	maxCanvasWidth = 0;
	maxCanvasHeight = 0;
	skeletonRenderer;
	skeletonDebugRenderer;
	constructor(canvas, context, twoColorTint = true) {
		this.canvas = canvas;
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		this.twoColorTint = twoColorTint;
		this.camera = new OrthoCamera(canvas.width, canvas.height);
		this.batcherShader = twoColorTint ? Shader.newTwoColoredTextured(this.context) : Shader.newColoredTextured(this.context);
		this.batcher = new PolygonBatcher(this.context, twoColorTint);
		this.shapesShader = Shader.newColored(this.context);
		this.shapes = new ShapeRenderer(this.context);
		this.skeletonRenderer = new SkeletonRenderer(this.context, twoColorTint);
		this.skeletonDebugRenderer = new SkeletonDebugRenderer(this.context);
	}
	dispose() {
		this.batcher.dispose();
		this.batcherShader.dispose();
		this.shapes.dispose();
		this.shapesShader.dispose();
		this.skeletonDebugRenderer.dispose();
	}
	begin() {
		this.camera.update();
		this.enableRenderer(this.batcher);
	}
	drawSkeleton(skeleton, slotRangeStart = -1, slotRangeEnd = -1, transform = null) {
		this.enableRenderer(this.batcher);
		this.skeletonRenderer.draw(this.batcher, skeleton, slotRangeStart, slotRangeEnd, transform);
	}
	drawSkeletonDebug(skeleton, ignoredBones) {
		this.enableRenderer(this.shapes);
		this.skeletonDebugRenderer.draw(this.shapes, skeleton, ignoredBones);
	}
	drawTexture(texture, x, y, width, height, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE;
		var i = 0;
		quad[i++] = x;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 0;
		quad[i++] = 1;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 1;
		quad[i++] = 1;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 1;
		quad[i++] = 0;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 0;
		quad[i++] = 0;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i] = 0;
		}
		this.batcher.draw(texture, quad, QUAD_TRIANGLES);
	}
	drawTextureUV(texture, x, y, width, height, u, v, u2, v2, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE;
		var i = 0;
		quad[i++] = x;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = u;
		quad[i++] = v;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = u2;
		quad[i++] = v;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = u2;
		quad[i++] = v2;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = u;
		quad[i++] = v2;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i] = 0;
		}
		this.batcher.draw(texture, quad, QUAD_TRIANGLES);
	}
	drawTextureRotated(texture, x, y, width, height, pivotX, pivotY, angle, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE;
		const worldOriginX = x + pivotX;
		const worldOriginY = y + pivotY;
		const fx = -pivotX;
		const fy = -pivotY;
		const fx2 = width - pivotX;
		const fy2 = height - pivotY;
		const p1x = fx;
		const p1y = fy;
		const p2x = fx;
		const p2y = fy2;
		const p3x = fx2;
		const p3y = fy2;
		const p4x = fx2;
		const p4y = fy;
		let x1 = 0;
		let y1 = 0;
		let x2 = 0;
		let y2 = 0;
		let x3 = 0;
		let y3 = 0;
		let x4 = 0;
		let y4 = 0;
		if (angle !== 0) {
			const cos = MathUtils.cosDeg(angle);
			const sin = MathUtils.sinDeg(angle);
			x1 = cos * p1x - sin * p1y;
			y1 = sin * p1x + cos * p1y;
			x4 = cos * p2x - sin * p2y;
			y4 = sin * p2x + cos * p2y;
			x3 = cos * p3x - sin * p3y;
			y3 = sin * p3x + cos * p3y;
			x2 = x3 + (x1 - x4);
			y2 = y3 + (y1 - y4);
		} else {
			x1 = p1x;
			y1 = p1y;
			x4 = p2x;
			y4 = p2y;
			x3 = p3x;
			y3 = p3y;
			x2 = p4x;
			y2 = p4y;
		}
		x1 += worldOriginX;
		y1 += worldOriginY;
		x2 += worldOriginX;
		y2 += worldOriginY;
		x3 += worldOriginX;
		y3 += worldOriginY;
		x4 += worldOriginX;
		y4 += worldOriginY;
		var i = 0;
		quad[i++] = x1;
		quad[i++] = y1;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 0;
		quad[i++] = 1;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x2;
		quad[i++] = y2;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 1;
		quad[i++] = 1;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x3;
		quad[i++] = y3;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 1;
		quad[i++] = 0;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x4;
		quad[i++] = y4;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 0;
		quad[i++] = 0;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i] = 0;
		}
		this.batcher.draw(texture, quad, QUAD_TRIANGLES);
	}
	drawRegion(region, x, y, width, height, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE;
		var i = 0;
		quad[i++] = x;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = region.u;
		quad[i++] = region.v2;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = region.u2;
		quad[i++] = region.v2;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = region.u2;
		quad[i++] = region.v;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = region.u;
		quad[i++] = region.v;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i] = 0;
		}
		this.batcher.draw(region.page.texture, quad, QUAD_TRIANGLES);
	}
	line(x, y, x2, y2, color, color2) {
		this.enableRenderer(this.shapes);
		this.shapes.line(x, y, x2, y2, color);
	}
	triangle(filled, x, y, x2, y2, x3, y3, color, color2, color3) {
		this.enableRenderer(this.shapes);
		this.shapes.triangle(filled, x, y, x2, y2, x3, y3, color, color2, color3);
	}
	quad(filled, x, y, x2, y2, x3, y3, x4, y4, color, color2, color3, color4) {
		this.enableRenderer(this.shapes);
		this.shapes.quad(filled, x, y, x2, y2, x3, y3, x4, y4, color, color2, color3, color4);
	}
	rect(filled, x, y, width, height, color) {
		this.enableRenderer(this.shapes);
		this.shapes.rect(filled, x, y, width, height, color);
	}
	rectLine(filled, x1, y1, x2, y2, width, color) {
		this.enableRenderer(this.shapes);
		this.shapes.rectLine(filled, x1, y1, x2, y2, width, color);
	}
	polygon(polygonVertices, offset, count, color) {
		this.enableRenderer(this.shapes);
		this.shapes.polygon(polygonVertices, offset, count, color);
	}
	circle(filled, x, y, radius, color, segments = 0) {
		this.enableRenderer(this.shapes);
		this.shapes.circle(filled, x, y, radius, color, segments);
	}
	curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color) {
		this.enableRenderer(this.shapes);
		this.shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color);
	}
	end() {
		if (this.activeRenderer === this.batcher) this.batcher.end();
		else if (this.activeRenderer === this.shapes) this.shapes.end();
		this.activeRenderer = null;
	}
	resize(resizeMode, worldWidth, worldHeight) {
		const canvas = this.canvas;
		const dpr = this.getSafeDevicePixelRatio(canvas.clientWidth, canvas.clientHeight);
		var w = Math.round(canvas.clientWidth * dpr);
		var h = Math.round(canvas.clientHeight * dpr);
		if (canvas.width !== w || canvas.height !== h) {
			canvas.width = w;
			canvas.height = h;
		}
		if (resizeMode === ResizeMode.FitClip && worldWidth !== void 0 && worldHeight !== void 0) {
			const scale = h / w > worldHeight / worldWidth ? w / worldWidth : h / worldHeight;
			worldWidth *= scale;
			worldHeight *= scale;
			this.camera.setViewport(worldWidth, worldHeight);
			this.context.gl.viewport((w - worldWidth) / 2, (h - worldHeight) / 2, worldWidth, worldHeight);
		} else {
			if (resizeMode === ResizeMode.Fit) {
				const targetWidth = this.camera.viewportWidth, targetHeight = this.camera.viewportHeight;
				const scale = targetHeight / targetWidth < h / w ? targetWidth / w : targetHeight / h;
				this.camera.setViewport(w * scale, h * scale);
			} else if (resizeMode === ResizeMode.Expand) this.camera.setViewport(w, h);
			this.context.gl.viewport(0, 0, w, h);
		}
		this.camera.update();
	}
	getSafeDevicePixelRatio(cssWidth, cssHeight) {
		const dpr = window.devicePixelRatio || 1;
		if (cssWidth <= 0 || cssHeight <= 0) return dpr;
		if (this.maxCanvasWidth === 0 || this.maxCanvasHeight === 0) {
			const gl = this.context.gl;
			const maxRenderbufferSize = gl.getParameter(gl.MAX_RENDERBUFFER_SIZE);
			const maxViewportDims = gl.getParameter(gl.MAX_VIEWPORT_DIMS);
			this.maxCanvasWidth = Math.min(maxRenderbufferSize, maxViewportDims[0]);
			this.maxCanvasHeight = Math.min(maxRenderbufferSize, maxViewportDims[1]);
		}
		return Math.min(dpr, this.maxCanvasWidth / cssWidth, this.maxCanvasHeight / cssHeight);
	}
	enableRenderer(renderer) {
		if (this.activeRenderer === renderer) return;
		this.end();
		if (renderer instanceof PolygonBatcher) {
			this.batcherShader.bind();
			this.batcherShader.setUniform4x4f(Shader.MVP_MATRIX, this.camera.projectionView.values);
			this.batcherShader.setUniformi("u_texture", 0);
			this.batcher.begin(this.batcherShader);
			this.activeRenderer = this.batcher;
		} else if (renderer instanceof ShapeRenderer) {
			this.shapesShader.bind();
			this.shapesShader.setUniform4x4f(Shader.MVP_MATRIX, this.camera.projectionView.values);
			this.shapes.begin(this.shapesShader);
			this.activeRenderer = this.shapes;
		} else this.activeRenderer = this.skeletonDebugRenderer;
	}
};
var ResizeMode;
(function(ResizeMode) {
	ResizeMode[ResizeMode["Stretch"] = 0] = "Stretch";
	ResizeMode[ResizeMode["Expand"] = 1] = "Expand";
	ResizeMode[ResizeMode["Fit"] = 2] = "Fit";
	ResizeMode[ResizeMode["FitClip"] = 3] = "FitClip";
})(ResizeMode || (ResizeMode = {}));
//#endregion
//#region node_modules/@esotericsoftware/spine-webgl/dist/LoadingScreen.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var spinnerImage;
var logoImage;
var loaded = 0;
var FADE_IN = 1;
var FADE_OUT = 1;
var logoWidth = 165;
var logoHeight = 108;
var spinnerSize = 163;
var LoadingScreen = class {
	renderer;
	logo = null;
	spinner = null;
	angle = 0;
	fadeOut = 0;
	fadeIn = 0;
	timeKeeper = new TimeKeeper();
	backgroundColor = new Color(.135, .135, .135, 1);
	tempColor = new Color();
	constructor(renderer) {
		this.renderer = renderer;
		this.timeKeeper.maxDelta = 9;
		if (!logoImage) {
			const isSafari = navigator.userAgent.indexOf("Safari") > -1;
			const onload = () => loaded++;
			logoImage = new Image();
			logoImage.src = SPINE_LOGO_DATA;
			if (!isSafari) logoImage.crossOrigin = "anonymous";
			logoImage.onload = onload;
			spinnerImage = new Image();
			spinnerImage.src = SPINNER_DATA;
			if (!isSafari) spinnerImage.crossOrigin = "anonymous";
			spinnerImage.onload = onload;
		}
	}
	dispose() {
		this.logo?.dispose();
		this.spinner?.dispose();
	}
	draw(complete = false) {
		if (loaded < 2 || complete && this.fadeOut > FADE_OUT) return;
		this.timeKeeper.update();
		let a = Math.abs(Math.sin(this.timeKeeper.totalTime + .25));
		this.angle -= this.timeKeeper.delta * 200 * (1 + 1.5 * Math.pow(a, 5));
		const tempColor = this.tempColor;
		const renderer = this.renderer;
		const canvas = renderer.canvas;
		const gl = renderer.context.gl;
		renderer.resize(ResizeMode.Expand);
		renderer.camera.position.set(canvas.width / 2, canvas.height / 2, 0);
		renderer.batcher.setBlendMode(BlendMode.Normal);
		if (complete) {
			this.fadeOut += this.timeKeeper.delta * (this.timeKeeper.totalTime < 1 ? 2 : 1);
			if (this.fadeOut > FADE_OUT) return;
			tempColor.setFromColor(this.backgroundColor);
			a = 1 - this.fadeOut / FADE_OUT;
			a = 1 - (a - 1) * (a - 1);
			tempColor.a *= a;
			if (tempColor.a > 0) {
				renderer.camera.zoom = 1;
				renderer.begin();
				renderer.quad(true, 0, 0, canvas.width, 0, canvas.width, canvas.height, 0, canvas.height, tempColor, tempColor, tempColor, tempColor);
				renderer.end();
			}
		} else {
			this.fadeIn += this.timeKeeper.delta;
			if (this.backgroundColor.a > 0) {
				gl.clearColor(this.backgroundColor.r, this.backgroundColor.g, this.backgroundColor.b, this.backgroundColor.a);
				gl.clear(gl.COLOR_BUFFER_BIT);
			}
			a = 1;
		}
		a *= Math.min(this.fadeIn / FADE_IN, 1);
		tempColor.set(a, a, a, a);
		if (!this.logo) {
			this.logo = new GLTexture(renderer.context, logoImage, true);
			this.spinner = new GLTexture(renderer.context, spinnerImage, true);
		}
		renderer.camera.zoom = Math.max(1, spinnerSize / canvas.height);
		renderer.begin();
		renderer.drawTexture(this.logo, (canvas.width - logoWidth) / 2, (canvas.height - logoHeight) / 2, logoWidth, logoHeight, tempColor);
		if (this.spinner) renderer.drawTextureRotated(this.spinner, (canvas.width - spinnerSize) / 2, (canvas.height - spinnerSize) / 2, spinnerSize, spinnerSize, spinnerSize / 2, spinnerSize / 2, this.angle, tempColor);
		renderer.end();
	}
	drawInCoordinates(x, y) {
		if (loaded < 2) return;
		this.timeKeeper.update();
		const renderer = this.renderer;
		renderer.batcher.setBlendMode(BlendMode.Normal);
		if (!this.logo) {
			this.logo = new GLTexture(renderer.context, logoImage, true);
			this.spinner = new GLTexture(renderer.context, spinnerImage, true);
		}
		const shiftedX = x - logoWidth / 2;
		const shiftedY = y - logoHeight / 2;
		renderer.drawTexture(this.logo, shiftedX, shiftedY, logoWidth, logoHeight);
		this.angle -= this.timeKeeper.delta * 500;
		if (this.spinner) renderer.drawTextureRotated(this.spinner, shiftedX, shiftedY - 25, spinnerSize, spinnerSize, spinnerSize / 2, spinnerSize / 2, this.angle);
	}
};
var SPINNER_DATA = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKMAAACjCAYAAADmbK6AAAALKElEQVR42u2de2iW5R/GPzuqcwfnnKfNmafl5tTNHWzqNi3DEMQykcAoJSsySkspjSIk0iD/07Kf4R+FnVBDUTshZGpWUEJaaiWFgZlUFmXmIe3HNXthyebeZ77P9H13ffBG8Y8H7ut7vff93N/7fu4vGGPiFZiez/Qtw9lytJajfzfw9z/j+efPOv7cV8W+lUNY2a8T/ayTCRsWFLJA5rtUO1LLkV5p9LJeJizQiHeqnlOtmVFtdTGrrZkJCxYXsTgaI6r9MY4/UpNItW4mFDaXsTlaM6qVZlBq3UwofFrJp0HMWJ9DvXUzobCznJ1BzFjWlTLrZkJh/TDWBzFjTgo51s2EgnKI0Rrx+FiOWzNzVaym91Syx5qZsGBWb2ZFa0ZN6dbMhAWTcpkUrRmXD2K5NTNhgVbH0Zpxbl/mWjMTFvRIo0e0ZpzcncnWzISKtvmiMWNRJ4qslwmVXRXsas2Ix8ZwzFqZsGFREYtaM+Oaa1ljrUzYkJ9G/ok6TlzKjJWZVFor0y7c1Zu7WjLiqiGsskamXdHopyT4vALmzS9k/t19uHtKHlOSIMn6xAtARjIZ1sFcUSZ0Y4La+G6M18hS2IlCn4a+WoC0JNL0d/dUupdnUj40g6EJ2VEdMnhrOG/p5f/jUXz8SgmvaGU6KpNRNsLVQV0OdXf24s63h/P2gWoOrBjMCr2GJFQnnxnIM3q5P1PPmaYv+4ev4/C6UtbpV2gzXCkgL5W8Bwt48OIc6ul6Tp+s4+SyASxLiI4+PYCn1bHzDZxvaQW6vZzto7MYnQIpNkf7kp5EuozYUroqEjcNKHHd0Tl9mBPN1pk+hFeieGBnBtog7UXjsj9pWg+m6duecw2cay1OC/uxMC47KmP9OIYfoz1YoC20J/rzRG4quTZK2EAyJGs20qwUbYw0aNRmUxtvfUW/uEtNzc1NB1/X8LVyd15hh82F43AvD+VlXcsSJEZa1CQ3ejleAO7oxR3RDP0XN91X4+NXYb8nkv7UNTwV7e0YTdu7I3g33t7tuaEbNwSZpps2fSyvs4M2Tjhot+jb0Xzbltj8r5j/xVt/6Z1Ob93U1ZYO691EhhzchcHeXosVjcNZysyezLw4xRZt05R+fTeuj8vOj+zKyG0j2aZcVVs6v+QalnjrMFZASQYl2nBoSyz06e3j/Xk8rgWYmMvEICu2pm1HOTuc7okV8FgRj0XukwzanhvCc/F+72TjoQjdObN1OFuDLmh0xP+WHtxiI10ukJlCprb4guiv1fP+avZrS1C7NAkliHZjDtZwMMgqbukAltpMlwuMy2FcEBPqvfLLar5Uqi0hBdEwryy+Mv5n6zkbjTBa+dlMlwvUZFETZKGiFM7tvbhdJ3gSVRO0wzIjnxmvl/J6a6JsGMYGrahtpssFeqbR841S3mhN80OjOaSDEdqd6SjaMKgzgzRK7q1ib3PT9sYyNo7JZoyNFNvRcVMZmy7WOvIuryv/Zvdmdt90+nY0bRp3AvROohFwdwW7dTG7RFlbwlqdrbOBYg005NAQmZU0HWt1rXMBH1Xw0dQ8pmqzoaPmdhun7bHZjNVe9qP9eFQfO1VkUmHjhAVUZ1GtnKFSbjrkrPfy4i4UW5t/6ZxM54J0CqxFe81KpGsQyE4h23oYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjLna+bdOy+IiFquIpGq16Pb79cNYv3IIK/X/ugx+Ui6TVKvYVU9Nc8gX8od8Ir/IN/KPfCQ/yVfyl/6/pfJvLChkQdD6wyqntquCXYuKWJSfRr6D0dEAxV3xlw/khyD+kd/ku/88cHo+09tS3LBpO1HHCVUqcIA6CqB4K+6X6x35L/JM2loXurlWmUmlA5XogOIcK8/If5HncrSWo7F6cKIWPjT/RXGOlWfkv8hzaWsN4uaaysE6WIkOKM6x8oz8F3kusXqo2vxC5jtYiQ4ozrH0TeS5qIZcrB7qkrwdA8U5Vp6R/yLPZV8V+2L14Cl5THGwEh1QnGPlGfkv8lyUlIzFQ1cNYVVHrcjZ0VCcFe9Y+Eb+izy3ceclUl43aFN52DXXssYpnY6a4qFS8ZcP2uIf+e7inRh6pdFrdTGrm8uiHx/L8T2V7NGWzvJBLJ/bl7mTuzO5qBNFDoiJID/IF/KHfCK/yDfyT3O7d/KbfNfS80hNIrU0g9L6HOq1x5iTQo6FNpeLfCQ/yVfyl3xmXYwxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHNk9z4JwJ0SqKTdQkbyEwhU393T6V7zzR6pieR3tE1ITeVXImhe6BXDGZFdRbVeank2TBhcaEMr0rwbixj49IBLL2/L/ffmMuNHfqO9tFZjJYBd1ewO3Lx+IcVfKhqna5nHZYR6XFPH+5R3eeI5t9fx/fvjeC9Jdew5OKZKqFR/RDVKL6vL/f9PJafmyvHsL+a/ff24V6NmjZQbGchVbY6UM2BluqHv1rCqzVZ1KQlkZboepCdQvacPsz5bjTfXao+yMEaDt7Wk9tSIMVGig3TejCtJSM2bSpkPjWPqd1S6Zao+lORSYWmgkOjORRNwZqd5ezMSiHLRooNr5XwWjS6/1XHX9vL2T67N7M1iyXa9JCrYjVrS1gbpJyw6hBfsmiNCYT0P9/A+Wj1/6qGr5YNYFlJBiWJogEzezLz/ZG8/9s4fgtSyuvNYbyp1IONFBtu7sHNv4/j9yAxUHWrdaWsG9+N8XHd+YxkMpSy+aySz841cC5oXbmHCnnI74yxAgZ3YbDeB4PEQCOpBpFNZWwa2ZWRcdnxLsl00crtRB0n2lLg8JNRfDKoM4NsolgBSmw/UMADba1+qpmqfyf6x1u/0a/og3I+aEunP6/i86osqmygcGarF4p54dex/Bo0LqfqOfVwIQ/HW5/RSkwV1oN2WLlHTc82TljAwM4M1O5LWwYKZTjibYXNS0N5KcjKTe10PadfLObFuJwK4ozp+UzXDBTUjL+M5ZcBnRkQV53dMIwNQTu6bSTbVEzbi5awuVByd2E/FgaN0Tc1fKOzBHHV2aAdVSdv6s5NNkp7cSH/++xAng2yyHx+CM/H21YhfdPp+0U1X0TbSZnXx8faG9Aop0MS0cToh1p+iLcpOkLj9t/JOk5eqoPHxnDsyf486an5yqCDK7XZ1O4oZ4dWyy3FSXHUAYq47uyYbMZoGmhpG3DlEFb6uNiVBhpyaHhnBO8oJmfqOROJjzIiP43hJ8UxITqqX56S2Hur2KsOnq3nrE6PPNKPRwrSKbAZrjTQNZmuE7oxYXMZmxWbw9dxWFu4W4ezVedOE6qzI7oyYkY+M7TPeWsPbk2UX1qioSN+E3OZqOR2cReKE+qQRFN0Pi7y73g/UawU1KzezJpXwLz5hczX1ueUPKYkNb6GJQZ+j7/aAfRZREsv+quGsMoamXZBW2Gt5eU0alorEzYsKmJRa/m4NdeyxlqZsCGa84DKnVorEzboC7podis69DfIJmwufHMc7famvvmxZiYsKOtKWbRm1OcW1syEBboSJFozLh/EcmtmwgIluaM14/phrLdmJixYXMTiaM24p5I91syEBTphFOR7Y2tmwgJNvUFOr+tov3UzoaAv44KYUatv62ZCoemdhtG0+hzqrZsJBR08DWLG0gxKrZu50qvpxos3U5NItW4mFPp1ot+lPlpq2lYXs9qamVBZUMiC1ox4pJYjvlfStAu6GmTLcLboMtPIV4/6im5fFfuUi9QIap2MiWP+D96R1vPmsD/fAAAAAElFTkSuQmCC";
var SPINE_LOGO_DATA = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKUAAABsCAYAAAALzHKmAAAQ7klEQVR42u3da4xdVRUA4D0zd2Y6nZY59DVtZ1puS9+lzC0YAi2UQ8AAQczFpPgA9VIeIQbirRqJ0cBUBVGjDr/QCKSNRSMmpuODxAdxqhgwxkhFjf6Sxh/+UUNVNGJCzR7uTvas7LXX2q9zzp3em6y0gTN3Zu75utZe5+yztxC9V+/Ve5X9En1Vjd7J6SFbLNF7naPw+l2jh7YHMBWssqMHtlsRdim4qsLtIawaPiHEQOLoNrA9iIkQDnRrVA1qD2LZ8ISoxYqKo13sQAtBWBayQWZUAXGRQM9JjCngDVY0UqJNDbQrMcaGmArdUKpIjbYiQLsCZCyIMQBy8QwnilR4Q5AuCpxFYvRFmBLbEiwKwpsSaWycVQGZBKMrwBjA9BhxDe57u2L2hOoKNCbOrgAZitEVYUxoKSMErQvSxYIzCkguRg5EF4AUhqUlhy/YUKSxcRaKsioYOQhD4I0yYxkR3PcJBcuFysmgsXAWBTMJyBCMIQh9kGGxXIXvexCQXbHGAMrBWTbM2CCpMSMLIxehC77lSJwXGth7M0FzoVJIXXDWQnGmhOkL0ic7YhhtWdGGkAuPAjUWGoF4faCmwBkbZmyUqUCyMqMLRA4+E6IsdTjidUHKBYrh9CnpRcH0ypKxsyOGEYNIIeTCOz91OIJ1QYoB5eAMyZo+MFNnyVTZ0YiRC9EGEMOyAgshxErHsL2XK1gOUgwohtM1a5YNM7Rsu4K0ZkcbRm4mpPBRwFZ5hg9eCqkrUB+csWGGogzNkqEgrdnRhpGLkINudaLgwvVB6oqzCjCTZElb2Y4B0gUjBtEG0ARnDRLjjoG9DwcshtQGlIPTljVjwUySLWNkyRCQVHa0ZUUTRAwgF91a33BEy0VKAcVwwqwZC2bqbOlUurllOxQkJzNyINoAYqjWhYYjWg5SCiiG05Q1U8FMjTIoS8YE6YORi1BHtJ4KIcQEEtTXUWAxpK44YVlPBdO1jCdFWTZIE8bVGEYMIRPcZGBw4HKQcoBiOE1ZMzbMgVQwU6JMAdKEEcuIJogUvg1YCCE2gsCO42DlIIVAKZwpYJaSLVNnSU6XjYHUmxhTmXaFaMO3EYkLqMC+FsLlIoVAKZzMrEnBhJeLfLNlKMrYWRIDCbOkFSSVHbHM6AKRC6/ODUewNqQ+OLlZkxpjUmV8MBbMUJSxyzY3Q1IgTRgxiBRCHdem0KDAUkBh9sRwwjEnAXMMgTnKhFlUtiwkS5rGka4g9SaGgxFmRC7AzTCEEBcyA36dDSsXqAtOLkysjGMwY5XxVChjZ0kuSCo7YlkRQsQQYtDEFsegsLoCxUp7Kpgps2UslFGzJGccSYHUmxhOZqwzEZqAbfUMCisHKIZzgsCpl3MTzMwTpi1bYp2477gyFKUxS7qWbdjY2EBS2dGE0QQRA7gNCyHEdhjE8RhUDlBT9tzgmjWZMFNlSy+Urk1OzCyJlW0XkK4YOQh1cDtcgwBrQmoDWkdgboBZE8mYsJSHlnFbJ+5bwmOPJ7lZkirbC8aRsMvmgtTHjBhGE0QbwJ2egUE1ITVlUC5OmDVdYNrKuN70xM6WoShjlW4464dbtiFIWK6x7GjESEHUUe0iYncnbMdQSE0Z1ITTNOb0hRmjjLtmS9dmJ2rp1jtuKktyyrb6YLEMCUHq2dGG0QQRQ7f72kzc+cJecerne8Wvv7JNPHPvenEkz8Sh3UtFc92QyGt9Yko/HgOLAIUZlItTz5ouMF3KuE+2jFLCQ1D6lm6fLMkBacuOJowYRBUXyfjuHjF3NhdnsfjvAfH6E9vFt9XxKgikEKgJZyyYalzOLeMu2bLbULI6bh+QGwmQ+rgRlumdGEQAao+K56bEL2woVUwOiev0r8OAUjiJrMmFCbvykGxZRAmPitK1dHM7bohyMsuyi/I8f0+e57fJYIKEZXpXo9E4mOf5XTKyLLvCBLETF8uY2SKepkC+dpX4T02Ivepr4HvZcOZ5fmee54fyPL+DmTUhzAs6n4n8bN5dr9f3YdkSg8nsxG0lPBVKVpNjG0/aGhzfLDmRZdnumZmZp8+c+cdZPV555fSr7Xb7s0jJ3i5Pcue4MxKkPPkvvXTqz/B92u32l0wYOzG1fkhcd/py8Rcbyq/vFM/KY1WA95h/3zzP71bfU6JsNpsfgj+P/FlbrdaDGExYyuXvLz8H+DudODH700ajcSM3W6Yu4alQ1spCOTd38jcKocTZbh9+9NixY99XJ8AEUkcpo9W64yH197m5k7+bnZ19QT+J09NHntQhwji/Jg58qi6++ofLxJ8gSFneVw2Ka4QQDfh1Ok4dZavVmtZ/nrm5k7/Vf55O1tRhboUw5+ZOvqyOl5+R/FyOHj32PYVU/tloNG5IXcKrhJIzngwp3fNjomazea/64BuNxts646f50lWv169utw9/DmtqdJQyZFaSJVuV6nq9fqMEof5/vV6/CYBqgJDlee+yAbF/+4i4ZWqZeNfaIfHWzn+Hx0KcEuU9+s8jv3ej0bhVlXOZydX/k0iRMeb8P0D5e6tj8zy/Xb9UJIc56h/yqVOnXul8lmuZ2bJslKmbHG7XrbpCmCXFRLvdfqQD6jTS3Jiy5I4OykM6ADV+1Eu1DmV6evopBORexzDi1L+X/HnGxsb2w3Hm9PSRJ9QxWPOTZdmlKht2hi+w6dkox5bqffI8fye3hDteGqKaHVsHXihKl0tB+h0cY+lute54AGRKDCW89LNTRynHb7ChUWVVjetOnJh9EYBUyPZeNCoOtsbFQwdXi4/esELcd+tq8cCHJ8UXp+viy9efLz7AgamjlKXc1AA1m83DoIRDlFubzeb96hhZLVTlgJ24gttutx+ONa50bHZKRenaeTs1OfpAfnr6yOOdE7EZdNwmlKocntXLNkA5JTGq47Ds+Lf94lWsyfnXleLfnIwJUN4DOnNYwuUxh2A3Ln9XULrfK8t3J27Tu3BVwiOjXJqoAy8UZej1yclGo3GTLN+gu3w+z/P3YaWbQqk3Ne12e4ZC+c8rxWsYytcPiP9RpZxCqWDKnxOiBNlyAUpOnGsoh4tA2Rm8X9xqtT6md5wyZmYe+0YRKL+1S/wYQ3n8zctBl5SBUv5djivfjMOPduIzcizeiYfr9foVvUwZG+XCuzibZKnSceZ5/v4QlKp8y7ElhnJlTeTP7BI/kllRYfzrfvHqFy4UX1vaL/aVlSmROzwbwdS29T2UcEwZF+V8ozM2lu1VY812u/15akypGh3TmFJesJbHHD167IdUxz3YJy5bNySuX1mbvy55CbMLtzU6tjGlsdFptVqfUMc0Go23F4wy1l2dSnbfvpMwVPe9WWVLDsrOJaF9MFu2Wq1PqmNkGce67xiXhTjdNwdlvV6/BgxfbPfBfVCetxi6b9/rlCup65QzM48dl2OjLMv26CibzeZ96sTIzEFdpwQXz9U1yrtVlpR/Zll2Fec65Y6l4pbbx8XHH9kknvzJlPjlHy8Tp29eKT5ou0aJoIT3w3dBlLDzVpfAJEZ1XOdaJZxnOSlvPMjPzxFljIvng914RwebsjYO7uhMyHu46sOfnf3Oz2TXDW6vvYxdFoIXz3Wc8J5zs9n8iOn2IrxTc2BM3Glqdp7dI553uaOjxrhwcob+MyuUpjs6WZZdon8OcigjPx8V+u+GTWFTSWEx3WYcdJ225jNDSE4q0GHCzlueHOyujn6bUWYgeb9ZZUaQPe+GzQ+Gc8+oOGhC+c1d4gfI16n3XDAhQ7+9qE9l01E2Go132GYKyXE1NiFDTcpoNpv3LOYJGWXNErJNW9sEp63p2RKiVPMn1bS1DgxsyhoGdGpmizj+xtXiDYnx7/vFmce3iWdW1cTVGEY4hQ2ZW0nNq8Qm/M6XbXm3S100lwGedFybuvNOibLI+ZS2ceU4eAxiEuvCkfmU8ycToDxETe6FgCBQHeqyAbFvfEhcO7BwDuXFCEbTZF840XeHK0jYcbs2OIGle0mVJ/mmnClEPQqxyTY5I8/zFhif7fSZee4bnrPOU4AssnRXHaVTCTd14dRDY3UbTIiSeFhsN/aMjgnqthFx880rxX3yATL5p3y4LPXzOaBkUyBjZMlYpbtQlIOBD475ZEusjMNSvkXe6VEoJVDkeZ2dzIfIFsRzU+JF2OyM9M9fTC/6SUYOyFQPjQ2nWiUjxnPfw5EeHqMWIqAeIFsAU847lJM2JM6xsewt1OIDLs99P7ZFHNdB/upS8XtPiD7PfLuCXJNolYyyFiNI/Zit65ItrOVafFbHcFohY7hPTN21Tjz4uc3iqfsnxKdX1MTl1OoYRFaMsToGB6Trw2JFP/OdZC2hJZ7ZkrMoAbbSGmelDJ91hFKuJeS7jlBMkJnrAqqJlgMUZS/dArPlGHNdSg5M3xXXtvquuEatvIYtDRhpxbUJuIgqsU5lGWtUploK0KuEU9mSW8YpmFQ556xNuYW7NiW13B+FkMiKHIy+C6eGgBxJvMR0oSv5hi6+z4HJyZoU0M2RVvDlrOQbcxVfX5AhZbuqy0v7ZstYMLHlAVlLTF9ALLbvu9Y5Zylpn/XOsd0ibIvxr2KCLHpp6SCUIdnSZSF+WzfOhem6GD+1KwR3Z4jNjrtDpNoZwmWd8yrupZN6Hx3fbMmFSe0Swdq2ZIPjxk1112Duo8OBGLrBkw/IoncdK2XHsdC9dHz204m50xh3tzFq1zFqtzHXrfCw7OgDsqyNnZLszVijsmXgrmNcmGtS78lIoMX2aJz03fKO2sDJddPQSCDPiQ1DfWBycY6XtXstc2PQKuxgG2McmXTPb9/9vmuJYXKyJrWjbeg+3xPM4O73nWqvbyw7xgZZSJbEUBa157cNJjdr2vb+5iA1YV3HxYscj30PDCEHIgcjtfm8K8hSsmRotkwFk5s1TTghUAopB6xrjHMBBkI0YYTZ0dZlxwLpkiWDULpmy5gwqayZgZNkA7oKQQCxctByYg0XIIEQQuRitGVHblMTA2ShKGPDpC6wu+DEgJqg2rDGDBtAF4Q6RAojp1xXGmSMbImVcR+YWNY04eQCtUG1ofUJ2/uvcETIgUhhdAE5GAlkKShjwHTNmhhODKgJqQ2sC14uOgyfD0IbRF+MlQaZAiZWyn2yJsTJATqGnHQO2Jhh+xlsACFCG0QbRtdyzQFZCZSxYPpmTS7Q5cjJHYNBYIkZpu99HoUQ/o4QIYSIZUZfjJ4ZMjZI32wZBDMU5yhy8pZTULl4XYP5fagMyEVoy4oupTpGduwnkloSlKEwY+AcQU4MhRTD6ovXBRwFzwWgCSEF0QVjJUGmgEllTS5OLlCIlIN1mS9mx/cZ5eLDALpCTI2RAhkTZQqYoTgpoCPECbaBHQ2ETL3PUl98ECAXYijG0OyYAmQoTG7W5ODkAF1CnVgm2JQx4okPA+gCMTbGskBGgRmaOblAh5GTORIrfKFx4VH4EIAxIXIxlg2SBbMvECY3e7oApbDaIgQu5/2HmeEKEINYiwSRi7EQkLFgumZOCuggctKGI4ULZN/vMeSLj0AYMytWEqMLzFg4fYDaoKaC6wvOFR4FkIPQFaILxrJAOsHsc/zlfYDWXE8qF22s8Pz5KHxcgEVALBtjJXBSSEOwFhk1Zgy4hitCT4hVw+gFs8/zwxqIBbUgyK7fcyA0PD9XX4iVxhiC0xdof6STWCsoBmKF7+cVCWFXQYyBMxRpf+STX1b0x45AhN0OMSrOGEirhrY/dfQAdjvS7oy+WCF6r1RIFxXWvlTRg1YVqFWBmxZbD99ig9pt0YPQw9rD1nstVri9V+/Ve3XrS/wfim4P5fIFxLoAAAAASUVORK5CYII=";
//#endregion
//#region node_modules/@esotericsoftware/spine-player/dist/Player.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var SpinePlayer = class {
	config;
	parent;
	dom;
	canvas = null;
	context = null;
	sceneRenderer = null;
	loadingScreen = null;
	assetManager = null;
	bg = new Color();
	bgFullscreen = new Color();
	playerControls = null;
	timelineSlider = null;
	playButton = null;
	skinButton = null;
	pinnedSkins = /* @__PURE__ */ new Set();
	animationButton = null;
	playTime = 0;
	selectedBones = [];
	cancelId = 0;
	popup = null;
	error = false;
	skeleton = null;
	animationState = null;
	paused = true;
	speed = 1;
	time = new TimeKeeper();
	stopRequestAnimationFrame = false;
	disposed = false;
	viewport = {};
	currentViewport = {};
	previousViewport = {};
	viewportTransitionStart = 0;
	eventListeners = [];
	input;
	constructor(parent, config) {
		this.config = config;
		const parentDom = typeof parent === "string" ? document.getElementById(parent) : parent;
		if (parentDom == null) throw new Error(`SpinePlayer parent not found: ${parent}`);
		this.parent = parentDom;
		if (config.showControls === void 0) config.showControls = true;
		const controls = config.showControls ? `
<div class="spine-player-controls spine-player-popup-parent spine-player-controls-hidden">
<div class="spine-player-timeline"></div>
<div class="spine-player-buttons">
<button class="spine-player-button spine-player-button-icon-pause"></button>
<div class="spine-player-button-spacer"></div>
<button class="spine-player-button spine-player-button-icon-speed"></button>
<button class="spine-player-button spine-player-button-icon-animations"></button>
<button class="spine-player-button spine-player-button-icon-skins"></button>
<button class="spine-player-button spine-player-button-icon-settings"></button>
<button class="spine-player-button spine-player-button-icon-fullscreen"></button>
<img class="spine-player-button-icon-spine-logo" src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20104%2031.16%22%3E%3Cpath%20d%3D%22M104%2012.68a1.31%201.31%200%200%201-.37%201%201.28%201.28%200%200%201-.85.31H91.57a10.51%2010.51%200%200%200%20.29%202.55%204.92%204.92%200%200%200%201%202%204.27%204.27%200%200%200%201.64%201.26%206.89%206.89%200%200%200%202.6.44%2010.66%2010.66%200%200%200%202.17-.2%2012.81%2012.81%200%200%200%201.64-.44q.69-.25%201.14-.44a1.87%201.87%200%200%201%20.68-.2.44.44%200%200%201%20.27.04.43.43%200%200%201%20.16.2%201.38%201.38%200%200%201%20.09.37%204.89%204.89%200%200%201%200%20.58%204.14%204.14%200%200%201%200%20.43v.32a.83.83%200%200%201-.09.26%201.1%201.1%200%200%201-.17.22%202.77%202.77%200%200%201-.61.34%208.94%208.94%200%200%201-1.32.46%2018.54%2018.54%200%200%201-1.88.41%2013.78%2013.78%200%200%201-2.28.18%2010.55%2010.55%200%200%201-3.68-.59%206.82%206.82%200%200%201-2.66-1.74%207.44%207.44%200%200%201-1.63-2.89%2013.48%2013.48%200%200%201-.55-4%2012.76%2012.76%200%200%201%20.57-3.94%208.35%208.35%200%200%201%201.64-3%207.15%207.15%200%200%201%202.58-1.87%208.47%208.47%200%200%201%203.39-.65%208.19%208.19%200%200%201%203.41.64%206.46%206.46%200%200%201%202.32%201.73%207%207%200%200%201%201.3%202.54%2011.17%2011.17%200%200%201%20.43%203.13zm-3.14-.93a5.69%205.69%200%200%200-1.09-3.86%204.17%204.17%200%200%200-3.42-1.4%204.52%204.52%200%200%200-2%20.44%204.41%204.41%200%200%200-1.47%201.15A5.29%205.29%200%200%200%2092%209.75a7%207%200%200%200-.36%202zM80.68%2021.94a.42.42%200%200%201-.08.26.59.59%200%200%201-.25.18%201.74%201.74%200%200%201-.47.11%206.31%206.31%200%200%201-.76%200%206.5%206.5%200%200%201-.78%200%201.74%201.74%200%200%201-.47-.11.59.59%200%200%201-.25-.18.42.42%200%200%201-.08-.26V12a9.8%209.8%200%200%200-.23-2.35%204.86%204.86%200%200%200-.66-1.53%202.88%202.88%200%200%200-1.13-1%203.57%203.57%200%200%200-1.6-.34%204%204%200%200%200-2.35.83A12.71%2012.71%200%200%200%2069.11%2010v11.9a.42.42%200%200%201-.08.26.59.59%200%200%201-.25.18%201.74%201.74%200%200%201-.47.11%206.51%206.51%200%200%201-.78%200%206.31%206.31%200%200%201-.76%200%201.88%201.88%200%200%201-.48-.11.52.52%200%200%201-.25-.18.46.46%200%200%201-.07-.26v-17a.53.53%200%200%201%20.03-.21.5.5%200%200%201%20.23-.19%201.28%201.28%200%200%201%20.44-.11%208.53%208.53%200%200%201%201.39%200%201.12%201.12%200%200%201%20.43.11.6.6%200%200%201%20.22.19.47.47%200%200%201%20.07.26V7.2a10.46%2010.46%200%200%201%202.87-2.36%206.17%206.17%200%200%201%202.88-.75%206.41%206.41%200%200%201%202.87.58%205.16%205.16%200%200%201%201.88%201.54%206.15%206.15%200%200%201%201%202.26%2013.46%2013.46%200%200%201%20.31%203.11z%22%20fill%3D%22%23fff%22%2F%3E%3Cpath%20d%3D%22M43.35%202.86c.09%202.6%201.89%204%205.48%204.61%203%20.48%205.79.24%206.69-2.37%201.75-5.09-2.4-3.82-6-4.39s-6.31-2.03-6.17%202.15zm1.08%2010.69c.33%201.94%202.14%203.06%204.91%203s4.84-1.16%205.13-3.25c.53-3.88-2.53-2.38-5.3-2.3s-5.4-1.26-4.74%202.55zM48%2022.44c.55%201.45%202.06%202.06%204.1%201.63s3.45-1.11%203.33-2.76c-.21-3.06-2.22-2.1-4.26-1.66S47%2019.6%2048%2022.44zm1.78%206.78c.16%201.22%201.22%202%202.88%201.93s2.92-.67%203.13-2c.4-2.43-1.46-1.53-3.12-1.51s-3.17-.82-2.89%201.58z%22%20fill%3D%22%23ff4000%22%2F%3E%3Cpath%20d%3D%22M35.28%2013.16a15.33%2015.33%200%200%201-.48%204%208.75%208.75%200%200%201-1.42%203%206.35%206.35%200%200%201-2.32%201.91%207.14%207.14%200%200%201-3.16.67%206.1%206.1%200%200%201-1.4-.15%205.34%205.34%200%200%201-1.26-.47%207.29%207.29%200%200%201-1.24-.81q-.61-.49-1.29-1.15v8.51a.47.47%200%200%201-.08.26.56.56%200%200%201-.25.19%201.74%201.74%200%200%201-.47.11%206.47%206.47%200%200%201-.78%200%206.26%206.26%200%200%201-.76%200%201.89%201.89%200%200%201-.48-.11.49.49%200%200%201-.25-.19.51.51%200%200%201-.07-.26V4.91a.57.57%200%200%201%20.06-.27.46.46%200%200%201%20.23-.18%201.47%201.47%200%200%201%20.44-.1%207.41%207.41%200%200%201%201.3%200%201.45%201.45%200%200%201%20.43.1.52.52%200%200%201%20.24.18.51.51%200%200%201%20.07.27V7.2a18.06%2018.06%200%200%201%201.49-1.38%209%209%200%200%201%201.45-1%206.82%206.82%200%200%201%201.49-.59%207.09%207.09%200%200%201%204.78.52%206%206%200%200%201%202.13%202%208.79%208.79%200%200%201%201.2%202.9%2015.72%2015.72%200%200%201%20.4%203.51zm-3.28.36a15.64%2015.64%200%200%200-.2-2.53%207.32%207.32%200%200%200-.69-2.17%204.06%204.06%200%200%200-1.3-1.51%203.49%203.49%200%200%200-2-.57%204.1%204.1%200%200%200-1.2.18%204.92%204.92%200%200%200-1.2.57%208.54%208.54%200%200%200-1.28%201A15.77%2015.77%200%200%200%2022.76%2010v6.77a13.53%2013.53%200%200%200%202.46%202.4%204.12%204.12%200%200%200%202.44.83%203.56%203.56%200%200%200%202-.57A4.28%204.28%200%200%200%2031%2018a7.58%207.58%200%200%200%20.77-2.12%2011.43%2011.43%200%200%200%20.23-2.36zM12%2017.3a5.39%205.39%200%200%201-.48%202.33%204.73%204.73%200%200%201-1.37%201.72%206.19%206.19%200%200%201-2.12%201.06%209.62%209.62%200%200%201-2.71.36%2010.38%2010.38%200%200%201-3.21-.5A7.63%207.63%200%200%201%201%2021.82a3.25%203.25%200%200%201-.66-.43%201.09%201.09%200%200%201-.3-.53%203.59%203.59%200%200%201-.04-.93%204.06%204.06%200%200%201%200-.61%202%202%200%200%201%20.09-.4.42.42%200%200%201%20.16-.22.43.43%200%200%201%20.24-.07%201.35%201.35%200%200%201%20.61.26q.41.26%201%20.56a9.22%209.22%200%200%200%201.41.55%206.25%206.25%200%200%200%201.87.26%205.62%205.62%200%200%200%201.44-.17%203.48%203.48%200%200%200%201.12-.5%202.23%202.23%200%200%200%20.73-.84%202.68%202.68%200%200%200%20.26-1.21%202%202%200%200%200-.37-1.21%203.55%203.55%200%200%200-1-.87%208.09%208.09%200%200%200-1.36-.66l-1.56-.61a16%2016%200%200%201-1.57-.73%206%206%200%200%201-1.37-1%204.52%204.52%200%200%201-1-1.4%204.69%204.69%200%200%201-.37-2%204.88%204.88%200%200%201%20.39-1.87%204.46%204.46%200%200%201%201.16-1.61%205.83%205.83%200%200%201%201.94-1.11A8.06%208.06%200%200%201%206.53%204a8.28%208.28%200%200%201%201.36.11%209.36%209.36%200%200%201%201.23.28%205.92%205.92%200%200%201%20.94.37%204.09%204.09%200%200%201%20.59.35%201%201%200%200%201%20.26.26.83.83%200%200%201%20.09.26%201.32%201.32%200%200%200%20.06.35%203.87%203.87%200%200%201%200%20.51%204.76%204.76%200%200%201%200%20.56%201.39%201.39%200%200%201-.09.39.5.5%200%200%201-.16.22.35.35%200%200%201-.21.07%201%201%200%200%201-.49-.21%207%207%200%200%200-.83-.44%209.26%209.26%200%200%200-1.2-.44%205.49%205.49%200%200%200-1.58-.16%204.93%204.93%200%200%200-1.4.18%202.69%202.69%200%200%200-1%20.51%202.16%202.16%200%200%200-.59.83%202.43%202.43%200%200%200-.2%201%202%202%200%200%200%20.38%201.24%203.6%203.6%200%200%200%201%20.88%208.25%208.25%200%200%200%201.38.68l1.58.62q.8.32%201.59.72a6%206%200%200%201%201.39%201%204.37%204.37%200%200%201%201%201.36%204.46%204.46%200%200%201%20.37%201.8z%22%20fill%3D%22%23fff%22%2F%3E%3C%2Fsvg%3E">
</div></div>` : "";
		this.parent.appendChild(this.dom = createElement(`<div class="spine-player" style="position:relative;height:100%"><canvas class="spine-player-canvas" style="display:block;width:100%;height:100%"></canvas>${controls}</div>`));
		try {
			this.validateConfig(config);
		} catch (e) {
			this.showError(e.message, e);
		}
		this.initialize();
		this.addEventListener(window, "resize", () => this.drawFrame(false));
		requestAnimationFrame(() => this.drawFrame());
	}
	dispose() {
		this.sceneRenderer?.dispose();
		this.loadingScreen?.dispose();
		this.assetManager?.dispose();
		this.context?.dispose();
		for (let i = 0; i < this.eventListeners.length; i++) {
			const eventListener = this.eventListeners[i];
			eventListener.target.removeEventListener(eventListener.event, eventListener.func);
		}
		this.input?.dispose();
		if (this.canvas) {
			this.canvas.width = 0;
			this.canvas.height = 0;
		}
		this.parent.removeChild(this.dom);
		this.disposed = true;
	}
	addEventListener(target, event, func) {
		this.eventListeners.push({
			target,
			event,
			func
		});
		target.addEventListener(event, func);
	}
	validateConfig(config) {
		if (!config) throw new Error("A configuration object must be passed to to new SpinePlayer().");
		if (config.skelUrl) config.skeleton = config.skelUrl;
		if (!config.skeleton) throw new Error("A URL must be specified for the skeleton JSON or binary file.");
		if (!config.scale) config.scale = 1;
		if (!config.atlas && !config.atlasUrl) throw new Error("A URL must be specified for the atlas file.");
		if (config.atlasUrl && !config.atlas) config.atlas = config.atlasUrl;
		if (!config.backgroundColor) config.backgroundColor = config.alpha ? "00000000" : "000000";
		if (!config.fullScreenBackgroundColor) config.fullScreenBackgroundColor = config.backgroundColor;
		if (config.backgroundImage && !config.backgroundImage.url) config.backgroundImage = void 0;
		if (config.preserveDrawingBuffer === void 0) config.preserveDrawingBuffer = false;
		if (config.mipmaps === void 0) config.mipmaps = true;
		if (config.interactive === void 0) config.interactive = true;
		if (typeof config.debug !== "object") {
			const d = !!config.debug;
			config.debug = {
				bones: d,
				regions: d,
				meshes: d,
				bounds: d,
				paths: d,
				clipping: d,
				points: d,
				hulls: d
			};
		}
		if (config.animations && config.animation && config.animations.indexOf(config.animation) < 0) throw new Error(`Animation '${config.animation}' is not in the config animation list: ${print(config.animations)}`);
		if (config.skin) {
			if (!Array.isArray(config.skin)) config.skin = [config.skin];
			if (config.skins) {
				for (const s of config.skin) if (config.skins.indexOf(s) < 0) throw new Error(`Default skin '${s}' is not in the config skins list: ${print(config.skins)}`);
			}
		}
		if (!config.viewport) config.viewport = {};
		if (!config.viewport.animations) config.viewport.animations = {};
		if (config.viewport.debugRender === void 0) config.viewport.debugRender = false;
		if (config.viewport.transitionTime === void 0) config.viewport.transitionTime = .25;
		if (!config.controlBones) config.controlBones = [];
		if (config.showLoading === void 0) config.showLoading = true;
		if (config.defaultMix === void 0) config.defaultMix = .25;
	}
	initialize() {
		const config = this.config;
		const dom = this.dom;
		if (!config.alpha) {
			const hex = config.backgroundColor;
			this.dom.style.backgroundColor = (hex.charAt(0) === "#" ? hex : `#${hex}`).substring(0, 7);
		}
		try {
			this.canvas = findWithClass(dom, "spine-player-canvas");
			this.context = new ManagedWebGLRenderingContext(this.canvas, {
				alpha: config.alpha,
				preserveDrawingBuffer: config.preserveDrawingBuffer
			});
			this.sceneRenderer = new SceneRenderer(this.canvas, this.context, true);
			if (config.showLoading) this.loadingScreen = new LoadingScreen(this.sceneRenderer);
		} catch (e) {
			this.showError("Sorry, your browser does not support WebGL, or you have disabled WebGL in your browser settings.\nPlease use the latest version of Firefox, Chrome, Edge, or Safari.", e);
			return null;
		}
		this.assetManager = new AssetManager(this.context, "", config.downloader);
		if (config.rawDataURIs) for (const path in config.rawDataURIs) this.assetManager.setRawDataURI(path, config.rawDataURIs[path]);
		if (config.skeleton.endsWith(".json")) this.assetManager.loadJson(config.skeleton);
		else this.assetManager.loadBinary(config.skeleton);
		this.assetManager.loadTextureAtlas(config.atlas);
		if (config.backgroundImage) this.assetManager.loadTexture(config.backgroundImage.url);
		this.bg.setFromString(config.backgroundColor);
		this.bgFullscreen.setFromString(config.fullScreenBackgroundColor);
		if (config.showControls) {
			this.playerControls = dom.children[1];
			const controls = this.playerControls.children;
			const timeline = controls[0];
			const buttons = controls[1].children;
			this.playButton = buttons[0];
			const speedButton = buttons[2];
			this.animationButton = buttons[3];
			this.skinButton = buttons[4];
			const settingsButton = buttons[5];
			const fullscreenButton = buttons[6];
			const logoButton = buttons[7];
			this.timelineSlider = new Slider();
			timeline.appendChild(this.timelineSlider.create());
			this.timelineSlider.change = (percentage) => {
				this.pause();
				const time = this.animationState.getTrack(0).animation.duration * percentage;
				this.animationState.update(time - this.playTime);
				this.animationState.apply(this.skeleton);
				this.skeleton.update(time - this.playTime);
				this.skeleton.updateWorldTransform(Physics.update);
				this.playTime = time;
			};
			this.playButton.onclick = () => this.paused ? this.play() : this.pause();
			speedButton.onclick = () => this.showSpeedDialog(speedButton);
			this.animationButton.onclick = () => this.showAnimationsDialog(this.animationButton);
			this.skinButton.onclick = () => this.showSkinsDialog(this.skinButton);
			settingsButton.onclick = () => this.showSettingsDialog(settingsButton);
			let oldWidth = this.canvas.clientWidth, oldHeight = this.canvas.clientHeight;
			let oldStyleWidth = this.canvas.style.width, oldStyleHeight = this.canvas.style.height;
			let isFullscreen = false;
			fullscreenButton.onclick = () => {
				const fullscreenChanged = () => {
					isFullscreen = !isFullscreen;
					if (!isFullscreen) {
						this.canvas.style.width = `${oldWidth}px`;
						this.canvas.style.height = `${oldHeight}px`;
						this.drawFrame(false);
						requestAnimationFrame(() => {
							this.canvas.style.width = oldStyleWidth;
							this.canvas.style.height = oldStyleHeight;
						});
					}
				};
				const player = dom;
				player.onfullscreenchange = fullscreenChanged;
				player.onwebkitfullscreenchange = fullscreenChanged;
				const doc = document;
				if (doc.fullscreenElement || doc.webkitFullscreenElement || doc.mozFullScreenElement || doc.msFullscreenElement) {
					if (doc.exitFullscreen) doc.exitFullscreen();
					else if (doc.mozCancelFullScreen) doc.mozCancelFullScreen();
					else if (doc.webkitExitFullscreen) doc.webkitExitFullscreen();
					else if (doc.msExitFullscreen) doc.msExitFullscreen();
				} else {
					oldWidth = this.canvas.clientWidth;
					oldHeight = this.canvas.clientHeight;
					oldStyleWidth = this.canvas.style.width;
					oldStyleHeight = this.canvas.style.height;
					if (player.requestFullscreen) player.requestFullscreen();
					else if (player.webkitRequestFullScreen) player.webkitRequestFullScreen();
					else if (player.mozRequestFullScreen) player.mozRequestFullScreen();
					else if (player.msRequestFullscreen) player.msRequestFullscreen();
				}
			};
			logoButton.onclick = () => window.open("http://esotericsoftware.com");
		}
		return dom;
	}
	loadSkeleton() {
		if (this.error) return;
		if (this.assetManager.hasErrors()) this.showError(`Error: Assets could not be loaded.\n${print(this.assetManager.getErrors())}`);
		const config = this.config;
		const atlas = this.assetManager.require(config.atlas);
		const gl = this.context.gl, anisotropic = gl.getExtension("EXT_texture_filter_anisotropic");
		const isWebGL1 = gl.getParameter(gl.VERSION).indexOf("WebGL 1.0") !== -1;
		for (const page of atlas.pages) {
			let minFilter = page.minFilter;
			let useMipMaps = config.mipmaps;
			const isPOT = MathUtils.isPowerOfTwo(page.width) && MathUtils.isPowerOfTwo(page.height);
			if (isWebGL1 && !isPOT) useMipMaps = false;
			if (useMipMaps) {
				if (anisotropic) {
					gl.texParameterf(gl.TEXTURE_2D, anisotropic.TEXTURE_MAX_ANISOTROPY_EXT, 8);
					minFilter = TextureFilter.MipMapLinearLinear;
				} else minFilter = TextureFilter.Linear;
				page.texture.setFilters(minFilter, TextureFilter.Nearest);
			}
			if (minFilter !== TextureFilter.Nearest && minFilter !== TextureFilter.Linear) page.texture.update(true);
		}
		let skeletonData;
		try {
			let loader, data, attachmentLoader = new AtlasAttachmentLoader(atlas);
			if (config.skeleton.endsWith(".json")) {
				data = this.assetManager.remove(config.skeleton);
				if (!data) throw new Error("Empty JSON data.");
				if (config.jsonField) {
					data = data[config.jsonField];
					if (!data) throw new Error(`JSON field does not exist: ${config.jsonField}`);
				}
				loader = new SkeletonJson(attachmentLoader);
			} else {
				data = this.assetManager.remove(config.skeleton);
				loader = new SkeletonBinary(attachmentLoader);
			}
			loader.scale = config.scale;
			skeletonData = loader.readSkeletonData(data);
		} catch (e) {
			this.showError(`Error: Could not load skeleton data.\n${e.message}`, e);
			return;
		}
		this.skeleton = new Skeleton(skeletonData);
		const stateData = new AnimationStateData(skeletonData);
		stateData.defaultMix = config.defaultMix;
		this.animationState = new AnimationState(stateData);
		config.controlBones.forEach((bone) => {
			if (!skeletonData.findBone(bone)) this.showError(`Error: Control bone does not exist in skeleton: ${bone}`);
		});
		if ((!config.skin || !config.skin.length) && skeletonData.skins.length) config.skin = [skeletonData.skins[0].name];
		if (config.skins && config.skin.length) config.skins.forEach((skin) => {
			if (!this.skeleton.data.findSkin(skin)) this.showError(`Error: Skin in config list does not exist in skeleton: ${skin}`);
		});
		const skinList = config.skin;
		if (skinList?.length) {
			for (const s of skinList) {
				if (!this.skeleton.data.findSkin(s)) this.showError(`Error: Skin does not exist in skeleton: ${s}`);
				if (this.skeleton.data.findSkin(s) !== this.skeleton.data.defaultSkin) this.pinnedSkins.add(s);
			}
			this.applyCombinedSkin();
		}
		Object.getOwnPropertyNames(config.viewport.animations).forEach((animation) => {
			if (!skeletonData.findAnimation(animation)) this.showError(`Error: Animation for which a viewport was specified does not exist in skeleton: ${animation}`);
		});
		if (config.animations && config.animations.length) {
			config.animations.forEach((animation) => {
				if (!this.skeleton.data.findAnimation(animation)) this.showError(`Error: Animation in config list does not exist in skeleton: ${animation}`);
			});
			if (!config.animation) config.animation = config.animations[0];
		}
		if (config.animation && !skeletonData.findAnimation(config.animation)) this.showError(`Error: Animation does not exist in skeleton: ${config.animation}`);
		this.setupInput();
		if (config.showControls) {
			if (skeletonData.skins.length === 1 || config.skins && config.skins.length === 1) this.skinButton.classList.add("spine-player-hidden");
			if (skeletonData.animations.length === 1 || config.animations && config.animations.length === 1) this.animationButton.classList.add("spine-player-hidden");
		}
		if (config.success) config.success(this);
		let entry = this.animationState.getTrack(0);
		if (!entry) {
			if (config.animation) {
				entry = this.setAnimation(config.animation);
				this.play();
			} else {
				entry = this.animationState.setEmptyAnimation(0);
				entry.trackEnd = 1e8;
				this.skeleton.updateWorldTransform(Physics.update);
				this.setViewport(entry.animation);
				this.pause();
			}
		} else {
			if (this.currentViewport.x === void 0) this.setViewport(entry.animation);
			if (!config.animation) config.animation = entry.animation?.name;
			this.play();
		}
	}
	setupInput() {
		const config = this.config;
		const controlBones = config.controlBones;
		if (!controlBones.length && !config.showControls) return;
		const selectedBones = this.selectedBones = new Array(controlBones.length);
		const canvas = this.canvas;
		let target = null;
		const offset = new Vector2();
		const coords = new Vector3();
		const mouse = new Vector3();
		const position = new Vector2();
		const skeleton = this.skeleton;
		const renderer = this.sceneRenderer;
		if (config.interactive) {
			const closest = (x, y) => {
				mouse.set(x, canvas.clientHeight - y, 0);
				offset.x = offset.y = 0;
				let bestDistance = 24, index = 0;
				let best = null;
				for (let i = 0; i < controlBones.length; i++) {
					selectedBones[i] = null;
					const bone = skeleton.findBone(controlBones[i]);
					if (!bone) continue;
					const distance = renderer.camera.worldToScreen(coords.set(bone.appliedPose.worldX, bone.appliedPose.worldY, 0), canvas.clientWidth, canvas.clientHeight).distance(mouse);
					if (distance < bestDistance) {
						bestDistance = distance;
						best = bone;
						index = i;
						offset.x = coords.x - mouse.x;
						offset.y = coords.y - mouse.y;
					}
				}
				if (best) selectedBones[index] = best;
				return best;
			};
			this.input = new Input(canvas);
			this.input.addListener({
				down: (x, y) => {
					target = closest(x, y);
				},
				up: () => {
					if (target) target = null;
					else if (config.showControls) this.paused ? this.play() : this.pause();
				},
				dragged: (x, y) => {
					if (target) {
						x = MathUtils.clamp(x + offset.x, 0, canvas.clientWidth);
						y = MathUtils.clamp(y - offset.y, 0, canvas.clientHeight);
						renderer.camera.screenToWorld(coords.set(x, y, 0), canvas.clientWidth, canvas.clientHeight);
						const applied = target.appliedPose;
						if (target.parent) {
							target.parent.appliedPose.worldToLocal(position.set(coords.x - skeleton.x, coords.y - skeleton.y));
							applied.x = position.x;
							applied.y = position.y;
						} else {
							applied.x = coords.x - skeleton.x;
							applied.y = coords.y - skeleton.y;
						}
					}
				},
				moved: (x, y) => closest(x, y)
			});
		}
		if (config.showControls) {
			this.addEventListener(document, "mousemove", (ev) => {
				if (ev instanceof MouseEvent) handleHover(ev.clientX, ev.clientY);
			});
			this.addEventListener(document, "touchmove", (ev) => {
				if (ev instanceof TouchEvent) {
					const touches = ev.changedTouches;
					if (touches.length) {
						const touch = touches[0];
						handleHover(touch.clientX, touch.clientY);
					}
				}
			});
			const overlap = (mouseX, mouseY, rect) => {
				const x = mouseX - rect.left, y = mouseY - rect.top;
				return x >= 0 && x <= rect.width && y >= 0 && y <= rect.height;
			};
			let mouseOverControls = true, mouseOverCanvas = false;
			const handleHover = (mouseX, mouseY) => {
				const popup = findWithClass(this.dom, "spine-player-popup");
				mouseOverControls = overlap(mouseX, mouseY, this.playerControls.getBoundingClientRect());
				mouseOverCanvas = overlap(mouseX, mouseY, canvas.getBoundingClientRect());
				clearTimeout(this.cancelId);
				if (!popup && !mouseOverControls && !mouseOverCanvas && !this.paused) this.playerControls.classList.add("spine-player-controls-hidden");
				else this.playerControls.classList.remove("spine-player-controls-hidden");
				if (!mouseOverControls && !popup && !this.paused) this.cancelId = setTimeout(() => {
					if (!this.paused) this.playerControls.classList.add("spine-player-controls-hidden");
				}, 1e3);
			};
		}
	}
	play() {
		this.paused = false;
		const config = this.config;
		if (config.showControls) {
			this.cancelId = setTimeout(() => {
				if (!this.paused) this.playerControls.classList.add("spine-player-controls-hidden");
			}, 1e3);
			this.playButton.classList.remove("spine-player-button-icon-play");
			this.playButton.classList.add("spine-player-button-icon-pause");
			if (!config.animation) {
				if (config.animations && config.animations.length) config.animation = config.animations[0];
				else if (this.skeleton.data.animations.length) config.animation = this.skeleton.data.animations[0].name;
				if (config.animation) this.setAnimation(config.animation);
			}
		}
	}
	pause() {
		this.paused = true;
		if (this.config.showControls) {
			this.playerControls.classList.remove("spine-player-controls-hidden");
			clearTimeout(this.cancelId);
			this.playButton.classList.remove("spine-player-button-icon-pause");
			this.playButton.classList.add("spine-player-button-icon-play");
		}
	}
	setAnimation(animation, loop = true) {
		animation = this.setViewport(animation);
		return this.animationState.setAnimation(0, animation, loop);
	}
	addAnimation(animation, loop = true, delay = 0) {
		animation = this.setViewport(animation);
		return this.animationState.addAnimation(0, animation, loop, delay);
	}
	setViewport(animation) {
		if (typeof animation === "string") {
			const foundAnimation = this.skeleton.data.findAnimation(animation);
			if (!foundAnimation) throw new Error(`Animation not found: ${animation}`);
			animation = foundAnimation;
		}
		this.previousViewport = this.currentViewport;
		const globalViewport = this.config.viewport;
		const viewport = this.currentViewport = {
			clip: globalViewport.clip,
			padLeft: globalViewport.padLeft !== void 0 ? globalViewport.padLeft : "10%",
			padRight: globalViewport.padRight !== void 0 ? globalViewport.padRight : "10%",
			padTop: globalViewport.padTop !== void 0 ? globalViewport.padTop : "10%",
			padBottom: globalViewport.padBottom !== void 0 ? globalViewport.padBottom : "10%"
		};
		if (globalViewport.x !== void 0 && globalViewport.y !== void 0 && globalViewport.width && globalViewport.height) {
			viewport.x = globalViewport.x;
			viewport.y = globalViewport.y;
			viewport.width = globalViewport.width;
			viewport.height = globalViewport.height;
		} else this.calculateAnimationViewport(animation, viewport);
		const userAnimViewport = this.config.viewport.animations[animation.name];
		if (userAnimViewport) {
			if (userAnimViewport.x !== void 0 && userAnimViewport.y !== void 0 && userAnimViewport.width && userAnimViewport.height) {
				viewport.x = userAnimViewport.x;
				viewport.y = userAnimViewport.y;
				viewport.width = userAnimViewport.width;
				viewport.height = userAnimViewport.height;
			}
			if (userAnimViewport.clip !== void 0) viewport.clip = userAnimViewport.clip;
			if (userAnimViewport.padLeft !== void 0) viewport.padLeft = userAnimViewport.padLeft;
			if (userAnimViewport.padRight !== void 0) viewport.padRight = userAnimViewport.padRight;
			if (userAnimViewport.padTop !== void 0) viewport.padTop = userAnimViewport.padTop;
			if (userAnimViewport.padBottom !== void 0) viewport.padBottom = userAnimViewport.padBottom;
		}
		viewport.padLeft = this.percentageToWorldUnit(viewport.width, viewport.padLeft);
		viewport.padRight = this.percentageToWorldUnit(viewport.width, viewport.padRight);
		viewport.padBottom = this.percentageToWorldUnit(viewport.height, viewport.padBottom);
		viewport.padTop = this.percentageToWorldUnit(viewport.height, viewport.padTop);
		this.viewportTransitionStart = performance.now();
		return animation;
	}
	percentageToWorldUnit(size, percentageOrAbsolute) {
		if (typeof percentageOrAbsolute === "string") return size * parseFloat(percentageOrAbsolute.slice(0, -1)) / 100;
		return percentageOrAbsolute;
	}
	calculateAnimationViewport(animation, viewport) {
		this.skeleton.setupPose();
		let steps = 100, stepTime = animation.duration ? animation.duration / steps : 0, time = 0;
		let minX = 1e8, maxX = -1e8, minY = 1e8, maxY = -1e8;
		const offset = new Vector2(), size = new Vector2();
		const tempArray = [0, 0];
		for (let i = 0; i < steps; i++, time += stepTime) {
			animation.apply(this.skeleton, time, time, false, [], 1, MixFrom.setup, false, false, false);
			this.skeleton.updateWorldTransform(Physics.update);
			this.skeleton.getBounds(offset, size, tempArray, this.sceneRenderer.skeletonRenderer.getSkeletonClipping());
			if (Number.isFinite(offset.x) && Number.isFinite(offset.y) && Number.isFinite(size.x) && Number.isFinite(size.y)) {
				minX = Math.min(offset.x, minX);
				maxX = Math.max(offset.x + size.x, maxX);
				minY = Math.min(offset.y, minY);
				maxY = Math.max(offset.y + size.y, maxY);
			}
		}
		viewport.x = minX;
		viewport.y = minY;
		viewport.width = maxX - minX;
		viewport.height = maxY - minY;
		if (!Number.isFinite(viewport.width) || !Number.isFinite(viewport.height)) this.showError(`Animation bounds are invalid: ${animation.name}`);
	}
	drawFrame(requestNextFrame = true) {
		try {
			if (this.error) return;
			if (this.disposed) return;
			if (requestNextFrame && !this.stopRequestAnimationFrame) requestAnimationFrame(() => this.drawFrame());
			const doc = document;
			const bg = doc.fullscreenElement || doc.webkitFullscreenElement || doc.mozFullScreenElement || doc.msFullscreenElement ? this.bgFullscreen : this.bg;
			this.time.update();
			const delta = this.time.delta;
			const loading = !this.assetManager.isLoadingComplete();
			if (!this.skeleton && !loading) this.loadSkeleton();
			const skeleton = this.skeleton;
			const config = this.config;
			if (skeleton) {
				const playDelta = this.paused ? 0 : delta * this.speed;
				if (config.frame) config.frame(this, playDelta);
				if (!this.paused) {
					skeleton.update(playDelta);
					this.animationState.update(playDelta);
					this.animationState.apply(skeleton);
					if (config.updateWorldTransform) config.updateWorldTransform(this, playDelta);
					else skeleton.updateWorldTransform(Physics.update);
					if (config.showControls) {
						this.playTime += playDelta;
						const entry = this.animationState.getTrack(0);
						if (entry) {
							const duration = entry.animation.duration;
							while (this.playTime >= duration && duration !== 0) this.playTime -= duration;
							this.playTime = Math.max(0, Math.min(this.playTime, duration));
							this.timelineSlider.setValue(this.playTime / duration);
						}
					}
				}
				const viewport = this.viewport;
				viewport.x = this.currentViewport.x - this.currentViewport.padLeft;
				viewport.y = this.currentViewport.y - this.currentViewport.padBottom;
				viewport.width = this.currentViewport.width + this.currentViewport.padLeft + this.currentViewport.padRight;
				viewport.height = this.currentViewport.height + this.currentViewport.padBottom + this.currentViewport.padTop;
				if (this.previousViewport) {
					const transitionAlpha = (performance.now() - this.viewportTransitionStart) / 1e3 / config.viewport.transitionTime;
					if (transitionAlpha < 1) {
						const x = this.previousViewport.x - this.previousViewport.padLeft;
						const y = this.previousViewport.y - this.previousViewport.padBottom;
						const width = this.previousViewport.width + this.previousViewport.padLeft + this.previousViewport.padRight;
						const height = this.previousViewport.height + this.previousViewport.padBottom + this.previousViewport.padTop;
						viewport.x = x + (viewport.x - x) * transitionAlpha;
						viewport.y = y + (viewport.y - y) * transitionAlpha;
						viewport.width = width + (viewport.width - width) * transitionAlpha;
						viewport.height = height + (viewport.height - height) * transitionAlpha;
					}
				}
				const renderer = this.sceneRenderer;
				renderer.camera.zoom = this.canvas.height / this.canvas.width > viewport.height / viewport.width ? viewport.width / this.canvas.width : viewport.height / this.canvas.height;
				renderer.camera.position.x = viewport.x + viewport.width / 2;
				renderer.camera.position.y = viewport.y + viewport.height / 2;
				renderer.resize(this.currentViewport.clip ? ResizeMode.FitClip : ResizeMode.Expand, viewport.width, viewport.height);
				const gl = this.context.gl;
				gl.clearColor(bg.r, bg.g, bg.b, bg.a);
				gl.clear(gl.COLOR_BUFFER_BIT);
				if (config.update) config.update(this, playDelta);
				renderer.begin();
				const bgImage = config.backgroundImage;
				if (bgImage) {
					const texture = this.assetManager.require(bgImage.url);
					if (bgImage.x !== void 0 && bgImage.y !== void 0 && bgImage.width && bgImage.height) renderer.drawTexture(texture, bgImage.x, bgImage.y, bgImage.width, bgImage.height);
					else renderer.drawTexture(texture, viewport.x, viewport.y, viewport.width, viewport.height);
				}
				renderer.drawSkeleton(skeleton);
				const debug = config.debug;
				if (Number(renderer.skeletonDebugRenderer.drawBones = debug.bones) + Number(renderer.skeletonDebugRenderer.drawBoundingBoxes = debug.bounds) + Number(renderer.skeletonDebugRenderer.drawClipping = debug.clipping) + Number(renderer.skeletonDebugRenderer.drawMeshHull = debug.hulls) + Number(renderer.skeletonDebugRenderer.drawPaths = debug.paths) + Number(renderer.skeletonDebugRenderer.drawRegionAttachments = debug.regions) + Number(renderer.skeletonDebugRenderer.drawMeshTriangles = debug.meshes) > 0) renderer.drawSkeletonDebug(skeleton);
				const controlBones = config.controlBones;
				if (controlBones.length) {
					const selectedBones = this.selectedBones;
					gl.lineWidth(2);
					for (let i = 0; i < controlBones.length; i++) {
						const bone = skeleton.findBone(controlBones[i]);
						if (!bone) continue;
						const colorInner = selectedBones[i] ? BONE_INNER_OVER : BONE_INNER;
						const colorOuter = selectedBones[i] ? BONE_OUTER_OVER : BONE_OUTER;
						const applied = bone.appliedPose;
						renderer.circle(true, skeleton.x + applied.worldX, skeleton.y + applied.worldY, 20, colorInner);
						renderer.circle(false, skeleton.x + applied.worldX, skeleton.y + applied.worldY, 20, colorOuter);
					}
				}
				if (config.viewport.debugRender) {
					gl.lineWidth(1);
					renderer.rect(false, this.currentViewport.x, this.currentViewport.y, this.currentViewport.width, this.currentViewport.height, Color.GREEN);
					renderer.rect(false, viewport.x, viewport.y, viewport.width, viewport.height, Color.RED);
				}
				renderer.end();
				if (config.draw) config.draw(this, playDelta);
			}
			if (config.showLoading) {
				this.loadingScreen.backgroundColor.setFromColor(bg);
				this.loadingScreen.draw(!loading);
			}
			if (loading && config.loading) config.loading(this, delta);
		} catch (e) {
			this.showError(`Error: Unable to render skeleton.\n${e.message}`, e);
		}
	}
	startRendering() {
		this.stopRequestAnimationFrame = false;
		requestAnimationFrame(() => this.drawFrame());
	}
	stopRendering() {
		this.stopRequestAnimationFrame = true;
	}
	hidePopup(id) {
		return this.popup != null && this.popup.hide(id);
	}
	showSpeedDialog(speedButton) {
		const id = "speed";
		if (this.hidePopup(id)) return;
		const popup = new Popup(id, speedButton, this, this.playerControls, `
<div class="spine-player-popup-title">Speed</div>
<hr>
<div class="spine-player-row" style="align-items:center;padding:8px">
<div class="spine-player-column">
	<div class="spine-player-speed-slider" style="margin-bottom:4px"></div>
	<div class="spine-player-row" style="justify-content:space-between"><div>0.1x</div><div>1x</div><div>2x</div></div>
</div>
</div>`);
		const slider = new Slider(2, .1, true);
		findWithClass(popup.dom, "spine-player-speed-slider").appendChild(slider.create());
		slider.setValue(this.speed / 2);
		slider.change = (percentage) => this.speed = percentage * 2;
		popup.show();
	}
	showAnimationsDialog(animationsButton) {
		const id = "animations";
		if (this.hidePopup(id)) return;
		if (!this.skeleton || !this.skeleton.data.animations.length) return;
		const popup = new Popup(id, animationsButton, this, this.playerControls, `<div class="spine-player-popup-title">Animations</div><hr><ul class="spine-player-list"></ul>`);
		const rows = findWithClass(popup.dom, "spine-player-list");
		this.skeleton.data.animations.forEach((animation) => {
			if (this.config.animations && this.config.animations.indexOf(animation.name) < 0) return;
			const row = createElement(`<li class="spine-player-list-item selectable"><div class="selectable-circle"></div><div class="selectable-text"></div></li>`);
			if (animation.name === this.config.animation) row.classList.add("selected");
			findWithClass(row, "selectable-text").innerText = animation.name;
			rows.appendChild(row);
			row.onclick = () => {
				removeClass(rows.children, "selected");
				row.classList.add("selected");
				this.config.animation = animation.name;
				this.playTime = 0;
				this.setAnimation(animation.name);
				this.play();
			};
		});
		popup.show();
	}
	applyCombinedSkin() {
		if (!this.skeleton) return;
		if (this.pinnedSkins.size === 0) this.skeleton.setSkin(this.skeleton.data.defaultSkin);
		else if (this.pinnedSkins.size === 1) this.skeleton.setSkin(this.pinnedSkins.values().next().value);
		else {
			const combined = new Skin("combined");
			for (const name of this.pinnedSkins) {
				const skin = this.skeleton.data.findSkin(name);
				if (skin) combined.addSkin(skin);
			}
			this.skeleton.setSkin(combined);
		}
		this.skeleton.setupPoseSlots();
		this.skeleton.updateWorldTransform(Physics.pose);
		const entry = this.animationState?.getTrack(0);
		if (entry && entry.animation) this.setViewport(entry.animation);
	}
	showSkinsDialog(skinButton) {
		const id = "skins";
		if (this.hidePopup(id)) return;
		if (!this.skeleton || !this.skeleton.data.skins.length) return;
		const popup = new Popup(id, skinButton, this, this.playerControls, `<div class="spine-player-popup-title">Skins</div><hr><ul class="spine-player-list"></ul>`);
		const rows = findWithClass(popup.dom, "spine-player-list");
		this.skeleton.data.skins.forEach((skin) => {
			if (skin === this.skeleton.data.defaultSkin) return;
			if (this.config.skins && this.config.skins.indexOf(skin.name) < 0) return;
			const row = createElement(`<li class="spine-player-list-item selectable"><div class="selectable-pin"></div><div class="selectable-text"></div></li>`);
			if (this.pinnedSkins.has(skin.name)) row.classList.add("pinned");
			const pinElement = findWithClass(row, "selectable-pin");
			const textElement = findWithClass(row, "selectable-text");
			textElement.innerText = skin.name;
			rows.appendChild(row);
			pinElement.onclick = (e) => {
				e.stopPropagation();
				if (this.pinnedSkins.has(skin.name)) {
					this.pinnedSkins.delete(skin.name);
					row.classList.remove("pinned");
				} else {
					this.pinnedSkins.add(skin.name);
					row.classList.add("pinned");
				}
				this.applyCombinedSkin();
			};
			row.onclick = () => {
				this.pinnedSkins.clear();
				this.pinnedSkins.add(skin.name);
				for (let i = 0; i < rows.children.length; i++) rows.children[i].classList.remove("pinned");
				row.classList.add("pinned");
				this.applyCombinedSkin();
			};
		});
		popup.show();
	}
	showSettingsDialog(settingsButton) {
		const id = "settings";
		if (this.hidePopup(id)) return;
		if (!this.skeleton || !this.skeleton.data.animations.length) return;
		const popup = new Popup(id, settingsButton, this, this.playerControls, `<div class="spine-player-popup-title">Debug</div><hr><ul class="spine-player-list"></ul>`);
		const rows = findWithClass(popup.dom, "spine-player-list");
		const makeItem = (label, name) => {
			const row = createElement(`<li class="spine-player-list-item"></li>`);
			const s = new Switch(label);
			row.appendChild(s.create());
			const debug = this.config.debug;
			s.setEnabled(debug[name]);
			s.change = (value) => debug[name] = value;
			rows.appendChild(row);
		};
		makeItem("Bones", "bones");
		makeItem("Regions", "regions");
		makeItem("Meshes", "meshes");
		makeItem("Bounds", "bounds");
		makeItem("Paths", "paths");
		makeItem("Clipping", "clipping");
		makeItem("Points", "points");
		makeItem("Hulls", "hulls");
		popup.show();
	}
	showError(message, error) {
		if (this.error) {
			if (error) throw error;
		} else {
			this.error = true;
			this.dom.appendChild(createElement(`<div class="spine-player-error" style="background:#000;color:#fff;position:absolute;top:0;width:100%;height:100%;display:flex;justify-content:center;align-items:center;overflow:auto;z-index:999">` + message.replace("\n", "<br><br>") + `</div>`));
			if (this.config.error) this.config.error(this, message);
			throw error ? error : new Error(message);
		}
	}
};
var Popup = class {
	id;
	button;
	player;
	parent;
	dom;
	className;
	constructor(id, button, player, parent, htmlContent) {
		this.id = id;
		this.button = button;
		this.player = player;
		this.parent = parent;
		this.dom = createElement(`<div class="spine-player-popup spine-player-hidden"></div>`);
		this.dom.innerHTML = htmlContent;
		parent.appendChild(this.dom);
		this.className = `spine-player-button-icon-${id}-selected`;
	}
	dispose() {}
	hide(id) {
		this.dom.remove();
		this.button.classList.remove(this.className);
		if (this.id === id) {
			this.player.popup = null;
			return true;
		}
		return false;
	}
	show() {
		this.player.popup = this;
		this.button.classList.add(this.className);
		this.dom.classList.remove("spine-player-hidden");
		let dismissed = false;
		const resize = () => {
			if (!dismissed) requestAnimationFrame(resize);
			this.dom.style.maxHeight = `${this.player.dom.clientHeight - this.parent.getBoundingClientRect().height}px`;
		};
		requestAnimationFrame(resize);
		let justClicked = true;
		const windowClickListener = (event) => {
			if (justClicked || this.player.popup !== this) {
				justClicked = false;
				return;
			}
			if (!this.dom.contains(event.target)) {
				this.dom.remove();
				window.removeEventListener("click", windowClickListener);
				this.button.classList.remove(this.className);
				this.player.popup = null;
				dismissed = true;
			}
		};
		this.player.addEventListener(window, "click", windowClickListener);
	}
};
var Switch = class {
	text;
	switch = null;
	enabled = false;
	change = () => {};
	constructor(text) {
		this.text = text;
	}
	create() {
		this.switch = createElement(`
<div class="spine-player-switch">
	<span class="spine-player-switch-text">${this.text}</span>
	<div class="spine-player-switch-knob-area">
		<div class="spine-player-switch-knob"></div>
	</div>
</div>`);
		this.switch.addEventListener("click", () => {
			this.setEnabled(!this.enabled);
			if (this.change) this.change(this.enabled);
		});
		return this.switch;
	}
	setEnabled(enabled) {
		if (enabled) this.switch?.classList.add("active");
		else this.switch?.classList.remove("active");
		this.enabled = enabled;
	}
	isEnabled() {
		return this.enabled;
	}
};
var Slider = class {
	snaps;
	snapPercentage;
	big;
	slider = null;
	value = null;
	knob = null;
	change = () => {};
	constructor(snaps = 0, snapPercentage = .1, big = false) {
		this.snaps = snaps;
		this.snapPercentage = snapPercentage;
		this.big = big;
	}
	create() {
		this.slider = createElement(`
<div class="spine-player-slider ${this.big ? "big" : ""}">
	<div class="spine-player-slider-value"></div>
	<!--<div class="spine-player-slider-knob"></div>-->
</div>`);
		this.value = findWithClass(this.slider, "spine-player-slider-value");
		this.setValue(0);
		let rect;
		const update = (ev) => {
			const clientX = ev instanceof MouseEvent ? ev.clientX : ev.changedTouches[0].clientX;
			if (this.change) this.change(this.setValue((clientX - rect.left) / rect.width));
		};
		const onEnd = (ev) => {
			update(ev);
			this.value?.classList.remove("hovering");
			this.slider?.parentElement?.classList.remove("dragging");
			document.removeEventListener("mousemove", update, true);
			document.removeEventListener("mouseup", onEnd, true);
			document.removeEventListener("touchmove", update, true);
			document.removeEventListener("touchend", onEnd, true);
		};
		const onStart = (ev) => {
			rect = this.slider.getBoundingClientRect();
			this.value?.classList.add("hovering");
			this.slider?.parentElement?.classList.add("dragging");
			update(ev);
			document.addEventListener("mousemove", update, true);
			document.addEventListener("mouseup", onEnd, true);
			document.addEventListener("touchmove", update, true);
			document.addEventListener("touchend", onEnd, true);
		};
		this.slider.addEventListener("mousedown", onStart, true);
		this.slider.addEventListener("touchstart", onStart, true);
		return this.slider;
	}
	setValue(percentage) {
		percentage = Math.max(0, Math.min(1, percentage));
		if (this.snaps) {
			const snap = 1 / this.snaps;
			const modulo = percentage % snap;
			if (modulo < snap * this.snapPercentage) percentage = percentage - modulo;
			else if (modulo > snap - snap * this.snapPercentage) percentage = percentage - modulo + snap;
			percentage = Math.max(0, Math.min(1, percentage));
		}
		this.value.style.width = `${percentage * 100}%`;
		return percentage;
	}
};
function findWithClass(element, className) {
	return element.getElementsByClassName(className)[0];
}
function createElement(html) {
	const div = document.createElement("div");
	div.innerHTML = html;
	return div.children[0];
}
function removeClass(elements, clazz) {
	for (let i = 0; i < elements.length; i++) elements[i].classList.remove(clazz);
}
function print(object) {
	return JSON.stringify(object).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&#34;").replace(/'/g, "&#39;");
}
var BONE_INNER_OVER = new Color(.478, 0, 0, .25);
var BONE_OUTER_OVER = new Color(1, 1, 1, 1);
var BONE_INNER = new Color(.478, 0, 0, .5);
var BONE_OUTER = new Color(1, 0, 0, .8);
//#endregion
//#region node_modules/@esotericsoftware/spine-player/dist/PlayerEditor.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
function loadScript(url) {
	return new Promise((resolve, reject) => {
		const script = document.createElement("script");
		script.src = url;
		script.onload = () => resolve();
		script.onerror = () => reject(/* @__PURE__ */ new Error(`Script load error for ${url}`));
		document.head.appendChild(script);
	});
}
function loadCss(url) {
	return new Promise((resolve, reject) => {
		const link = document.createElement("link");
		link.href = url;
		link.rel = "stylesheet";
		link.onload = () => resolve();
		link.onerror = () => reject(/* @__PURE__ */ new Error(`CSS load error for ${url}`));
		document.head.appendChild(link);
	});
}
var SpinePlayerEditor = class SpinePlayerEditor {
	parent;
	static DEFAULT_CODE = `
<script src="https://esotericsoftware.com/files/spine-player/4.1/spine-player.js"><\/script>
<link rel="stylesheet" href="https://esotericsoftware.com/files/spine-player/4.1/spine-player.css">

<div id="player-container" style="width: 100vw; height: 100vh;"></div>

<script>
new spine.SpinePlayer("player-container", {
	jsonUrl: "https://esotericsoftware.com/files/examples/4.1/spineboy/export/spineboy-pro.json",
	atlasUrl: "https://esotericsoftware.com/files/examples/4.1/spineboy/export/spineboy-pma.atlas"
});
<\/script>
		`.trim();
	prefix = `<html>
<head>
<style>
body { margin: 0px; }
</style>
</head>
<body>`.trim();
	postfix = `</body>`;
	code;
	player;
	constructor(parent) {
		this.parent = parent;
		this.load();
	}
	async load() {
		await Promise.all([loadScript("https://www.unpkg.com/codemirror@5.51.0/lib/codemirror.js"), loadCss("https://www.unpkg.com/codemirror@5.51.0/lib/codemirror.css")]);
		this.render(this.parent);
	}
	render(parent) {
		parent.innerHTML = `
				<div style="display: flex; flex-direction: column; width: 100%; height: 100%;">
					<div style="width: 100%; height: 50%"></div>
					<iframe style="width: 100%; height: 50%; outline: none; border: none;"></iframe>
				</div>
			`;
		const codeElement = parent.children[0].children[0];
		this.player = parent.children[0].children[1];
		requestAnimationFrame(() => {
			this.code = CodeMirror(codeElement, {
				lineNumbers: true,
				tabSize: 3,
				indentUnit: 3,
				indentWithTabs: true,
				scrollBarStyle: "native",
				mode: "htmlmixed",
				theme: "monokai"
			});
			this.code.on("change", () => {
				this.startPlayer();
			});
			codeElement.children[0].style.height = "100%";
			this.setCode(SpinePlayerEditor.DEFAULT_CODE);
		});
	}
	setPreAndPostfix(prefix, postfix) {
		this.prefix = prefix;
		this.postfix = postfix;
		this.startPlayer();
	}
	setCode(code) {
		this.code.setValue(code);
		this.startPlayer();
	}
	timerId = 0;
	startPlayer() {
		clearTimeout(this.timerId);
		this.timerId = setTimeout(() => {
			let code = this.code.getDoc().getValue();
			code = this.prefix + code + this.postfix;
			code = window.btoa(code);
			this.player.src = "";
			this.player.src = "data:text/html;base64," + code;
		}, 500);
	}
};
//#endregion
//#region node_modules/@esotericsoftware/spine-player/dist/index.js
var dist_exports = /* @__PURE__ */ __exportAll({
	ATTACH_RETAIN: () => 2,
	ATTACH_SETUP: () => 1,
	AlphaTimeline: () => AlphaTimeline,
	Animation: () => Animation,
	AnimationState: () => AnimationState,
	AnimationStateData: () => AnimationStateData,
	AssetCache: () => AssetCache,
	AssetManager: () => AssetManager,
	AssetManagerBase: () => AssetManagerBase,
	AtlasAttachmentLoader: () => AtlasAttachmentLoader,
	Attachment: () => Attachment,
	AttachmentTimeline: () => AttachmentTimeline,
	BinaryInput: () => BinaryInput,
	BlendMode: () => BlendMode,
	Bone: () => Bone,
	BoneData: () => BoneData,
	BonePose: () => BonePose,
	BoneTimeline1: () => BoneTimeline1,
	BoneTimeline2: () => BoneTimeline2,
	BoundingBoxAttachment: () => BoundingBoxAttachment,
	CURRENT: () => 0,
	ClippingAttachment: () => ClippingAttachment,
	Color: () => Color,
	Color2Attribute: () => Color2Attribute,
	ColorAttribute: () => ColorAttribute,
	Constraint: () => Constraint,
	ConstraintData: () => ConstraintData,
	ConstraintTimeline1: () => ConstraintTimeline1,
	CurveTimeline: () => CurveTimeline,
	CurveTimeline1: () => CurveTimeline1,
	DeformTimeline: () => DeformTimeline,
	Downloader: () => Downloader,
	DrawOrder: () => DrawOrder,
	DrawOrderFolderTimeline: () => DrawOrderFolderTimeline,
	DrawOrderTimeline: () => DrawOrderTimeline,
	Event: () => Event,
	EventData: () => EventData,
	EventQueue: () => EventQueue,
	EventTimeline: () => EventTimeline,
	EventType: () => EventType,
	FIRST: () => 2,
	FromProperty: () => FromProperty,
	FromRotate: () => FromRotate,
	FromScaleX: () => FromScaleX,
	FromScaleY: () => FromScaleY,
	FromShearY: () => FromShearY,
	FromX: () => FromX,
	FromY: () => FromY,
	GLTexture: () => GLTexture,
	HOLD: () => 4,
	IkConstraint: () => IkConstraint,
	IkConstraintData: () => IkConstraintData,
	IkConstraintPose: () => IkConstraintPose,
	IkConstraintTimeline: () => IkConstraintTimeline,
	Inherit: () => Inherit,
	InheritTimeline: () => InheritTimeline,
	Input: () => Input,
	Interpolation: () => Interpolation,
	LoadingScreen: () => LoadingScreen,
	M00: () => 0,
	M01: () => 4,
	M02: () => 8,
	M03: () => 12,
	M10: () => 1,
	M11: () => 5,
	M12: () => 9,
	M13: () => 13,
	M20: () => 2,
	M21: () => 6,
	M22: () => 10,
	M23: () => 14,
	M30: () => 3,
	M31: () => 7,
	M32: () => 11,
	M33: () => 15,
	MODE: () => 3,
	ManagedWebGLRenderingContext: () => ManagedWebGLRenderingContext,
	MathUtils: () => MathUtils,
	Matrix4: () => Matrix4,
	Mesh: () => Mesh,
	MeshAttachment: () => MeshAttachment,
	MixFrom: () => MixFrom,
	OrthoCamera: () => OrthoCamera,
	PathAttachment: () => PathAttachment,
	PathConstraint: () => PathConstraint,
	PathConstraintData: () => PathConstraintData,
	PathConstraintMixTimeline: () => PathConstraintMixTimeline,
	PathConstraintPose: () => PathConstraintPose,
	PathConstraintPositionTimeline: () => PathConstraintPositionTimeline,
	PathConstraintSpacingTimeline: () => PathConstraintSpacingTimeline,
	Physics: () => Physics,
	PhysicsConstraint: () => PhysicsConstraint,
	PhysicsConstraintDampingTimeline: () => PhysicsConstraintDampingTimeline,
	PhysicsConstraintData: () => PhysicsConstraintData,
	PhysicsConstraintGravityTimeline: () => PhysicsConstraintGravityTimeline,
	PhysicsConstraintInertiaTimeline: () => PhysicsConstraintInertiaTimeline,
	PhysicsConstraintMassTimeline: () => PhysicsConstraintMassTimeline,
	PhysicsConstraintMixTimeline: () => PhysicsConstraintMixTimeline,
	PhysicsConstraintPose: () => PhysicsConstraintPose,
	PhysicsConstraintResetTimeline: () => PhysicsConstraintResetTimeline,
	PhysicsConstraintStrengthTimeline: () => PhysicsConstraintStrengthTimeline,
	PhysicsConstraintTimeline: () => PhysicsConstraintTimeline,
	PhysicsConstraintWindTimeline: () => PhysicsConstraintWindTimeline,
	PointAttachment: () => PointAttachment,
	PolygonBatcher: () => PolygonBatcher,
	Pool: () => Pool,
	Posed: () => Posed,
	PosedActive: () => PosedActive,
	PosedData: () => PosedData,
	Position2Attribute: () => Position2Attribute,
	PositionMode: () => PositionMode,
	Property: () => Property,
	RGB2Timeline: () => RGB2Timeline,
	RGBA2Timeline: () => RGBA2Timeline,
	RGBATimeline: () => RGBATimeline,
	RGBTimeline: () => RGBTimeline,
	RegionAttachment: () => RegionAttachment,
	ResizeMode: () => ResizeMode,
	RotateMode: () => RotateMode,
	RotateTimeline: () => RotateTimeline,
	SETUP: () => 1,
	ScaleTimeline: () => ScaleTimeline,
	ScaleXTimeline: () => ScaleXTimeline,
	ScaleYMode: () => ScaleYMode,
	ScaleYTimeline: () => ScaleYTimeline,
	SceneRenderer: () => SceneRenderer,
	Sequence: () => Sequence,
	SequenceMode: () => SequenceMode,
	SequenceModeValues: () => SequenceModeValues,
	SequenceTimeline: () => SequenceTimeline,
	Shader: () => Shader,
	ShapeRenderer: () => ShapeRenderer,
	ShapeType: () => ShapeType,
	ShearTimeline: () => ShearTimeline,
	ShearXTimeline: () => ShearXTimeline,
	ShearYTimeline: () => ShearYTimeline,
	Skeleton: () => Skeleton,
	SkeletonBinary: () => SkeletonBinary,
	SkeletonBounds: () => SkeletonBounds,
	SkeletonClipping: () => SkeletonClipping,
	SkeletonData: () => SkeletonData,
	SkeletonDebugRenderer: () => SkeletonDebugRenderer,
	SkeletonJson: () => SkeletonJson,
	SkeletonRenderer: () => SkeletonRenderer,
	Skin: () => Skin,
	SkinEntry: () => SkinEntry,
	Slider: () => Slider$1,
	SliderData: () => SliderData,
	SliderMixTimeline: () => SliderMixTimeline,
	SliderPose: () => SliderPose,
	SliderTimeline: () => SliderTimeline,
	Slot: () => Slot,
	SlotCurveTimeline: () => SlotCurveTimeline,
	SlotData: () => SlotData,
	SlotPose: () => SlotPose,
	SpacingMode: () => SpacingMode,
	SpinePlayer: () => SpinePlayer,
	SpinePlayerEditor: () => SpinePlayerEditor,
	StringSet: () => StringSet,
	TexCoordAttribute: () => TexCoordAttribute,
	Texture: () => Texture,
	TextureAtlas: () => TextureAtlas,
	TextureAtlasPage: () => TextureAtlasPage,
	TextureAtlasRegion: () => TextureAtlasRegion,
	TextureFilter: () => TextureFilter,
	TextureRegion: () => TextureRegion,
	TextureWrap: () => TextureWrap,
	TimeKeeper: () => TimeKeeper,
	Timeline: () => Timeline,
	ToProperty: () => ToProperty,
	ToRotate: () => ToRotate,
	ToScaleX: () => ToScaleX,
	ToScaleY: () => ToScaleY,
	ToShearY: () => ToShearY,
	ToX: () => ToX,
	ToY: () => ToY,
	Touch: () => Touch,
	TrackEntry: () => TrackEntry,
	TransformConstraint: () => TransformConstraint,
	TransformConstraintData: () => TransformConstraintData,
	TransformConstraintPose: () => TransformConstraintPose,
	TransformConstraintTimeline: () => TransformConstraintTimeline,
	TranslateTimeline: () => TranslateTimeline,
	TranslateXTimeline: () => TranslateXTimeline,
	TranslateYTimeline: () => TranslateYTimeline,
	Triangulator: () => Triangulator,
	Utils: () => Utils,
	Vector2: () => Vector2,
	Vector3: () => Vector3,
	VertexAttachment: () => VertexAttachment,
	VertexAttribute: () => VertexAttribute,
	VertexAttributeType: () => VertexAttributeType,
	isBoneTimeline: () => isBoneTimeline,
	isConstraintTimeline: () => isConstraintTimeline,
	isSlotTimeline: () => isSlotTimeline
});
//#endregion
export { dist_exports as t };
