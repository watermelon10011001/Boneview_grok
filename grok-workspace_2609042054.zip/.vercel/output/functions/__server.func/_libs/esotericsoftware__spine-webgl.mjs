import { Ar as Vector2$1, D as AssetManagerBase$2, En as RegionAttachment$1, Fr as SkeletonBounds, G as ClippingAttachment$2, H as TextureFilter$2, Ht as Color$2, I as PathAttachment$2, Jt as Vector2$2, Kt as TimeKeeper$2, L as MeshAttachment$2, Ln as ClippingAttachment$1, Nn as Texture$1, Nr as SkeletonClipping, O as Downloader$1, On as PathAttachment$1, Or as TimeKeeper$1, P as RegionAttachment$2, Pn as TextureFilter$1, Qt as SkeletonBounds$1, Tr as MathUtils$1, Ut as MathUtils$2, V as Texture$2, Xt as SkeletonClipping$1, _i as TextureFilter, bi as ClippingAttachment, bn as Downloader, c as BlendMode$2, ca as MathUtils, di as PathAttachment, fi as MeshAttachment, gi as Texture, ha as Vector2, i as SkeletonBounds$2, kn as MeshAttachment$1, kr as Utils$1, li as RegionAttachment, ma as Utils, n as SkeletonClipping$2, ni as AssetManagerBase, nn as BlendMode$1, oa as Color, pa as TimeKeeper, qt as Utils$2, wr as Color$1, yn as AssetManagerBase$1, zr as BlendMode } from "./esotericsoftware__spine-core.mjs";
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/WebGL.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var ManagedWebGLRenderingContext$2 = class {
	constructor(canvasOrContext, contextConfig = { alpha: "true" }) {
		this.restorables = new Array();
		if (!(canvasOrContext instanceof WebGLRenderingContext || typeof WebGL2RenderingContext !== "undefined" && canvasOrContext instanceof WebGL2RenderingContext)) this.setupCanvas(canvasOrContext, contextConfig);
		else {
			this.gl = canvasOrContext;
			this.canvas = this.gl.canvas;
		}
	}
	setupCanvas(canvas, contextConfig) {
		this.gl = canvas.getContext("webgl2", contextConfig) || canvas.getContext("webgl", contextConfig);
		this.canvas = canvas;
		canvas.addEventListener("webglcontextlost", (e) => {
			if (e) e.preventDefault();
		});
		canvas.addEventListener("webglcontextrestored", (e) => {
			for (let i = 0, n = this.restorables.length; i < n; i++) this.restorables[i].restore();
		});
	}
	addRestorable(restorable) {
		this.restorables.push(restorable);
	}
	removeRestorable(restorable) {
		let index = this.restorables.indexOf(restorable);
		if (index > -1) this.restorables.splice(index, 1);
	}
};
var ONE = 1;
var ONE_MINUS_SRC_COLOR = 769;
var SRC_ALPHA = 770;
var ONE_MINUS_SRC_ALPHA = 771;
var DST_COLOR = 774;
var WebGLBlendModeConverter = class {
	static getDestGLBlendMode(blendMode) {
		switch (blendMode) {
			case BlendMode.Normal: return ONE_MINUS_SRC_ALPHA;
			case BlendMode.Additive: return ONE;
			case BlendMode.Multiply: return ONE_MINUS_SRC_ALPHA;
			case BlendMode.Screen: return ONE_MINUS_SRC_ALPHA;
			default: throw new Error("Unknown blend mode: " + blendMode);
		}
	}
	static getSourceColorGLBlendMode(blendMode, premultipliedAlpha = false) {
		switch (blendMode) {
			case BlendMode.Normal: return premultipliedAlpha ? ONE : SRC_ALPHA;
			case BlendMode.Additive: return premultipliedAlpha ? ONE : SRC_ALPHA;
			case BlendMode.Multiply: return DST_COLOR;
			case BlendMode.Screen: return ONE;
			default: throw new Error("Unknown blend mode: " + blendMode);
		}
	}
	static getSourceAlphaGLBlendMode(blendMode) {
		switch (blendMode) {
			case BlendMode.Normal: return ONE;
			case BlendMode.Additive: return ONE;
			case BlendMode.Multiply: return ONE_MINUS_SRC_ALPHA;
			case BlendMode.Screen: return ONE_MINUS_SRC_COLOR;
			default: throw new Error("Unknown blend mode: " + blendMode);
		}
	}
};
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/GLTexture.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var GLTexture$2 = class GLTexture$2 extends Texture {
	constructor(context, image, useMipMaps = false) {
		super(image);
		this.texture = null;
		this.boundUnit = 0;
		this.useMipMaps = false;
		this.context = context instanceof ManagedWebGLRenderingContext$2 ? context : new ManagedWebGLRenderingContext$2(context);
		this.useMipMaps = useMipMaps;
		this.restore();
		this.context.addRestorable(this);
	}
	setFilters(minFilter, magFilter) {
		let gl = this.context.gl;
		this.bind();
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, minFilter);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, GLTexture$2.validateMagFilter(magFilter));
	}
	static validateMagFilter(magFilter) {
		switch (magFilter) {
			case TextureFilter.MipMap:
			case TextureFilter.MipMapLinearLinear:
			case TextureFilter.MipMapLinearNearest:
			case TextureFilter.MipMapNearestLinear:
			case TextureFilter.MipMapNearestNearest: return TextureFilter.Linear;
			default: return magFilter;
		}
	}
	setWraps(uWrap, vWrap) {
		let gl = this.context.gl;
		this.bind();
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, uWrap);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, vWrap);
	}
	update(useMipMaps) {
		let gl = this.context.gl;
		if (!this.texture) this.texture = this.context.gl.createTexture();
		this.bind();
		if (GLTexture$2.DISABLE_UNPACK_PREMULTIPLIED_ALPHA_WEBGL) gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this._image);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, useMipMaps ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
		if (useMipMaps) gl.generateMipmap(gl.TEXTURE_2D);
	}
	restore() {
		this.texture = null;
		this.update(this.useMipMaps);
	}
	bind(unit = 0) {
		let gl = this.context.gl;
		this.boundUnit = unit;
		gl.activeTexture(gl.TEXTURE0 + unit);
		gl.bindTexture(gl.TEXTURE_2D, this.texture);
	}
	unbind() {
		let gl = this.context.gl;
		gl.activeTexture(gl.TEXTURE0 + this.boundUnit);
		gl.bindTexture(gl.TEXTURE_2D, null);
	}
	dispose() {
		this.context.removeRestorable(this);
		this.context.gl.deleteTexture(this.texture);
	}
};
GLTexture$2.DISABLE_UNPACK_PREMULTIPLIED_ALPHA_WEBGL = false;
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/AssetManager.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var AssetManager$2 = class extends AssetManagerBase {
	constructor(context, pathPrefix = "", downloader = null) {
		super((image) => {
			return new GLTexture$2(context, image);
		}, pathPrefix, downloader);
	}
};
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/Vector3.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Vector3$2 = class {
	constructor(x = 0, y = 0, z = 0) {
		this.x = 0;
		this.y = 0;
		this.z = 0;
		this.x = x;
		this.y = y;
		this.z = z;
	}
	setFrom(v) {
		this.x = v.x;
		this.y = v.y;
		this.z = v.z;
		return this;
	}
	set(x, y, z) {
		this.x = x;
		this.y = y;
		this.z = z;
		return this;
	}
	add(v) {
		this.x += v.x;
		this.y += v.y;
		this.z += v.z;
		return this;
	}
	sub(v) {
		this.x -= v.x;
		this.y -= v.y;
		this.z -= v.z;
		return this;
	}
	scale(s) {
		this.x *= s;
		this.y *= s;
		this.z *= s;
		return this;
	}
	normalize() {
		let len = this.length();
		if (len == 0) return this;
		len = 1 / len;
		this.x *= len;
		this.y *= len;
		this.z *= len;
		return this;
	}
	cross(v) {
		return this.set(this.y * v.z - this.z * v.y, this.z * v.x - this.x * v.z, this.x * v.y - this.y * v.x);
	}
	multiply(matrix) {
		let l_mat = matrix.values;
		return this.set(this.x * l_mat[0] + this.y * l_mat[4] + this.z * l_mat[8] + l_mat[12], this.x * l_mat[1] + this.y * l_mat[5] + this.z * l_mat[9] + l_mat[13], this.x * l_mat[2] + this.y * l_mat[6] + this.z * l_mat[10] + l_mat[14]);
	}
	project(matrix) {
		let l_mat = matrix.values;
		let l_w = 1 / (this.x * l_mat[3] + this.y * l_mat[7] + this.z * l_mat[11] + l_mat[15]);
		return this.set((this.x * l_mat[0] + this.y * l_mat[4] + this.z * l_mat[8] + l_mat[12]) * l_w, (this.x * l_mat[1] + this.y * l_mat[5] + this.z * l_mat[9] + l_mat[13]) * l_w, (this.x * l_mat[2] + this.y * l_mat[6] + this.z * l_mat[10] + l_mat[14]) * l_w);
	}
	dot(v) {
		return this.x * v.x + this.y * v.y + this.z * v.z;
	}
	length() {
		return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
	}
	distance(v) {
		let a = v.x - this.x;
		let b = v.y - this.y;
		let c = v.z - this.z;
		return Math.sqrt(a * a + b * b + c * c);
	}
};
var Matrix4$2 = class Matrix4$2 {
	constructor() {
		this.temp = /* @__PURE__ */ new Float32Array(16);
		this.values = /* @__PURE__ */ new Float32Array(16);
		let v = this.values;
		v[0] = 1;
		v[5] = 1;
		v[10] = 1;
		v[15] = 1;
	}
	set(values) {
		this.values.set(values);
		return this;
	}
	transpose() {
		let t = this.temp;
		let v = this.values;
		t[0] = v[0];
		t[4] = v[1];
		t[8] = v[2];
		t[12] = v[3];
		t[1] = v[4];
		t[5] = v[5];
		t[9] = v[6];
		t[13] = v[7];
		t[2] = v[8];
		t[6] = v[9];
		t[10] = v[10];
		t[14] = v[11];
		t[3] = v[12];
		t[7] = v[13];
		t[11] = v[14];
		t[15] = v[15];
		return this.set(t);
	}
	identity() {
		let v = this.values;
		v[0] = 1;
		v[4] = 0;
		v[8] = 0;
		v[12] = 0;
		v[1] = 0;
		v[5] = 1;
		v[9] = 0;
		v[13] = 0;
		v[2] = 0;
		v[6] = 0;
		v[10] = 1;
		v[14] = 0;
		v[3] = 0;
		v[7] = 0;
		v[11] = 0;
		v[15] = 1;
		return this;
	}
	invert() {
		let v = this.values;
		let t = this.temp;
		let l_det = v[3] * v[6] * v[9] * v[12] - v[2] * v[7] * v[9] * v[12] - v[3] * v[5] * v[10] * v[12] + v[1] * v[7] * v[10] * v[12] + v[2] * v[5] * v[11] * v[12] - v[1] * v[6] * v[11] * v[12] - v[3] * v[6] * v[8] * v[13] + v[2] * v[7] * v[8] * v[13] + v[3] * v[4] * v[10] * v[13] - v[0] * v[7] * v[10] * v[13] - v[2] * v[4] * v[11] * v[13] + v[0] * v[6] * v[11] * v[13] + v[3] * v[5] * v[8] * v[14] - v[1] * v[7] * v[8] * v[14] - v[3] * v[4] * v[9] * v[14] + v[0] * v[7] * v[9] * v[14] + v[1] * v[4] * v[11] * v[14] - v[0] * v[5] * v[11] * v[14] - v[2] * v[5] * v[8] * v[15] + v[1] * v[6] * v[8] * v[15] + v[2] * v[4] * v[9] * v[15] - v[0] * v[6] * v[9] * v[15] - v[1] * v[4] * v[10] * v[15] + v[0] * v[5] * v[10] * v[15];
		if (l_det == 0) throw new Error("non-invertible matrix");
		let inv_det = 1 / l_det;
		t[0] = v[9] * v[14] * v[7] - v[13] * v[10] * v[7] + v[13] * v[6] * v[11] - v[5] * v[14] * v[11] - v[9] * v[6] * v[15] + v[5] * v[10] * v[15];
		t[4] = v[12] * v[10] * v[7] - v[8] * v[14] * v[7] - v[12] * v[6] * v[11] + v[4] * v[14] * v[11] + v[8] * v[6] * v[15] - v[4] * v[10] * v[15];
		t[8] = v[8] * v[13] * v[7] - v[12] * v[9] * v[7] + v[12] * v[5] * v[11] - v[4] * v[13] * v[11] - v[8] * v[5] * v[15] + v[4] * v[9] * v[15];
		t[12] = v[12] * v[9] * v[6] - v[8] * v[13] * v[6] - v[12] * v[5] * v[10] + v[4] * v[13] * v[10] + v[8] * v[5] * v[14] - v[4] * v[9] * v[14];
		t[1] = v[13] * v[10] * v[3] - v[9] * v[14] * v[3] - v[13] * v[2] * v[11] + v[1] * v[14] * v[11] + v[9] * v[2] * v[15] - v[1] * v[10] * v[15];
		t[5] = v[8] * v[14] * v[3] - v[12] * v[10] * v[3] + v[12] * v[2] * v[11] - v[0] * v[14] * v[11] - v[8] * v[2] * v[15] + v[0] * v[10] * v[15];
		t[9] = v[12] * v[9] * v[3] - v[8] * v[13] * v[3] - v[12] * v[1] * v[11] + v[0] * v[13] * v[11] + v[8] * v[1] * v[15] - v[0] * v[9] * v[15];
		t[13] = v[8] * v[13] * v[2] - v[12] * v[9] * v[2] + v[12] * v[1] * v[10] - v[0] * v[13] * v[10] - v[8] * v[1] * v[14] + v[0] * v[9] * v[14];
		t[2] = v[5] * v[14] * v[3] - v[13] * v[6] * v[3] + v[13] * v[2] * v[7] - v[1] * v[14] * v[7] - v[5] * v[2] * v[15] + v[1] * v[6] * v[15];
		t[6] = v[12] * v[6] * v[3] - v[4] * v[14] * v[3] - v[12] * v[2] * v[7] + v[0] * v[14] * v[7] + v[4] * v[2] * v[15] - v[0] * v[6] * v[15];
		t[10] = v[4] * v[13] * v[3] - v[12] * v[5] * v[3] + v[12] * v[1] * v[7] - v[0] * v[13] * v[7] - v[4] * v[1] * v[15] + v[0] * v[5] * v[15];
		t[14] = v[12] * v[5] * v[2] - v[4] * v[13] * v[2] - v[12] * v[1] * v[6] + v[0] * v[13] * v[6] + v[4] * v[1] * v[14] - v[0] * v[5] * v[14];
		t[3] = v[9] * v[6] * v[3] - v[5] * v[10] * v[3] - v[9] * v[2] * v[7] + v[1] * v[10] * v[7] + v[5] * v[2] * v[11] - v[1] * v[6] * v[11];
		t[7] = v[4] * v[10] * v[3] - v[8] * v[6] * v[3] + v[8] * v[2] * v[7] - v[0] * v[10] * v[7] - v[4] * v[2] * v[11] + v[0] * v[6] * v[11];
		t[11] = v[8] * v[5] * v[3] - v[4] * v[9] * v[3] - v[8] * v[1] * v[7] + v[0] * v[9] * v[7] + v[4] * v[1] * v[11] - v[0] * v[5] * v[11];
		t[15] = v[4] * v[9] * v[2] - v[8] * v[5] * v[2] + v[8] * v[1] * v[6] - v[0] * v[9] * v[6] - v[4] * v[1] * v[10] + v[0] * v[5] * v[10];
		v[0] = t[0] * inv_det;
		v[4] = t[4] * inv_det;
		v[8] = t[8] * inv_det;
		v[12] = t[12] * inv_det;
		v[1] = t[1] * inv_det;
		v[5] = t[5] * inv_det;
		v[9] = t[9] * inv_det;
		v[13] = t[13] * inv_det;
		v[2] = t[2] * inv_det;
		v[6] = t[6] * inv_det;
		v[10] = t[10] * inv_det;
		v[14] = t[14] * inv_det;
		v[3] = t[3] * inv_det;
		v[7] = t[7] * inv_det;
		v[11] = t[11] * inv_det;
		v[15] = t[15] * inv_det;
		return this;
	}
	determinant() {
		let v = this.values;
		return v[3] * v[6] * v[9] * v[12] - v[2] * v[7] * v[9] * v[12] - v[3] * v[5] * v[10] * v[12] + v[1] * v[7] * v[10] * v[12] + v[2] * v[5] * v[11] * v[12] - v[1] * v[6] * v[11] * v[12] - v[3] * v[6] * v[8] * v[13] + v[2] * v[7] * v[8] * v[13] + v[3] * v[4] * v[10] * v[13] - v[0] * v[7] * v[10] * v[13] - v[2] * v[4] * v[11] * v[13] + v[0] * v[6] * v[11] * v[13] + v[3] * v[5] * v[8] * v[14] - v[1] * v[7] * v[8] * v[14] - v[3] * v[4] * v[9] * v[14] + v[0] * v[7] * v[9] * v[14] + v[1] * v[4] * v[11] * v[14] - v[0] * v[5] * v[11] * v[14] - v[2] * v[5] * v[8] * v[15] + v[1] * v[6] * v[8] * v[15] + v[2] * v[4] * v[9] * v[15] - v[0] * v[6] * v[9] * v[15] - v[1] * v[4] * v[10] * v[15] + v[0] * v[5] * v[10] * v[15];
	}
	translate(x, y, z) {
		let v = this.values;
		v[12] += x;
		v[13] += y;
		v[14] += z;
		return this;
	}
	copy() {
		return new Matrix4$2().set(this.values);
	}
	projection(near, far, fovy, aspectRatio) {
		this.identity();
		let l_fd = 1 / Math.tan(fovy * (Math.PI / 180) / 2);
		let l_a1 = (far + near) / (near - far);
		let l_a2 = 2 * far * near / (near - far);
		let v = this.values;
		v[0] = l_fd / aspectRatio;
		v[1] = 0;
		v[2] = 0;
		v[3] = 0;
		v[4] = 0;
		v[5] = l_fd;
		v[6] = 0;
		v[7] = 0;
		v[8] = 0;
		v[9] = 0;
		v[10] = l_a1;
		v[11] = -1;
		v[12] = 0;
		v[13] = 0;
		v[14] = l_a2;
		v[15] = 0;
		return this;
	}
	ortho2d(x, y, width, height) {
		return this.ortho(x, x + width, y, y + height, 0, 1);
	}
	ortho(left, right, bottom, top, near, far) {
		this.identity();
		let x_orth = 2 / (right - left);
		let y_orth = 2 / (top - bottom);
		let z_orth = -2 / (far - near);
		let tx = -(right + left) / (right - left);
		let ty = -(top + bottom) / (top - bottom);
		let tz = -(far + near) / (far - near);
		let v = this.values;
		v[0] = x_orth;
		v[1] = 0;
		v[2] = 0;
		v[3] = 0;
		v[4] = 0;
		v[5] = y_orth;
		v[6] = 0;
		v[7] = 0;
		v[8] = 0;
		v[9] = 0;
		v[10] = z_orth;
		v[11] = 0;
		v[12] = tx;
		v[13] = ty;
		v[14] = tz;
		v[15] = 1;
		return this;
	}
	multiply(matrix) {
		let t = this.temp;
		let v = this.values;
		let m = matrix.values;
		t[0] = v[0] * m[0] + v[4] * m[1] + v[8] * m[2] + v[12] * m[3];
		t[4] = v[0] * m[4] + v[4] * m[5] + v[8] * m[6] + v[12] * m[7];
		t[8] = v[0] * m[8] + v[4] * m[9] + v[8] * m[10] + v[12] * m[11];
		t[12] = v[0] * m[12] + v[4] * m[13] + v[8] * m[14] + v[12] * m[15];
		t[1] = v[1] * m[0] + v[5] * m[1] + v[9] * m[2] + v[13] * m[3];
		t[5] = v[1] * m[4] + v[5] * m[5] + v[9] * m[6] + v[13] * m[7];
		t[9] = v[1] * m[8] + v[5] * m[9] + v[9] * m[10] + v[13] * m[11];
		t[13] = v[1] * m[12] + v[5] * m[13] + v[9] * m[14] + v[13] * m[15];
		t[2] = v[2] * m[0] + v[6] * m[1] + v[10] * m[2] + v[14] * m[3];
		t[6] = v[2] * m[4] + v[6] * m[5] + v[10] * m[6] + v[14] * m[7];
		t[10] = v[2] * m[8] + v[6] * m[9] + v[10] * m[10] + v[14] * m[11];
		t[14] = v[2] * m[12] + v[6] * m[13] + v[10] * m[14] + v[14] * m[15];
		t[3] = v[3] * m[0] + v[7] * m[1] + v[11] * m[2] + v[15] * m[3];
		t[7] = v[3] * m[4] + v[7] * m[5] + v[11] * m[6] + v[15] * m[7];
		t[11] = v[3] * m[8] + v[7] * m[9] + v[11] * m[10] + v[15] * m[11];
		t[15] = v[3] * m[12] + v[7] * m[13] + v[11] * m[14] + v[15] * m[15];
		return this.set(this.temp);
	}
	multiplyLeft(matrix) {
		let t = this.temp;
		let v = this.values;
		let m = matrix.values;
		t[0] = m[0] * v[0] + m[4] * v[1] + m[8] * v[2] + m[12] * v[3];
		t[4] = m[0] * v[4] + m[4] * v[5] + m[8] * v[6] + m[12] * v[7];
		t[8] = m[0] * v[8] + m[4] * v[9] + m[8] * v[10] + m[12] * v[11];
		t[12] = m[0] * v[12] + m[4] * v[13] + m[8] * v[14] + m[12] * v[15];
		t[1] = m[1] * v[0] + m[5] * v[1] + m[9] * v[2] + m[13] * v[3];
		t[5] = m[1] * v[4] + m[5] * v[5] + m[9] * v[6] + m[13] * v[7];
		t[9] = m[1] * v[8] + m[5] * v[9] + m[9] * v[10] + m[13] * v[11];
		t[13] = m[1] * v[12] + m[5] * v[13] + m[9] * v[14] + m[13] * v[15];
		t[2] = m[2] * v[0] + m[6] * v[1] + m[10] * v[2] + m[14] * v[3];
		t[6] = m[2] * v[4] + m[6] * v[5] + m[10] * v[6] + m[14] * v[7];
		t[10] = m[2] * v[8] + m[6] * v[9] + m[10] * v[10] + m[14] * v[11];
		t[14] = m[2] * v[12] + m[6] * v[13] + m[10] * v[14] + m[14] * v[15];
		t[3] = m[3] * v[0] + m[7] * v[1] + m[11] * v[2] + m[15] * v[3];
		t[7] = m[3] * v[4] + m[7] * v[5] + m[11] * v[6] + m[15] * v[7];
		t[11] = m[3] * v[8] + m[7] * v[9] + m[11] * v[10] + m[15] * v[11];
		t[15] = m[3] * v[12] + m[7] * v[13] + m[11] * v[14] + m[15] * v[15];
		return this.set(this.temp);
	}
	lookAt(position, direction, up) {
		Matrix4$2.initTemps();
		let xAxis = Matrix4$2.xAxis, yAxis = Matrix4$2.yAxis, zAxis = Matrix4$2.zAxis;
		zAxis.setFrom(direction).normalize();
		xAxis.setFrom(direction).normalize();
		xAxis.cross(up).normalize();
		yAxis.setFrom(xAxis).cross(zAxis).normalize();
		this.identity();
		let val = this.values;
		val[0] = xAxis.x;
		val[4] = xAxis.y;
		val[8] = xAxis.z;
		val[1] = yAxis.x;
		val[5] = yAxis.y;
		val[9] = yAxis.z;
		val[2] = -zAxis.x;
		val[6] = -zAxis.y;
		val[10] = -zAxis.z;
		Matrix4$2.tmpMatrix.identity();
		Matrix4$2.tmpMatrix.values[12] = -position.x;
		Matrix4$2.tmpMatrix.values[13] = -position.y;
		Matrix4$2.tmpMatrix.values[14] = -position.z;
		this.multiply(Matrix4$2.tmpMatrix);
		return this;
	}
	static initTemps() {
		if (Matrix4$2.xAxis === null) Matrix4$2.xAxis = new Vector3$2();
		if (Matrix4$2.yAxis === null) Matrix4$2.yAxis = new Vector3$2();
		if (Matrix4$2.zAxis === null) Matrix4$2.zAxis = new Vector3$2();
	}
};
Matrix4$2.xAxis = null;
Matrix4$2.yAxis = null;
Matrix4$2.zAxis = null;
Matrix4$2.tmpMatrix = new Matrix4$2();
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/Camera.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var OrthoCamera$2 = class {
	constructor(viewportWidth, viewportHeight) {
		this.position = new Vector3$2(0, 0, 0);
		this.direction = new Vector3$2(0, 0, -1);
		this.up = new Vector3$2(0, 1, 0);
		this.near = 0;
		this.far = 100;
		this.zoom = 1;
		this.viewportWidth = 0;
		this.viewportHeight = 0;
		this.projectionView = new Matrix4$2();
		this.inverseProjectionView = new Matrix4$2();
		this.projection = new Matrix4$2();
		this.view = new Matrix4$2();
		this.viewportWidth = viewportWidth;
		this.viewportHeight = viewportHeight;
		this.update();
	}
	update() {
		let projection = this.projection;
		let view = this.view;
		let projectionView = this.projectionView;
		let inverseProjectionView = this.inverseProjectionView;
		let zoom = this.zoom, viewportWidth = this.viewportWidth, viewportHeight = this.viewportHeight;
		projection.ortho(zoom * (-viewportWidth / 2), zoom * (viewportWidth / 2), zoom * (-viewportHeight / 2), zoom * (viewportHeight / 2), this.near, this.far);
		view.lookAt(this.position, this.direction, this.up);
		projectionView.set(projection.values);
		projectionView.multiply(view);
		inverseProjectionView.set(projectionView.values).invert();
	}
	screenToWorld(screenCoords, screenWidth, screenHeight) {
		let x = screenCoords.x, y = screenHeight - screenCoords.y - 1;
		screenCoords.x = 2 * x / screenWidth - 1;
		screenCoords.y = 2 * y / screenHeight - 1;
		screenCoords.z = 2 * screenCoords.z - 1;
		screenCoords.project(this.inverseProjectionView);
		return screenCoords;
	}
	worldToScreen(worldCoords, screenWidth, screenHeight) {
		worldCoords.project(this.projectionView);
		worldCoords.x = screenWidth * (worldCoords.x + 1) / 2;
		worldCoords.y = screenHeight * (worldCoords.y + 1) / 2;
		worldCoords.z = (worldCoords.z + 1) / 2;
		return worldCoords;
	}
	setViewport(viewportWidth, viewportHeight) {
		this.viewportWidth = viewportWidth;
		this.viewportHeight = viewportHeight;
	}
};
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/Input.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Input$2 = class {
	constructor(element) {
		this.mouseX = 0;
		this.mouseY = 0;
		this.buttonDown = false;
		this.touch0 = null;
		this.touch1 = null;
		this.initialPinchDistance = 0;
		this.listeners = new Array();
		this.eventListeners = [];
		this.element = element;
		this.setupCallbacks(element);
	}
	setupCallbacks(element) {
		let mouseDown = (ev) => {
			if (ev instanceof MouseEvent) {
				let rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.buttonDown = true;
				this.listeners.map((listener) => {
					if (listener.down) listener.down(this.mouseX, this.mouseY);
				});
				document.addEventListener("mousemove", mouseMove);
				document.addEventListener("mouseup", mouseUp);
			}
		};
		let mouseMove = (ev) => {
			if (ev instanceof MouseEvent) {
				let rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.listeners.map((listener) => {
					if (this.buttonDown) {
						if (listener.dragged) listener.dragged(this.mouseX, this.mouseY);
					} else if (listener.moved) listener.moved(this.mouseX, this.mouseY);
				});
			}
		};
		let mouseUp = (ev) => {
			if (ev instanceof MouseEvent) {
				let rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.buttonDown = false;
				this.listeners.map((listener) => {
					if (listener.up) listener.up(this.mouseX, this.mouseY);
				});
				document.removeEventListener("mousemove", mouseMove);
				document.removeEventListener("mouseup", mouseUp);
			}
		};
		let mouseWheel = (e) => {
			e.preventDefault();
			let deltaY = e.deltaY;
			if (e.deltaMode == WheelEvent.DOM_DELTA_LINE) deltaY *= 8;
			if (e.deltaMode == WheelEvent.DOM_DELTA_PAGE) deltaY *= 24;
			this.listeners.map((listener) => {
				if (listener.wheel) listener.wheel(e.deltaY);
			});
		};
		element.addEventListener("mousedown", mouseDown, true);
		element.addEventListener("mousemove", mouseMove, true);
		element.addEventListener("mouseup", mouseUp, true);
		element.addEventListener("wheel", mouseWheel, true);
		element.addEventListener("touchstart", (ev) => {
			if (!this.touch0 || !this.touch1) {
				let nativeTouch = ev.changedTouches.item(0);
				let rect = element.getBoundingClientRect();
				let x = nativeTouch.clientX - rect.left;
				let y = nativeTouch.clientY - rect.top;
				let touch = new Touch$2(nativeTouch.identifier, x, y);
				this.mouseX = x;
				this.mouseY = y;
				this.buttonDown = true;
				if (!this.touch0) {
					this.touch0 = touch;
					this.listeners.map((listener) => {
						if (listener.down) listener.down(touch.x, touch.y);
					});
				} else if (!this.touch1) {
					this.touch1 = touch;
					let dx = this.touch1.x - this.touch0.x;
					let dy = this.touch1.x - this.touch0.x;
					this.initialPinchDistance = Math.sqrt(dx * dx + dy * dy);
					this.listeners.map((listener) => {
						if (listener.zoom) listener.zoom(this.initialPinchDistance, this.initialPinchDistance);
					});
				}
			}
			ev.preventDefault();
		}, false);
		element.addEventListener("touchmove", (ev) => {
			if (this.touch0) {
				var touches = ev.changedTouches;
				let rect = element.getBoundingClientRect();
				for (var i = 0; i < touches.length; i++) {
					var nativeTouch = touches[i];
					let x = nativeTouch.clientX - rect.left;
					let y = nativeTouch.clientY - rect.top;
					if (this.touch0.identifier === nativeTouch.identifier) {
						this.touch0.x = this.mouseX = x;
						this.touch0.y = this.mouseY = y;
						this.listeners.map((listener) => {
							if (listener.dragged) listener.dragged(x, y);
						});
					}
					if (this.touch1 && this.touch1.identifier === nativeTouch.identifier) {
						this.touch1.x = this.mouseX = x;
						this.touch1.y = this.mouseY = y;
					}
				}
				if (this.touch0 && this.touch1) {
					let dx = this.touch1.x - this.touch0.x;
					let dy = this.touch1.x - this.touch0.x;
					let distance = Math.sqrt(dx * dx + dy * dy);
					this.listeners.map((listener) => {
						if (listener.zoom) listener.zoom(this.initialPinchDistance, distance);
					});
				}
			}
			ev.preventDefault();
		}, false);
		let touchEnd = (ev) => {
			if (this.touch0) {
				var touches = ev.changedTouches;
				let rect = element.getBoundingClientRect();
				for (var i = 0; i < touches.length; i++) {
					var nativeTouch = touches[i];
					let x = nativeTouch.clientX - rect.left;
					let y = nativeTouch.clientY - rect.top;
					if (this.touch0.identifier === nativeTouch.identifier) {
						this.touch0 = null;
						this.mouseX = x;
						this.mouseY = y;
						this.listeners.map((listener) => {
							if (listener.up) listener.up(x, y);
						});
						if (!this.touch1) {
							this.buttonDown = false;
							break;
						} else {
							this.touch0 = this.touch1;
							this.touch1 = null;
							this.mouseX = this.touch0.x;
							this.mouseX = this.touch0.x;
							this.buttonDown = true;
							this.listeners.map((listener) => {
								if (listener.down) listener.down(this.touch0.x, this.touch0.y);
							});
						}
					}
					if (this.touch1 && this.touch1.identifier) this.touch1 = null;
				}
			}
			ev.preventDefault();
		};
		element.addEventListener("touchend", touchEnd, false);
		element.addEventListener("touchcancel", touchEnd);
	}
	addListener(listener) {
		this.listeners.push(listener);
	}
	removeListener(listener) {
		let idx = this.listeners.indexOf(listener);
		if (idx > -1) this.listeners.splice(idx, 1);
	}
};
var Touch$2 = class {
	constructor(identifier, x, y) {
		this.identifier = identifier;
		this.x = x;
		this.y = y;
	}
};
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/Shader.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Shader$2 = class Shader$2 {
	getProgram() {
		return this.program;
	}
	getVertexShader() {
		return this.vertexShader;
	}
	getFragmentShader() {
		return this.fragmentShader;
	}
	getVertexShaderSource() {
		return this.vsSource;
	}
	getFragmentSource() {
		return this.fsSource;
	}
	constructor(context, vertexShader, fragmentShader) {
		this.vertexShader = vertexShader;
		this.fragmentShader = fragmentShader;
		this.vs = null;
		this.fs = null;
		this.program = null;
		this.tmp2x2 = /* @__PURE__ */ new Float32Array(4);
		this.tmp3x3 = /* @__PURE__ */ new Float32Array(9);
		this.tmp4x4 = /* @__PURE__ */ new Float32Array(16);
		this.vsSource = vertexShader;
		this.fsSource = fragmentShader;
		this.context = context instanceof ManagedWebGLRenderingContext$2 ? context : new ManagedWebGLRenderingContext$2(context);
		this.context.addRestorable(this);
		this.compile();
	}
	compile() {
		let gl = this.context.gl;
		try {
			this.vs = this.compileShader(gl.VERTEX_SHADER, this.vertexShader);
			this.fs = this.compileShader(gl.FRAGMENT_SHADER, this.fragmentShader);
			this.program = this.compileProgram(this.vs, this.fs);
		} catch (e) {
			this.dispose();
			throw e;
		}
	}
	compileShader(type, source) {
		let gl = this.context.gl;
		let shader = gl.createShader(type);
		gl.shaderSource(shader, source);
		gl.compileShader(shader);
		if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
			let error = "Couldn't compile shader: " + gl.getShaderInfoLog(shader);
			gl.deleteShader(shader);
			if (!gl.isContextLost()) throw new Error(error);
		}
		return shader;
	}
	compileProgram(vs, fs) {
		let gl = this.context.gl;
		let program = gl.createProgram();
		gl.attachShader(program, vs);
		gl.attachShader(program, fs);
		gl.linkProgram(program);
		if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
			let error = "Couldn't compile shader program: " + gl.getProgramInfoLog(program);
			gl.deleteProgram(program);
			if (!gl.isContextLost()) throw new Error(error);
		}
		return program;
	}
	restore() {
		this.compile();
	}
	bind() {
		this.context.gl.useProgram(this.program);
	}
	unbind() {
		this.context.gl.useProgram(null);
	}
	setUniformi(uniform, value) {
		this.context.gl.uniform1i(this.getUniformLocation(uniform), value);
	}
	setUniformf(uniform, value) {
		this.context.gl.uniform1f(this.getUniformLocation(uniform), value);
	}
	setUniform2f(uniform, value, value2) {
		this.context.gl.uniform2f(this.getUniformLocation(uniform), value, value2);
	}
	setUniform3f(uniform, value, value2, value3) {
		this.context.gl.uniform3f(this.getUniformLocation(uniform), value, value2, value3);
	}
	setUniform4f(uniform, value, value2, value3, value4) {
		this.context.gl.uniform4f(this.getUniformLocation(uniform), value, value2, value3, value4);
	}
	setUniform2x2f(uniform, value) {
		let gl = this.context.gl;
		this.tmp2x2.set(value);
		gl.uniformMatrix2fv(this.getUniformLocation(uniform), false, this.tmp2x2);
	}
	setUniform3x3f(uniform, value) {
		let gl = this.context.gl;
		this.tmp3x3.set(value);
		gl.uniformMatrix3fv(this.getUniformLocation(uniform), false, this.tmp3x3);
	}
	setUniform4x4f(uniform, value) {
		let gl = this.context.gl;
		this.tmp4x4.set(value);
		gl.uniformMatrix4fv(this.getUniformLocation(uniform), false, this.tmp4x4);
	}
	getUniformLocation(uniform) {
		let gl = this.context.gl;
		let location = gl.getUniformLocation(this.program, uniform);
		if (!location && !gl.isContextLost()) throw new Error(`Couldn't find location for uniform ${uniform}`);
		return location;
	}
	getAttributeLocation(attribute) {
		let gl = this.context.gl;
		let location = gl.getAttribLocation(this.program, attribute);
		if (location == -1 && !gl.isContextLost()) throw new Error(`Couldn't find location for attribute ${attribute}`);
		return location;
	}
	dispose() {
		this.context.removeRestorable(this);
		let gl = this.context.gl;
		if (this.vs) {
			gl.deleteShader(this.vs);
			this.vs = null;
		}
		if (this.fs) {
			gl.deleteShader(this.fs);
			this.fs = null;
		}
		if (this.program) {
			gl.deleteProgram(this.program);
			this.program = null;
		}
	}
	static newColoredTextured(context) {
		let vs = `
				attribute vec4 ${Shader$2.POSITION};
				attribute vec4 ${Shader$2.COLOR};
				attribute vec2 ${Shader$2.TEXCOORDS};
				uniform mat4 ${Shader$2.MVP_MATRIX};
				varying vec4 v_color;
				varying vec2 v_texCoords;

				void main () {
					v_color = ${Shader$2.COLOR};
					v_texCoords = ${Shader$2.TEXCOORDS};
					gl_Position = ${Shader$2.MVP_MATRIX} * ${Shader$2.POSITION};
				}
			`;
		return new Shader$2(context, vs, `
				#ifdef GL_ES
					#define LOWP lowp
					precision mediump float;
				#else
					#define LOWP
				#endif
				varying LOWP vec4 v_color;
				varying vec2 v_texCoords;
				uniform sampler2D u_texture;

				void main () {
					gl_FragColor = v_color * texture2D(u_texture, v_texCoords);
				}
			`);
	}
	static newTwoColoredTextured(context) {
		let vs = `
				attribute vec4 ${Shader$2.POSITION};
				attribute vec4 ${Shader$2.COLOR};
				attribute vec4 ${Shader$2.COLOR2};
				attribute vec2 ${Shader$2.TEXCOORDS};
				uniform mat4 ${Shader$2.MVP_MATRIX};
				varying vec4 v_light;
				varying vec4 v_dark;
				varying vec2 v_texCoords;

				void main () {
					v_light = ${Shader$2.COLOR};
					v_dark = ${Shader$2.COLOR2};
					v_texCoords = ${Shader$2.TEXCOORDS};
					gl_Position = ${Shader$2.MVP_MATRIX} * ${Shader$2.POSITION};
				}
			`;
		return new Shader$2(context, vs, `
				#ifdef GL_ES
					#define LOWP lowp
					precision mediump float;
				#else
					#define LOWP
				#endif
				varying LOWP vec4 v_light;
				varying LOWP vec4 v_dark;
				varying vec2 v_texCoords;
				uniform sampler2D u_texture;

				void main () {
					vec4 texColor = texture2D(u_texture, v_texCoords);
					gl_FragColor.a = texColor.a * v_light.a;
					gl_FragColor.rgb = ((texColor.a - 1.0) * v_dark.a + 1.0 - texColor.rgb) * v_dark.rgb + texColor.rgb * v_light.rgb;
				}
			`);
	}
	static newColored(context) {
		let vs = `
				attribute vec4 ${Shader$2.POSITION};
				attribute vec4 ${Shader$2.COLOR};
				uniform mat4 ${Shader$2.MVP_MATRIX};
				varying vec4 v_color;

				void main () {
					v_color = ${Shader$2.COLOR};
					gl_Position = ${Shader$2.MVP_MATRIX} * ${Shader$2.POSITION};
				}
			`;
		return new Shader$2(context, vs, `
				#ifdef GL_ES
					#define LOWP lowp
					precision mediump float;
				#else
					#define LOWP
				#endif
				varying LOWP vec4 v_color;

				void main () {
					gl_FragColor = v_color;
				}
			`);
	}
};
Shader$2.MVP_MATRIX = "u_projTrans";
Shader$2.POSITION = "a_position";
Shader$2.COLOR = "a_color";
Shader$2.COLOR2 = "a_color2";
Shader$2.TEXCOORDS = "a_texCoords";
Shader$2.SAMPLER = "u_texture";
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/Mesh.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Mesh$2 = class {
	getAttributes() {
		return this.attributes;
	}
	maxVertices() {
		return this.vertices.length / this.elementsPerVertex;
	}
	numVertices() {
		return this.verticesLength / this.elementsPerVertex;
	}
	setVerticesLength(length) {
		this.dirtyVertices = true;
		this.verticesLength = length;
	}
	getVertices() {
		return this.vertices;
	}
	maxIndices() {
		return this.indices.length;
	}
	numIndices() {
		return this.indicesLength;
	}
	setIndicesLength(length) {
		this.dirtyIndices = true;
		this.indicesLength = length;
	}
	getIndices() {
		return this.indices;
	}
	getVertexSizeInFloats() {
		let size = 0;
		for (var i = 0; i < this.attributes.length; i++) {
			let attribute = this.attributes[i];
			size += attribute.numElements;
		}
		return size;
	}
	constructor(context, attributes, maxVertices, maxIndices) {
		this.attributes = attributes;
		this.verticesLength = 0;
		this.dirtyVertices = false;
		this.indicesLength = 0;
		this.dirtyIndices = false;
		this.elementsPerVertex = 0;
		this.context = context instanceof ManagedWebGLRenderingContext$2 ? context : new ManagedWebGLRenderingContext$2(context);
		this.elementsPerVertex = 0;
		for (let i = 0; i < attributes.length; i++) this.elementsPerVertex += attributes[i].numElements;
		this.vertices = new Float32Array(maxVertices * this.elementsPerVertex);
		this.indices = new Uint16Array(maxIndices);
		this.context.addRestorable(this);
	}
	setVertices(vertices) {
		this.dirtyVertices = true;
		if (vertices.length > this.vertices.length) throw Error("Mesh can't store more than " + this.maxVertices() + " vertices");
		this.vertices.set(vertices, 0);
		this.verticesLength = vertices.length;
	}
	setIndices(indices) {
		this.dirtyIndices = true;
		if (indices.length > this.indices.length) throw Error("Mesh can't store more than " + this.maxIndices() + " indices");
		this.indices.set(indices, 0);
		this.indicesLength = indices.length;
	}
	draw(shader, primitiveType) {
		this.drawWithOffset(shader, primitiveType, 0, this.indicesLength > 0 ? this.indicesLength : this.verticesLength / this.elementsPerVertex);
	}
	drawWithOffset(shader, primitiveType, offset, count) {
		let gl = this.context.gl;
		if (this.dirtyVertices || this.dirtyIndices) this.update();
		this.bind(shader);
		if (this.indicesLength > 0) gl.drawElements(primitiveType, count, gl.UNSIGNED_SHORT, offset * 2);
		else gl.drawArrays(primitiveType, offset, count);
		this.unbind(shader);
	}
	bind(shader) {
		let gl = this.context.gl;
		gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);
		let offset = 0;
		for (let i = 0; i < this.attributes.length; i++) {
			let attrib = this.attributes[i];
			let location = shader.getAttributeLocation(attrib.name);
			gl.enableVertexAttribArray(location);
			gl.vertexAttribPointer(location, attrib.numElements, gl.FLOAT, false, this.elementsPerVertex * 4, offset * 4);
			offset += attrib.numElements;
		}
		if (this.indicesLength > 0) gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indicesBuffer);
	}
	unbind(shader) {
		let gl = this.context.gl;
		for (let i = 0; i < this.attributes.length; i++) {
			let attrib = this.attributes[i];
			let location = shader.getAttributeLocation(attrib.name);
			gl.disableVertexAttribArray(location);
		}
		gl.bindBuffer(gl.ARRAY_BUFFER, null);
		if (this.indicesLength > 0) gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null);
	}
	update() {
		let gl = this.context.gl;
		if (this.dirtyVertices) {
			if (!this.verticesBuffer) this.verticesBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);
			gl.bufferData(gl.ARRAY_BUFFER, this.vertices.subarray(0, this.verticesLength), gl.DYNAMIC_DRAW);
			this.dirtyVertices = false;
		}
		if (this.dirtyIndices) {
			if (!this.indicesBuffer) this.indicesBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indicesBuffer);
			gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.indices.subarray(0, this.indicesLength), gl.DYNAMIC_DRAW);
			this.dirtyIndices = false;
		}
	}
	restore() {
		this.verticesBuffer = null;
		this.indicesBuffer = null;
		this.update();
	}
	dispose() {
		this.context.removeRestorable(this);
		let gl = this.context.gl;
		gl.deleteBuffer(this.verticesBuffer);
		gl.deleteBuffer(this.indicesBuffer);
	}
};
var VertexAttribute$2 = class {
	constructor(name, type, numElements) {
		this.name = name;
		this.type = type;
		this.numElements = numElements;
	}
};
var Position2Attribute$2 = class extends VertexAttribute$2 {
	constructor() {
		super(Shader$2.POSITION, VertexAttributeType$2.Float, 2);
	}
};
var TexCoordAttribute$2 = class extends VertexAttribute$2 {
	constructor(unit = 0) {
		super(Shader$2.TEXCOORDS + (unit == 0 ? "" : unit), VertexAttributeType$2.Float, 2);
	}
};
var ColorAttribute$2 = class extends VertexAttribute$2 {
	constructor() {
		super(Shader$2.COLOR, VertexAttributeType$2.Float, 4);
	}
};
var Color2Attribute$2 = class extends VertexAttribute$2 {
	constructor() {
		super(Shader$2.COLOR2, VertexAttributeType$2.Float, 4);
	}
};
var VertexAttributeType$2;
(function(VertexAttributeType) {
	VertexAttributeType[VertexAttributeType["Float"] = 0] = "Float";
})(VertexAttributeType$2 || (VertexAttributeType$2 = {}));
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/PolygonBatcher.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var PolygonBatcher$2 = class {
	constructor(context, twoColorTint = true, maxVertices = 10920) {
		this.isDrawing = false;
		this.shader = null;
		this.lastTexture = null;
		this.verticesLength = 0;
		this.indicesLength = 0;
		if (maxVertices > 10920) throw new Error("Can't have more than 10920 triangles per batch: " + maxVertices);
		this.context = context instanceof ManagedWebGLRenderingContext$2 ? context : new ManagedWebGLRenderingContext$2(context);
		let attributes = twoColorTint ? [
			new Position2Attribute$2(),
			new ColorAttribute$2(),
			new TexCoordAttribute$2(),
			new Color2Attribute$2()
		] : [
			new Position2Attribute$2(),
			new ColorAttribute$2(),
			new TexCoordAttribute$2()
		];
		this.mesh = new Mesh$2(context, attributes, maxVertices, maxVertices * 3);
		let gl = this.context.gl;
		this.srcColorBlend = gl.SRC_ALPHA;
		this.srcAlphaBlend = gl.ONE;
		this.dstBlend = gl.ONE_MINUS_SRC_ALPHA;
	}
	begin(shader) {
		if (this.isDrawing) throw new Error("PolygonBatch is already drawing. Call PolygonBatch.end() before calling PolygonBatch.begin()");
		this.drawCalls = 0;
		this.shader = shader;
		this.lastTexture = null;
		this.isDrawing = true;
		let gl = this.context.gl;
		gl.enable(gl.BLEND);
		gl.blendFuncSeparate(this.srcColorBlend, this.dstBlend, this.srcAlphaBlend, this.dstBlend);
	}
	setBlendMode(srcColorBlend, srcAlphaBlend, dstBlend) {
		if (this.srcColorBlend == srcColorBlend && this.srcAlphaBlend == srcAlphaBlend && this.dstBlend == dstBlend) return;
		this.srcColorBlend = srcColorBlend;
		this.srcAlphaBlend = srcAlphaBlend;
		this.dstBlend = dstBlend;
		if (this.isDrawing) {
			this.flush();
			this.context.gl.blendFuncSeparate(srcColorBlend, dstBlend, srcAlphaBlend, dstBlend);
		}
	}
	draw(texture, vertices, indices) {
		if (texture != this.lastTexture) {
			this.flush();
			this.lastTexture = texture;
		} else if (this.verticesLength + vertices.length > this.mesh.getVertices().length || this.indicesLength + indices.length > this.mesh.getIndices().length) this.flush();
		let indexStart = this.mesh.numVertices();
		this.mesh.getVertices().set(vertices, this.verticesLength);
		this.verticesLength += vertices.length;
		this.mesh.setVerticesLength(this.verticesLength);
		let indicesArray = this.mesh.getIndices();
		for (let i = this.indicesLength, j = 0; j < indices.length; i++, j++) indicesArray[i] = indices[j] + indexStart;
		this.indicesLength += indices.length;
		this.mesh.setIndicesLength(this.indicesLength);
	}
	flush() {
		if (this.verticesLength == 0) return;
		this.lastTexture.bind();
		this.mesh.draw(this.shader, this.context.gl.TRIANGLES);
		this.verticesLength = 0;
		this.indicesLength = 0;
		this.mesh.setVerticesLength(0);
		this.mesh.setIndicesLength(0);
		this.drawCalls++;
	}
	end() {
		if (!this.isDrawing) throw new Error("PolygonBatch is not drawing. Call PolygonBatch.begin() before calling PolygonBatch.end()");
		if (this.verticesLength > 0 || this.indicesLength > 0) this.flush();
		this.shader = null;
		this.lastTexture = null;
		this.isDrawing = false;
		let gl = this.context.gl;
		gl.disable(gl.BLEND);
	}
	getDrawCalls() {
		return this.drawCalls;
	}
	dispose() {
		this.mesh.dispose();
	}
};
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/ShapeRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var ShapeRenderer$2 = class {
	constructor(context, maxVertices = 10920) {
		this.isDrawing = false;
		this.shapeType = ShapeType$2.Filled;
		this.color = new Color(1, 1, 1, 1);
		this.vertexIndex = 0;
		this.tmp = new Vector2();
		if (maxVertices > 10920) throw new Error("Can't have more than 10920 triangles per batch: " + maxVertices);
		this.context = context instanceof ManagedWebGLRenderingContext$2 ? context : new ManagedWebGLRenderingContext$2(context);
		this.mesh = new Mesh$2(context, [new Position2Attribute$2(), new ColorAttribute$2()], maxVertices, 0);
		let gl = this.context.gl;
		this.srcColorBlend = gl.SRC_ALPHA;
		this.srcAlphaBlend = gl.ONE;
		this.dstBlend = gl.ONE_MINUS_SRC_ALPHA;
	}
	begin(shader) {
		if (this.isDrawing) throw new Error("ShapeRenderer.begin() has already been called");
		this.shader = shader;
		this.vertexIndex = 0;
		this.isDrawing = true;
		let gl = this.context.gl;
		gl.enable(gl.BLEND);
		gl.blendFuncSeparate(this.srcColorBlend, this.dstBlend, this.srcAlphaBlend, this.dstBlend);
	}
	setBlendMode(srcColorBlend, srcAlphaBlend, dstBlend) {
		this.srcColorBlend = srcColorBlend;
		this.srcAlphaBlend = srcAlphaBlend;
		this.dstBlend = dstBlend;
		if (this.isDrawing) {
			this.flush();
			this.context.gl.blendFuncSeparate(srcColorBlend, dstBlend, srcAlphaBlend, dstBlend);
		}
	}
	setColor(color) {
		this.color.setFromColor(color);
	}
	setColorWith(r, g, b, a) {
		this.color.set(r, g, b, a);
	}
	point(x, y, color = null) {
		this.check(ShapeType$2.Point, 1);
		if (color === null) color = this.color;
		this.vertex(x, y, color);
	}
	line(x, y, x2, y2, color = null) {
		this.check(ShapeType$2.Line, 2);
		this.mesh.getVertices();
		this.vertexIndex;
		if (color === null) color = this.color;
		this.vertex(x, y, color);
		this.vertex(x2, y2, color);
	}
	triangle(filled, x, y, x2, y2, x3, y3, color = null, color2 = null, color3 = null) {
		this.check(filled ? ShapeType$2.Filled : ShapeType$2.Line, 3);
		this.mesh.getVertices();
		this.vertexIndex;
		if (color === null) color = this.color;
		if (color2 === null) color2 = this.color;
		if (color3 === null) color3 = this.color;
		if (filled) {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
		} else {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x2, y2, color);
			this.vertex(x3, y3, color2);
			this.vertex(x3, y3, color);
			this.vertex(x, y, color2);
		}
	}
	quad(filled, x, y, x2, y2, x3, y3, x4, y4, color = null, color2 = null, color3 = null, color4 = null) {
		this.check(filled ? ShapeType$2.Filled : ShapeType$2.Line, 3);
		this.mesh.getVertices();
		this.vertexIndex;
		if (color === null) color = this.color;
		if (color2 === null) color2 = this.color;
		if (color3 === null) color3 = this.color;
		if (color4 === null) color4 = this.color;
		if (filled) {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
			this.vertex(x3, y3, color3);
			this.vertex(x4, y4, color4);
			this.vertex(x, y, color);
		} else {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
			this.vertex(x3, y3, color3);
			this.vertex(x4, y4, color4);
			this.vertex(x4, y4, color4);
			this.vertex(x, y, color);
		}
	}
	rect(filled, x, y, width, height, color = null) {
		this.quad(filled, x, y, x + width, y, x + width, y + height, x, y + height, color, color, color, color);
	}
	rectLine(filled, x1, y1, x2, y2, width, color = null) {
		this.check(filled ? ShapeType$2.Filled : ShapeType$2.Line, 8);
		if (color === null) color = this.color;
		let t = this.tmp.set(y2 - y1, x1 - x2);
		t.normalize();
		width *= .5;
		let tx = t.x * width;
		let ty = t.y * width;
		if (!filled) {
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
		} else {
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
		}
	}
	x(x, y, size) {
		this.line(x - size, y - size, x + size, y + size);
		this.line(x - size, y + size, x + size, y - size);
	}
	polygon(polygonVertices, offset, count, color = null) {
		if (count < 3) throw new Error("Polygon must contain at least 3 vertices");
		this.check(ShapeType$2.Line, count * 2);
		if (color === null) color = this.color;
		this.mesh.getVertices();
		this.vertexIndex;
		offset <<= 1;
		count <<= 1;
		let firstX = polygonVertices[offset];
		let firstY = polygonVertices[offset + 1];
		let last = offset + count;
		for (let i = offset, n = offset + count - 2; i < n; i += 2) {
			let x1 = polygonVertices[i];
			let y1 = polygonVertices[i + 1];
			let x2 = 0;
			let y2 = 0;
			if (i + 2 >= last) {
				x2 = firstX;
				y2 = firstY;
			} else {
				x2 = polygonVertices[i + 2];
				y2 = polygonVertices[i + 3];
			}
			this.vertex(x1, y1, color);
			this.vertex(x2, y2, color);
		}
	}
	circle(filled, x, y, radius, color = null, segments = 0) {
		if (segments === 0) segments = Math.max(1, 6 * MathUtils.cbrt(radius) | 0);
		if (segments <= 0) throw new Error("segments must be > 0.");
		if (color === null) color = this.color;
		let angle = 2 * MathUtils.PI / segments;
		let cos = Math.cos(angle);
		let sin = Math.sin(angle);
		let cx = radius, cy = 0;
		if (!filled) {
			this.check(ShapeType$2.Line, segments * 2 + 2);
			for (let i = 0; i < segments; i++) {
				this.vertex(x + cx, y + cy, color);
				let temp = cx;
				cx = cos * cx - sin * cy;
				cy = sin * temp + cos * cy;
				this.vertex(x + cx, y + cy, color);
			}
			this.vertex(x + cx, y + cy, color);
		} else {
			this.check(ShapeType$2.Filled, segments * 3 + 3);
			segments--;
			for (let i = 0; i < segments; i++) {
				this.vertex(x, y, color);
				this.vertex(x + cx, y + cy, color);
				let temp = cx;
				cx = cos * cx - sin * cy;
				cy = sin * temp + cos * cy;
				this.vertex(x + cx, y + cy, color);
			}
			this.vertex(x, y, color);
			this.vertex(x + cx, y + cy, color);
		}
		cx = radius;
		cy = 0;
		this.vertex(x + cx, y + cy, color);
	}
	curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color = null) {
		this.check(ShapeType$2.Line, segments * 2 + 2);
		if (color === null) color = this.color;
		let subdiv_step = 1 / segments;
		let subdiv_step2 = subdiv_step * subdiv_step;
		let subdiv_step3 = subdiv_step * subdiv_step * subdiv_step;
		let pre1 = 3 * subdiv_step;
		let pre2 = 3 * subdiv_step2;
		let pre4 = 6 * subdiv_step2;
		let pre5 = 6 * subdiv_step3;
		let tmp1x = x1 - cx1 * 2 + cx2;
		let tmp1y = y1 - cy1 * 2 + cy2;
		let tmp2x = (cx1 - cx2) * 3 - x1 + x2;
		let tmp2y = (cy1 - cy2) * 3 - y1 + y2;
		let fx = x1;
		let fy = y1;
		let dfx = (cx1 - x1) * pre1 + tmp1x * pre2 + tmp2x * subdiv_step3;
		let dfy = (cy1 - y1) * pre1 + tmp1y * pre2 + tmp2y * subdiv_step3;
		let ddfx = tmp1x * pre4 + tmp2x * pre5;
		let ddfy = tmp1y * pre4 + tmp2y * pre5;
		let dddfx = tmp2x * pre5;
		let dddfy = tmp2y * pre5;
		while (segments-- > 0) {
			this.vertex(fx, fy, color);
			fx += dfx;
			fy += dfy;
			dfx += ddfx;
			dfy += ddfy;
			ddfx += dddfx;
			ddfy += dddfy;
			this.vertex(fx, fy, color);
		}
		this.vertex(fx, fy, color);
		this.vertex(x2, y2, color);
	}
	vertex(x, y, color) {
		let idx = this.vertexIndex;
		let vertices = this.mesh.getVertices();
		vertices[idx++] = x;
		vertices[idx++] = y;
		vertices[idx++] = color.r;
		vertices[idx++] = color.g;
		vertices[idx++] = color.b;
		vertices[idx++] = color.a;
		this.vertexIndex = idx;
	}
	end() {
		if (!this.isDrawing) throw new Error("ShapeRenderer.begin() has not been called");
		this.flush();
		let gl = this.context.gl;
		gl.disable(gl.BLEND);
		this.isDrawing = false;
	}
	flush() {
		if (this.vertexIndex == 0) return;
		this.mesh.setVerticesLength(this.vertexIndex);
		this.mesh.draw(this.shader, this.shapeType);
		this.vertexIndex = 0;
	}
	check(shapeType, numVertices) {
		if (!this.isDrawing) throw new Error("ShapeRenderer.begin() has not been called");
		if (this.shapeType == shapeType) {
			if (this.mesh.maxVertices() - this.mesh.numVertices() < numVertices) this.flush();
			else return;
		} else {
			this.flush();
			this.shapeType = shapeType;
		}
	}
	dispose() {
		this.mesh.dispose();
	}
};
var ShapeType$2;
(function(ShapeType) {
	ShapeType[ShapeType["Point"] = 0] = "Point";
	ShapeType[ShapeType["Line"] = 1] = "Line";
	ShapeType[ShapeType["Filled"] = 4] = "Filled";
})(ShapeType$2 || (ShapeType$2 = {}));
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/SkeletonDebugRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var SkeletonDebugRenderer$2 = class SkeletonDebugRenderer$2 {
	constructor(context) {
		this.boneLineColor = new Color(1, 0, 0, 1);
		this.boneOriginColor = new Color(0, 1, 0, 1);
		this.attachmentLineColor = new Color(0, 0, 1, .5);
		this.triangleLineColor = new Color(1, .64, 0, .5);
		this.pathColor = new Color().setFromString("FF7F00");
		this.clipColor = new Color(.8, 0, 0, 2);
		this.aabbColor = new Color(0, 1, 0, .5);
		this.drawBones = true;
		this.drawRegionAttachments = true;
		this.drawBoundingBoxes = true;
		this.drawMeshHull = true;
		this.drawMeshTriangles = true;
		this.drawPaths = true;
		this.drawSkeletonXY = false;
		this.drawClipping = true;
		this.premultipliedAlpha = false;
		this.scale = 1;
		this.boneWidth = 2;
		this.bounds = new SkeletonBounds();
		this.temp = new Array();
		this.vertices = Utils.newFloatArray(2048);
		this.context = context instanceof ManagedWebGLRenderingContext$2 ? context : new ManagedWebGLRenderingContext$2(context);
	}
	draw(shapes, skeleton, ignoredBones = null) {
		let skeletonX = skeleton.x;
		let skeletonY = skeleton.y;
		let gl = this.context.gl;
		let srcFunc = this.premultipliedAlpha ? gl.ONE : gl.SRC_ALPHA;
		shapes.setBlendMode(srcFunc, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
		let bones = skeleton.bones;
		if (this.drawBones) {
			shapes.setColor(this.boneLineColor);
			for (let i = 0, n = bones.length; i < n; i++) {
				let bone = bones[i];
				if (ignoredBones && ignoredBones.indexOf(bone.data.name) > -1) continue;
				if (!bone.parent) continue;
				let x = skeletonX + bone.data.length * bone.a + bone.worldX;
				let y = skeletonY + bone.data.length * bone.c + bone.worldY;
				shapes.rectLine(true, skeletonX + bone.worldX, skeletonY + bone.worldY, x, y, this.boneWidth * this.scale);
			}
			if (this.drawSkeletonXY) shapes.x(skeletonX, skeletonY, 4 * this.scale);
		}
		if (this.drawRegionAttachments) {
			shapes.setColor(this.attachmentLineColor);
			let slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				let attachment = slot.getAttachment();
				if (attachment instanceof RegionAttachment) {
					let regionAttachment = attachment;
					let vertices = this.vertices;
					regionAttachment.computeWorldVertices(slot.bone, vertices, 0, 2);
					shapes.line(vertices[0], vertices[1], vertices[2], vertices[3]);
					shapes.line(vertices[2], vertices[3], vertices[4], vertices[5]);
					shapes.line(vertices[4], vertices[5], vertices[6], vertices[7]);
					shapes.line(vertices[6], vertices[7], vertices[0], vertices[1]);
				}
			}
		}
		if (this.drawMeshHull || this.drawMeshTriangles) {
			let slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				if (!slot.bone.active) continue;
				let attachment = slot.getAttachment();
				if (!(attachment instanceof MeshAttachment)) continue;
				let mesh = attachment;
				let vertices = this.vertices;
				mesh.computeWorldVertices(slot, 0, mesh.worldVerticesLength, vertices, 0, 2);
				let triangles = mesh.triangles;
				let hullLength = mesh.hullLength;
				if (this.drawMeshTriangles) {
					shapes.setColor(this.triangleLineColor);
					for (let ii = 0, nn = triangles.length; ii < nn; ii += 3) {
						let v1 = triangles[ii] * 2, v2 = triangles[ii + 1] * 2, v3 = triangles[ii + 2] * 2;
						shapes.triangle(false, vertices[v1], vertices[v1 + 1], vertices[v2], vertices[v2 + 1], vertices[v3], vertices[v3 + 1]);
					}
				}
				if (this.drawMeshHull && hullLength > 0) {
					shapes.setColor(this.attachmentLineColor);
					hullLength = (hullLength >> 1) * 2;
					let lastX = vertices[hullLength - 2], lastY = vertices[hullLength - 1];
					for (let ii = 0, nn = hullLength; ii < nn; ii += 2) {
						let x = vertices[ii], y = vertices[ii + 1];
						shapes.line(x, y, lastX, lastY);
						lastX = x;
						lastY = y;
					}
				}
			}
		}
		if (this.drawBoundingBoxes) {
			let bounds = this.bounds;
			bounds.update(skeleton, true);
			shapes.setColor(this.aabbColor);
			shapes.rect(false, bounds.minX, bounds.minY, bounds.getWidth(), bounds.getHeight());
			let polygons = bounds.polygons;
			let boxes = bounds.boundingBoxes;
			for (let i = 0, n = polygons.length; i < n; i++) {
				let polygon = polygons[i];
				shapes.setColor(boxes[i].color);
				shapes.polygon(polygon, 0, polygon.length);
			}
		}
		if (this.drawPaths) {
			let slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				if (!slot.bone.active) continue;
				let attachment = slot.getAttachment();
				if (!(attachment instanceof PathAttachment)) continue;
				let path = attachment;
				let nn = path.worldVerticesLength;
				let world = this.temp = Utils.setArraySize(this.temp, nn, 0);
				path.computeWorldVertices(slot, 0, nn, world, 0, 2);
				let color = this.pathColor;
				let x1 = world[2], y1 = world[3], x2 = 0, y2 = 0;
				if (path.closed) {
					shapes.setColor(color);
					let cx1 = world[0], cy1 = world[1], cx2 = world[nn - 2], cy2 = world[nn - 1];
					x2 = world[nn - 4];
					y2 = world[nn - 3];
					shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, 32);
					shapes.setColor(SkeletonDebugRenderer$2.LIGHT_GRAY);
					shapes.line(x1, y1, cx1, cy1);
					shapes.line(x2, y2, cx2, cy2);
				}
				nn -= 4;
				for (let ii = 4; ii < nn; ii += 6) {
					let cx1 = world[ii], cy1 = world[ii + 1], cx2 = world[ii + 2], cy2 = world[ii + 3];
					x2 = world[ii + 4];
					y2 = world[ii + 5];
					shapes.setColor(color);
					shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, 32);
					shapes.setColor(SkeletonDebugRenderer$2.LIGHT_GRAY);
					shapes.line(x1, y1, cx1, cy1);
					shapes.line(x2, y2, cx2, cy2);
					x1 = x2;
					y1 = y2;
				}
			}
		}
		if (this.drawBones) {
			shapes.setColor(this.boneOriginColor);
			for (let i = 0, n = bones.length; i < n; i++) {
				let bone = bones[i];
				if (ignoredBones && ignoredBones.indexOf(bone.data.name) > -1) continue;
				shapes.circle(true, skeletonX + bone.worldX, skeletonY + bone.worldY, 3 * this.scale, SkeletonDebugRenderer$2.GREEN, 8);
			}
		}
		if (this.drawClipping) {
			let slots = skeleton.slots;
			shapes.setColor(this.clipColor);
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				if (!slot.bone.active) continue;
				let attachment = slot.getAttachment();
				if (!(attachment instanceof ClippingAttachment)) continue;
				let clip = attachment;
				let nn = clip.worldVerticesLength;
				let world = this.temp = Utils.setArraySize(this.temp, nn, 0);
				clip.computeWorldVertices(slot, 0, nn, world, 0, 2);
				for (let i = 0, n = world.length; i < n; i += 2) {
					let x = world[i];
					let y = world[i + 1];
					let x2 = world[(i + 2) % world.length];
					let y2 = world[(i + 3) % world.length];
					shapes.line(x, y, x2, y2);
				}
			}
		}
	}
	dispose() {}
};
SkeletonDebugRenderer$2.LIGHT_GRAY = new Color(192 / 255, 192 / 255, 192 / 255, 1);
SkeletonDebugRenderer$2.GREEN = new Color(0, 1, 0, 1);
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/SkeletonRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Renderable$2 = class {
	constructor(vertices, numVertices, numFloats) {
		this.vertices = vertices;
		this.numVertices = numVertices;
		this.numFloats = numFloats;
	}
};
var SkeletonRenderer$2 = class SkeletonRenderer$2 {
	constructor(context, twoColorTint = true) {
		this.premultipliedAlpha = false;
		this.vertexEffect = null;
		this.tempColor = new Color();
		this.tempColor2 = new Color();
		this.vertexSize = 8;
		this.twoColorTint = false;
		this.renderable = new Renderable$2(null, 0, 0);
		this.clipper = new SkeletonClipping();
		this.temp = new Vector2();
		this.temp2 = new Vector2();
		this.temp3 = new Color();
		this.temp4 = new Color();
		this.twoColorTint = twoColorTint;
		if (twoColorTint) this.vertexSize += 4;
		this.vertices = Utils.newFloatArray(this.vertexSize * 1024);
	}
	draw(batcher, skeleton, slotRangeStart = -1, slotRangeEnd = -1) {
		let clipper = this.clipper;
		let premultipliedAlpha = this.premultipliedAlpha;
		let twoColorTint = this.twoColorTint;
		let blendMode = null;
		let tempPos = this.temp;
		let tempUv = this.temp2;
		let tempLight = this.temp3;
		let tempDark = this.temp4;
		let renderable = this.renderable;
		let uvs = null;
		let triangles = null;
		let drawOrder = skeleton.drawOrder;
		let attachmentColor = null;
		let skeletonColor = skeleton.color;
		let vertexSize = twoColorTint ? 12 : 8;
		let inRange = false;
		if (slotRangeStart == -1) inRange = true;
		for (let i = 0, n = drawOrder.length; i < n; i++) {
			let clippedVertexSize = clipper.isClipping() ? 2 : vertexSize;
			let slot = drawOrder[i];
			if (!slot.bone.active) {
				clipper.clipEndWithSlot(slot);
				continue;
			}
			if (slotRangeStart >= 0 && slotRangeStart == slot.data.index) inRange = true;
			if (!inRange) {
				clipper.clipEndWithSlot(slot);
				continue;
			}
			if (slotRangeEnd >= 0 && slotRangeEnd == slot.data.index) inRange = false;
			let attachment = slot.getAttachment();
			let texture = null;
			if (attachment instanceof RegionAttachment) {
				let region = attachment;
				renderable.vertices = this.vertices;
				renderable.numVertices = 4;
				renderable.numFloats = clippedVertexSize << 2;
				region.computeWorldVertices(slot.bone, renderable.vertices, 0, clippedVertexSize);
				triangles = SkeletonRenderer$2.QUAD_TRIANGLES;
				uvs = region.uvs;
				texture = region.region.renderObject.page.texture;
				attachmentColor = region.color;
			} else if (attachment instanceof MeshAttachment) {
				let mesh = attachment;
				renderable.vertices = this.vertices;
				renderable.numVertices = mesh.worldVerticesLength >> 1;
				renderable.numFloats = renderable.numVertices * clippedVertexSize;
				if (renderable.numFloats > renderable.vertices.length) renderable.vertices = this.vertices = Utils.newFloatArray(renderable.numFloats);
				mesh.computeWorldVertices(slot, 0, mesh.worldVerticesLength, renderable.vertices, 0, clippedVertexSize);
				triangles = mesh.triangles;
				texture = mesh.region.renderObject.page.texture;
				uvs = mesh.uvs;
				attachmentColor = mesh.color;
			} else if (attachment instanceof ClippingAttachment) {
				let clip = attachment;
				clipper.clipStart(slot, clip);
				continue;
			} else {
				clipper.clipEndWithSlot(slot);
				continue;
			}
			if (texture) {
				let slotColor = slot.color;
				let finalColor = this.tempColor;
				finalColor.r = skeletonColor.r * slotColor.r * attachmentColor.r;
				finalColor.g = skeletonColor.g * slotColor.g * attachmentColor.g;
				finalColor.b = skeletonColor.b * slotColor.b * attachmentColor.b;
				finalColor.a = skeletonColor.a * slotColor.a * attachmentColor.a;
				if (premultipliedAlpha) {
					finalColor.r *= finalColor.a;
					finalColor.g *= finalColor.a;
					finalColor.b *= finalColor.a;
				}
				let darkColor = this.tempColor2;
				if (!slot.darkColor) darkColor.set(0, 0, 0, 1);
				else {
					if (premultipliedAlpha) {
						darkColor.r = slot.darkColor.r * finalColor.a;
						darkColor.g = slot.darkColor.g * finalColor.a;
						darkColor.b = slot.darkColor.b * finalColor.a;
					} else darkColor.setFromColor(slot.darkColor);
					darkColor.a = premultipliedAlpha ? 1 : 0;
				}
				let slotBlendMode = slot.data.blendMode;
				if (slotBlendMode != blendMode) {
					blendMode = slotBlendMode;
					batcher.setBlendMode(WebGLBlendModeConverter.getSourceColorGLBlendMode(blendMode, premultipliedAlpha), WebGLBlendModeConverter.getSourceAlphaGLBlendMode(blendMode), WebGLBlendModeConverter.getDestGLBlendMode(blendMode));
				}
				if (clipper.isClipping()) {
					clipper.clipTriangles(renderable.vertices, renderable.numFloats, triangles, triangles.length, uvs, finalColor, darkColor, twoColorTint);
					let clippedVertices = new Float32Array(clipper.clippedVertices);
					let clippedTriangles = clipper.clippedTriangles;
					if (this.vertexEffect) {
						let vertexEffect = this.vertexEffect;
						let verts = clippedVertices;
						if (!twoColorTint) for (let v = 0, n = clippedVertices.length; v < n; v += vertexSize) {
							tempPos.x = verts[v];
							tempPos.y = verts[v + 1];
							tempLight.set(verts[v + 2], verts[v + 3], verts[v + 4], verts[v + 5]);
							tempUv.x = verts[v + 6];
							tempUv.y = verts[v + 7];
							tempDark.set(0, 0, 0, 0);
							vertexEffect.transform(tempPos, tempUv, tempLight, tempDark);
							verts[v] = tempPos.x;
							verts[v + 1] = tempPos.y;
							verts[v + 2] = tempLight.r;
							verts[v + 3] = tempLight.g;
							verts[v + 4] = tempLight.b;
							verts[v + 5] = tempLight.a;
							verts[v + 6] = tempUv.x;
							verts[v + 7] = tempUv.y;
						}
						else for (let v = 0, n = clippedVertices.length; v < n; v += vertexSize) {
							tempPos.x = verts[v];
							tempPos.y = verts[v + 1];
							tempLight.set(verts[v + 2], verts[v + 3], verts[v + 4], verts[v + 5]);
							tempUv.x = verts[v + 6];
							tempUv.y = verts[v + 7];
							tempDark.set(verts[v + 8], verts[v + 9], verts[v + 10], verts[v + 11]);
							vertexEffect.transform(tempPos, tempUv, tempLight, tempDark);
							verts[v] = tempPos.x;
							verts[v + 1] = tempPos.y;
							verts[v + 2] = tempLight.r;
							verts[v + 3] = tempLight.g;
							verts[v + 4] = tempLight.b;
							verts[v + 5] = tempLight.a;
							verts[v + 6] = tempUv.x;
							verts[v + 7] = tempUv.y;
							verts[v + 8] = tempDark.r;
							verts[v + 9] = tempDark.g;
							verts[v + 10] = tempDark.b;
							verts[v + 11] = tempDark.a;
						}
					}
					batcher.draw(texture, clippedVertices, clippedTriangles);
				} else {
					let verts = renderable.vertices;
					if (this.vertexEffect) {
						let vertexEffect = this.vertexEffect;
						if (!twoColorTint) for (let v = 0, u = 0, n = renderable.numFloats; v < n; v += vertexSize, u += 2) {
							tempPos.x = verts[v];
							tempPos.y = verts[v + 1];
							tempUv.x = uvs[u];
							tempUv.y = uvs[u + 1];
							tempLight.setFromColor(finalColor);
							tempDark.set(0, 0, 0, 0);
							vertexEffect.transform(tempPos, tempUv, tempLight, tempDark);
							verts[v] = tempPos.x;
							verts[v + 1] = tempPos.y;
							verts[v + 2] = tempLight.r;
							verts[v + 3] = tempLight.g;
							verts[v + 4] = tempLight.b;
							verts[v + 5] = tempLight.a;
							verts[v + 6] = tempUv.x;
							verts[v + 7] = tempUv.y;
						}
						else for (let v = 0, u = 0, n = renderable.numFloats; v < n; v += vertexSize, u += 2) {
							tempPos.x = verts[v];
							tempPos.y = verts[v + 1];
							tempUv.x = uvs[u];
							tempUv.y = uvs[u + 1];
							tempLight.setFromColor(finalColor);
							tempDark.setFromColor(darkColor);
							vertexEffect.transform(tempPos, tempUv, tempLight, tempDark);
							verts[v] = tempPos.x;
							verts[v + 1] = tempPos.y;
							verts[v + 2] = tempLight.r;
							verts[v + 3] = tempLight.g;
							verts[v + 4] = tempLight.b;
							verts[v + 5] = tempLight.a;
							verts[v + 6] = tempUv.x;
							verts[v + 7] = tempUv.y;
							verts[v + 8] = tempDark.r;
							verts[v + 9] = tempDark.g;
							verts[v + 10] = tempDark.b;
							verts[v + 11] = tempDark.a;
						}
					} else if (!twoColorTint) for (let v = 2, u = 0, n = renderable.numFloats; v < n; v += vertexSize, u += 2) {
						verts[v] = finalColor.r;
						verts[v + 1] = finalColor.g;
						verts[v + 2] = finalColor.b;
						verts[v + 3] = finalColor.a;
						verts[v + 4] = uvs[u];
						verts[v + 5] = uvs[u + 1];
					}
					else for (let v = 2, u = 0, n = renderable.numFloats; v < n; v += vertexSize, u += 2) {
						verts[v] = finalColor.r;
						verts[v + 1] = finalColor.g;
						verts[v + 2] = finalColor.b;
						verts[v + 3] = finalColor.a;
						verts[v + 4] = uvs[u];
						verts[v + 5] = uvs[u + 1];
						verts[v + 6] = darkColor.r;
						verts[v + 7] = darkColor.g;
						verts[v + 8] = darkColor.b;
						verts[v + 9] = darkColor.a;
					}
					let view = renderable.vertices.subarray(0, renderable.numFloats);
					batcher.draw(texture, view, triangles);
				}
			}
			clipper.clipEndWithSlot(slot);
		}
		clipper.clipEnd();
	}
};
SkeletonRenderer$2.QUAD_TRIANGLES = [
	0,
	1,
	2,
	2,
	3,
	0
];
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/SceneRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var quad$2 = [
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0
];
var QUAD_TRIANGLES$2 = [
	0,
	1,
	2,
	2,
	3,
	0
];
var WHITE$2 = new Color(1, 1, 1, 1);
var SceneRenderer$2 = class {
	constructor(canvas, context, twoColorTint = true) {
		this.twoColorTint = false;
		this.canvas = canvas;
		this.context = context instanceof ManagedWebGLRenderingContext$2 ? context : new ManagedWebGLRenderingContext$2(context);
		this.twoColorTint = twoColorTint;
		this.camera = new OrthoCamera$2(canvas.width, canvas.height);
		this.batcherShader = twoColorTint ? Shader$2.newTwoColoredTextured(this.context) : Shader$2.newColoredTextured(this.context);
		this.batcher = new PolygonBatcher$2(this.context, twoColorTint);
		this.shapesShader = Shader$2.newColored(this.context);
		this.shapes = new ShapeRenderer$2(this.context);
		this.skeletonRenderer = new SkeletonRenderer$2(this.context, twoColorTint);
		this.skeletonDebugRenderer = new SkeletonDebugRenderer$2(this.context);
	}
	dispose() {
		this.batcher.dispose();
		this.batcherShader.dispose();
		this.shapes.dispose();
		this.shapesShader.dispose();
		this.skeletonDebugRenderer.dispose();
	}
	begin() {
		this.camera.update();
		this.enableRenderer(this.batcher);
	}
	drawSkeleton(skeleton, premultipliedAlpha = false, slotRangeStart = -1, slotRangeEnd = -1) {
		this.enableRenderer(this.batcher);
		this.skeletonRenderer.premultipliedAlpha = premultipliedAlpha;
		this.skeletonRenderer.draw(this.batcher, skeleton, slotRangeStart, slotRangeEnd);
	}
	drawSkeletonDebug(skeleton, premultipliedAlpha = false, ignoredBones = null) {
		this.enableRenderer(this.shapes);
		this.skeletonDebugRenderer.premultipliedAlpha = premultipliedAlpha;
		this.skeletonDebugRenderer.draw(this.shapes, skeleton, ignoredBones);
	}
	drawTexture(texture, x, y, width, height, color = null) {
		this.enableRenderer(this.batcher);
		if (color === null) color = WHITE$2;
		var i = 0;
		quad$2[i++] = x;
		quad$2[i++] = y;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = 0;
		quad$2[i++] = 1;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x + width;
		quad$2[i++] = y;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = 1;
		quad$2[i++] = 1;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x + width;
		quad$2[i++] = y + height;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = 1;
		quad$2[i++] = 0;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x;
		quad$2[i++] = y + height;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = 0;
		quad$2[i++] = 0;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i] = 0;
		}
		this.batcher.draw(texture, quad$2, QUAD_TRIANGLES$2);
	}
	drawTextureUV(texture, x, y, width, height, u, v, u2, v2, color = null) {
		this.enableRenderer(this.batcher);
		if (color === null) color = WHITE$2;
		var i = 0;
		quad$2[i++] = x;
		quad$2[i++] = y;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = u;
		quad$2[i++] = v;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x + width;
		quad$2[i++] = y;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = u2;
		quad$2[i++] = v;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x + width;
		quad$2[i++] = y + height;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = u2;
		quad$2[i++] = v2;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x;
		quad$2[i++] = y + height;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = u;
		quad$2[i++] = v2;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i] = 0;
		}
		this.batcher.draw(texture, quad$2, QUAD_TRIANGLES$2);
	}
	drawTextureRotated(texture, x, y, width, height, pivotX, pivotY, angle, color = null) {
		this.enableRenderer(this.batcher);
		if (color === null) color = WHITE$2;
		let worldOriginX = x + pivotX;
		let worldOriginY = y + pivotY;
		let fx = -pivotX;
		let fy = -pivotY;
		let fx2 = width - pivotX;
		let fy2 = height - pivotY;
		let p1x = fx;
		let p1y = fy;
		let p2x = fx;
		let p2y = fy2;
		let p3x = fx2;
		let p3y = fy2;
		let p4x = fx2;
		let p4y = fy;
		let x1 = 0;
		let y1 = 0;
		let x2 = 0;
		let y2 = 0;
		let x3 = 0;
		let y3 = 0;
		let x4 = 0;
		let y4 = 0;
		if (angle != 0) {
			let cos = MathUtils.cosDeg(angle);
			let sin = MathUtils.sinDeg(angle);
			x1 = cos * p1x - sin * p1y;
			y1 = sin * p1x + cos * p1y;
			x4 = cos * p2x - sin * p2y;
			y4 = sin * p2x + cos * p2y;
			x3 = cos * p3x - sin * p3y;
			y3 = sin * p3x + cos * p3y;
			x2 = x3 + (x1 - x4);
			y2 = y3 + (y1 - y4);
		} else {
			x1 = p1x;
			y1 = p1y;
			x4 = p2x;
			y4 = p2y;
			x3 = p3x;
			y3 = p3y;
			x2 = p4x;
			y2 = p4y;
		}
		x1 += worldOriginX;
		y1 += worldOriginY;
		x2 += worldOriginX;
		y2 += worldOriginY;
		x3 += worldOriginX;
		y3 += worldOriginY;
		x4 += worldOriginX;
		y4 += worldOriginY;
		var i = 0;
		quad$2[i++] = x1;
		quad$2[i++] = y1;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = 0;
		quad$2[i++] = 1;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x2;
		quad$2[i++] = y2;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = 1;
		quad$2[i++] = 1;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x3;
		quad$2[i++] = y3;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = 1;
		quad$2[i++] = 0;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x4;
		quad$2[i++] = y4;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = 0;
		quad$2[i++] = 0;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i] = 0;
		}
		this.batcher.draw(texture, quad$2, QUAD_TRIANGLES$2);
	}
	drawRegion(region, x, y, width, height, color = null) {
		this.enableRenderer(this.batcher);
		if (color === null) color = WHITE$2;
		var i = 0;
		quad$2[i++] = x;
		quad$2[i++] = y;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = region.u;
		quad$2[i++] = region.v2;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x + width;
		quad$2[i++] = y;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = region.u2;
		quad$2[i++] = region.v2;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x + width;
		quad$2[i++] = y + height;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = region.u2;
		quad$2[i++] = region.v;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
		}
		quad$2[i++] = x;
		quad$2[i++] = y + height;
		quad$2[i++] = color.r;
		quad$2[i++] = color.g;
		quad$2[i++] = color.b;
		quad$2[i++] = color.a;
		quad$2[i++] = region.u;
		quad$2[i++] = region.v;
		if (this.twoColorTint) {
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i++] = 0;
			quad$2[i] = 0;
		}
		this.batcher.draw(region.page.texture, quad$2, QUAD_TRIANGLES$2);
	}
	line(x, y, x2, y2, color = null, color2 = null) {
		this.enableRenderer(this.shapes);
		this.shapes.line(x, y, x2, y2, color);
	}
	triangle(filled, x, y, x2, y2, x3, y3, color = null, color2 = null, color3 = null) {
		this.enableRenderer(this.shapes);
		this.shapes.triangle(filled, x, y, x2, y2, x3, y3, color, color2, color3);
	}
	quad(filled, x, y, x2, y2, x3, y3, x4, y4, color = null, color2 = null, color3 = null, color4 = null) {
		this.enableRenderer(this.shapes);
		this.shapes.quad(filled, x, y, x2, y2, x3, y3, x4, y4, color, color2, color3, color4);
	}
	rect(filled, x, y, width, height, color = null) {
		this.enableRenderer(this.shapes);
		this.shapes.rect(filled, x, y, width, height, color);
	}
	rectLine(filled, x1, y1, x2, y2, width, color = null) {
		this.enableRenderer(this.shapes);
		this.shapes.rectLine(filled, x1, y1, x2, y2, width, color);
	}
	polygon(polygonVertices, offset, count, color = null) {
		this.enableRenderer(this.shapes);
		this.shapes.polygon(polygonVertices, offset, count, color);
	}
	circle(filled, x, y, radius, color = null, segments = 0) {
		this.enableRenderer(this.shapes);
		this.shapes.circle(filled, x, y, radius, color, segments);
	}
	curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color = null) {
		this.enableRenderer(this.shapes);
		this.shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color);
	}
	end() {
		if (this.activeRenderer === this.batcher) this.batcher.end();
		else if (this.activeRenderer === this.shapes) this.shapes.end();
		this.activeRenderer = null;
	}
	resize(resizeMode) {
		let canvas = this.canvas;
		var dpr = window.devicePixelRatio || 1;
		var w = Math.round(canvas.clientWidth * dpr);
		var h = Math.round(canvas.clientHeight * dpr);
		if (canvas.width != w || canvas.height != h) {
			canvas.width = w;
			canvas.height = h;
		}
		this.context.gl.viewport(0, 0, canvas.width, canvas.height);
		if (resizeMode === ResizeMode$2.Expand) this.camera.setViewport(w, h);
		else if (resizeMode === ResizeMode$2.Fit) {
			let sourceWidth = canvas.width, sourceHeight = canvas.height;
			let targetWidth = this.camera.viewportWidth, targetHeight = this.camera.viewportHeight;
			let scale = targetHeight / targetWidth < sourceHeight / sourceWidth ? targetWidth / sourceWidth : targetHeight / sourceHeight;
			this.camera.setViewport(sourceWidth * scale, sourceHeight * scale);
		}
		this.camera.update();
	}
	enableRenderer(renderer) {
		if (this.activeRenderer === renderer) return;
		this.end();
		if (renderer instanceof PolygonBatcher$2) {
			this.batcherShader.bind();
			this.batcherShader.setUniform4x4f(Shader$2.MVP_MATRIX, this.camera.projectionView.values);
			this.batcherShader.setUniformi("u_texture", 0);
			this.batcher.begin(this.batcherShader);
			this.activeRenderer = this.batcher;
		} else if (renderer instanceof ShapeRenderer$2) {
			this.shapesShader.bind();
			this.shapesShader.setUniform4x4f(Shader$2.MVP_MATRIX, this.camera.projectionView.values);
			this.shapes.begin(this.shapesShader);
			this.activeRenderer = this.shapes;
		} else this.activeRenderer = this.skeletonDebugRenderer;
	}
};
var ResizeMode$2;
(function(ResizeMode) {
	ResizeMode[ResizeMode["Stretch"] = 0] = "Stretch";
	ResizeMode[ResizeMode["Expand"] = 1] = "Expand";
	ResizeMode[ResizeMode["Fit"] = 2] = "Fit";
})(ResizeMode$2 || (ResizeMode$2 = {}));
//#endregion
//#region node_modules/spine-player-40/node_modules/@esotericsoftware/spine-webgl/dist/LoadingScreen.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated January 1, 2020. Replaces all prior versions.
*
* Copyright (c) 2013-2020, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var spinnerImage$2;
var logoImage$2;
var loaded$2 = 0;
var FADE_IN$2 = 1;
var FADE_OUT$2 = 1;
var logoWidth$2 = 165;
var logoHeight$2 = 108;
var spinnerSize$2 = 163;
var LoadingScreen$2 = class {
	constructor(renderer) {
		this.logo = null;
		this.spinner = null;
		this.angle = 0;
		this.fadeOut = 0;
		this.fadeIn = 0;
		this.timeKeeper = new TimeKeeper();
		this.backgroundColor = new Color(.135, .135, .135, 1);
		this.tempColor = new Color();
		this.renderer = renderer;
		this.timeKeeper.maxDelta = 9;
		if (!logoImage$2) {
			let isSafari = navigator.userAgent.indexOf("Safari") > -1;
			let onload = () => loaded$2++;
			logoImage$2 = new Image();
			logoImage$2.src = SPINE_LOGO_DATA$2;
			if (!isSafari) logoImage$2.crossOrigin = "anonymous";
			logoImage$2.onload = onload;
			spinnerImage$2 = new Image();
			spinnerImage$2.src = SPINNER_DATA$2;
			if (!isSafari) spinnerImage$2.crossOrigin = "anonymous";
			spinnerImage$2.onload = onload;
		}
	}
	dispose() {
		var _a, _b;
		(_a = this.logo) === null || _a === void 0 || _a.dispose();
		(_b = this.spinner) === null || _b === void 0 || _b.dispose();
	}
	draw(complete = false) {
		if (loaded$2 < 2 || complete && this.fadeOut > FADE_OUT$2) return;
		this.timeKeeper.update();
		let a = Math.abs(Math.sin(this.timeKeeper.totalTime + .25));
		this.angle -= this.timeKeeper.delta * 200 * (1 + 1.5 * Math.pow(a, 5));
		let tempColor = this.tempColor;
		let renderer = this.renderer;
		let canvas = renderer.canvas;
		let gl = renderer.context.gl;
		renderer.resize(ResizeMode$2.Expand);
		renderer.camera.position.set(canvas.width / 2, canvas.height / 2, 0);
		renderer.batcher.setBlendMode(gl.ONE, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
		if (complete) {
			this.fadeOut += this.timeKeeper.delta * (this.timeKeeper.totalTime < 1 ? 2 : 1);
			if (this.fadeOut > FADE_OUT$2) return;
			tempColor.setFromColor(this.backgroundColor);
			a = 1 - this.fadeOut / FADE_OUT$2;
			a = 1 - (a - 1) * (a - 1);
			tempColor.a *= a;
			if (tempColor.a > 0) {
				renderer.camera.zoom = 1;
				renderer.begin();
				renderer.quad(true, 0, 0, canvas.width, 0, canvas.width, canvas.height, 0, canvas.height, tempColor, tempColor, tempColor, tempColor);
				renderer.end();
			}
		} else {
			this.fadeIn += this.timeKeeper.delta;
			if (this.backgroundColor.a > 0) {
				gl.clearColor(this.backgroundColor.r, this.backgroundColor.g, this.backgroundColor.b, this.backgroundColor.a);
				gl.clear(gl.COLOR_BUFFER_BIT);
			}
			a = 1;
		}
		a *= Math.min(this.fadeIn / FADE_IN$2, 1);
		tempColor.set(a, a, a, a);
		if (!this.logo) {
			this.logo = new GLTexture$2(renderer.context, logoImage$2);
			this.spinner = new GLTexture$2(renderer.context, spinnerImage$2);
		}
		renderer.camera.zoom = Math.max(1, spinnerSize$2 / canvas.height);
		renderer.begin();
		renderer.drawTexture(this.logo, (canvas.width - logoWidth$2) / 2, (canvas.height - logoHeight$2) / 2, logoWidth$2, logoHeight$2, tempColor);
		renderer.drawTextureRotated(this.spinner, (canvas.width - spinnerSize$2) / 2, (canvas.height - spinnerSize$2) / 2, spinnerSize$2, spinnerSize$2, spinnerSize$2 / 2, spinnerSize$2 / 2, this.angle, tempColor);
		renderer.end();
	}
};
var SPINNER_DATA$2 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKMAAACjCAYAAADmbK6AAAALKElEQVR42u2de2iW5R/GPzuqcwfnnKfNmafl5tTNHWzqNi3DEMQykcAoJSsySkspjSIk0iD/07Kf4R+FnVBDUTshZGpWUEJaaiWFgZlUFmXmIe3HNXthyebeZ77P9H13ffBG8Y8H7ut7vff93N/7fu4vGGPiFZiez/Qtw9lytJajfzfw9z/j+efPOv7cV8W+lUNY2a8T/ayTCRsWFLJA5rtUO1LLkV5p9LJeJizQiHeqnlOtmVFtdTGrrZkJCxYXsTgaI6r9MY4/UpNItW4mFDaXsTlaM6qVZlBq3UwofFrJp0HMWJ9DvXUzobCznJ1BzFjWlTLrZkJh/TDWBzFjTgo51s2EgnKI0Rrx+FiOWzNzVaym91Syx5qZsGBWb2ZFa0ZN6dbMhAWTcpkUrRmXD2K5NTNhgVbH0Zpxbl/mWjMTFvRIo0e0ZpzcncnWzISKtvmiMWNRJ4qslwmVXRXsas2Ix8ZwzFqZsGFREYtaM+Oaa1ljrUzYkJ9G/ok6TlzKjJWZVFor0y7c1Zu7WjLiqiGsskamXdHopyT4vALmzS9k/t19uHtKHlOSIMn6xAtARjIZ1sFcUSZ0Y4La+G6M18hS2IlCn4a+WoC0JNL0d/dUupdnUj40g6EJ2VEdMnhrOG/p5f/jUXz8SgmvaGU6KpNRNsLVQV0OdXf24s63h/P2gWoOrBjMCr2GJFQnnxnIM3q5P1PPmaYv+4ev4/C6UtbpV2gzXCkgL5W8Bwt48OIc6ul6Tp+s4+SyASxLiI4+PYCn1bHzDZxvaQW6vZzto7MYnQIpNkf7kp5EuozYUroqEjcNKHHd0Tl9mBPN1pk+hFeieGBnBtog7UXjsj9pWg+m6duecw2cay1OC/uxMC47KmP9OIYfoz1YoC20J/rzRG4quTZK2EAyJGs20qwUbYw0aNRmUxtvfUW/uEtNzc1NB1/X8LVyd15hh82F43AvD+VlXcsSJEZa1CQ3ejleAO7oxR3RDP0XN91X4+NXYb8nkv7UNTwV7e0YTdu7I3g33t7tuaEbNwSZpps2fSyvs4M2Tjhot+jb0Xzbltj8r5j/xVt/6Z1Ob93U1ZYO691EhhzchcHeXosVjcNZysyezLw4xRZt05R+fTeuj8vOj+zKyG0j2aZcVVs6v+QalnjrMFZASQYl2nBoSyz06e3j/Xk8rgWYmMvEICu2pm1HOTuc7okV8FgRj0XukwzanhvCc/F+72TjoQjdObN1OFuDLmh0xP+WHtxiI10ukJlCprb4guiv1fP+avZrS1C7NAkliHZjDtZwMMgqbukAltpMlwuMy2FcEBPqvfLLar5Uqi0hBdEwryy+Mv5n6zkbjTBa+dlMlwvUZFETZKGiFM7tvbhdJ3gSVRO0wzIjnxmvl/J6a6JsGMYGrahtpssFeqbR841S3mhN80OjOaSDEdqd6SjaMKgzgzRK7q1ib3PT9sYyNo7JZoyNFNvRcVMZmy7WOvIuryv/Zvdmdt90+nY0bRp3AvROohFwdwW7dTG7RFlbwlqdrbOBYg005NAQmZU0HWt1rXMBH1Xw0dQ8pmqzoaPmdhun7bHZjNVe9qP9eFQfO1VkUmHjhAVUZ1GtnKFSbjrkrPfy4i4UW5t/6ZxM54J0CqxFe81KpGsQyE4h23oYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjLna+bdOy+IiFquIpGq16Pb79cNYv3IIK/X/ugx+Ui6TVKvYVU9Nc8gX8od8Ir/IN/KPfCQ/yVfyl/6/pfJvLChkQdD6wyqntquCXYuKWJSfRr6D0dEAxV3xlw/khyD+kd/ku/88cHo+09tS3LBpO1HHCVUqcIA6CqB4K+6X6x35L/JM2loXurlWmUmlA5XogOIcK8/If5HncrSWo7F6cKIWPjT/RXGOlWfkv8hzaWsN4uaaysE6WIkOKM6x8oz8F3kusXqo2vxC5jtYiQ4ozrH0TeS5qIZcrB7qkrwdA8U5Vp6R/yLPZV8V+2L14Cl5THGwEh1QnGPlGfkv8lyUlIzFQ1cNYVVHrcjZ0VCcFe9Y+Eb+izy3ceclUl43aFN52DXXssYpnY6a4qFS8ZcP2uIf+e7inRh6pdFrdTGrm8uiHx/L8T2V7NGWzvJBLJ/bl7mTuzO5qBNFDoiJID/IF/KHfCK/yDfyT3O7d/KbfNfS80hNIrU0g9L6HOq1x5iTQo6FNpeLfCQ/yVfyl3xmXYwxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHNk9z4JwJ0SqKTdQkbyEwhU393T6V7zzR6pieR3tE1ITeVXImhe6BXDGZFdRbVeank2TBhcaEMr0rwbixj49IBLL2/L/ffmMuNHfqO9tFZjJYBd1ewO3Lx+IcVfKhqna5nHZYR6XFPH+5R3eeI5t9fx/fvjeC9Jdew5OKZKqFR/RDVKL6vL/f9PJafmyvHsL+a/ff24V6NmjZQbGchVbY6UM2BluqHv1rCqzVZ1KQlkZboepCdQvacPsz5bjTfXao+yMEaDt7Wk9tSIMVGig3TejCtJSM2bSpkPjWPqd1S6Zao+lORSYWmgkOjORRNwZqd5ezMSiHLRooNr5XwWjS6/1XHX9vL2T67N7M1iyXa9JCrYjVrS1gbpJyw6hBfsmiNCYT0P9/A+Wj1/6qGr5YNYFlJBiWJogEzezLz/ZG8/9s4fgtSyuvNYbyp1IONFBtu7sHNv4/j9yAxUHWrdaWsG9+N8XHd+YxkMpSy+aySz841cC5oXbmHCnnI74yxAgZ3YbDeB4PEQCOpBpFNZWwa2ZWRcdnxLsl00crtRB0n2lLg8JNRfDKoM4NsolgBSmw/UMADba1+qpmqfyf6x1u/0a/og3I+aEunP6/i86osqmygcGarF4p54dex/Bo0LqfqOfVwIQ/HW5/RSkwV1oN2WLlHTc82TljAwM4M1O5LWwYKZTjibYXNS0N5KcjKTe10PadfLObFuJwK4ozp+UzXDBTUjL+M5ZcBnRkQV53dMIwNQTu6bSTbVEzbi5awuVByd2E/FgaN0Tc1fKOzBHHV2aAdVSdv6s5NNkp7cSH/++xAng2yyHx+CM/H21YhfdPp+0U1X0TbSZnXx8faG9Aop0MS0cToh1p+iLcpOkLj9t/JOk5eqoPHxnDsyf486an5yqCDK7XZ1O4oZ4dWyy3FSXHUAYq47uyYbMZoGmhpG3DlEFb6uNiVBhpyaHhnBO8oJmfqOROJjzIiP43hJ8UxITqqX56S2Hur2KsOnq3nrE6PPNKPRwrSKbAZrjTQNZmuE7oxYXMZmxWbw9dxWFu4W4ezVedOE6qzI7oyYkY+M7TPeWsPbk2UX1qioSN+E3OZqOR2cReKE+qQRFN0Pi7y73g/UawU1KzezJpXwLz5hczX1ueUPKYkNb6GJQZ+j7/aAfRZREsv+quGsMoamXZBW2Gt5eU0alorEzYsKmJRa/m4NdeyxlqZsCGa84DKnVorEzboC7podis69DfIJmwufHMc7famvvmxZiYsKOtKWbRm1OcW1syEBboSJFozLh/EcmtmwgIluaM14/phrLdmJixYXMTiaM24p5I91syEBTphFOR7Y2tmwgJNvUFOr+tov3UzoaAv44KYUatv62ZCoemdhtG0+hzqrZsJBR08DWLG0gxKrZu50qvpxos3U5NItW4mFPp1ot+lPlpq2lYXs9qamVBZUMiC1ox4pJYjvlfStAu6GmTLcLboMtPIV4/6im5fFfuUi9QIap2MiWP+D96R1vPmsD/fAAAAAElFTkSuQmCC";
var SPINE_LOGO_DATA$2 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKUAAABsCAYAAAALzHKmAAAQ7klEQVR42u3da4xdVRUA4D0zd2Y6nZY59DVtZ1puS9+lzC0YAi2UQ8AAQczFpPgA9VIeIQbirRqJ0cBUBVGjDr/QCKSNRSMmpuODxAdxqhgwxkhFjf6Sxh/+UUNVNGJCzR7uTvas7LXX2q9zzp3em6y0gTN3Zu75utZe5+yztxC9V+/Ve5X9En1Vjd7J6SFbLNF7naPw+l2jh7YHMBWssqMHtlsRdim4qsLtIawaPiHEQOLoNrA9iIkQDnRrVA1qD2LZ8ISoxYqKo13sQAtBWBayQWZUAXGRQM9JjCngDVY0UqJNDbQrMcaGmArdUKpIjbYiQLsCZCyIMQBy8QwnilR4Q5AuCpxFYvRFmBLbEiwKwpsSaWycVQGZBKMrwBjA9BhxDe57u2L2hOoKNCbOrgAZitEVYUxoKSMErQvSxYIzCkguRg5EF4AUhqUlhy/YUKSxcRaKsioYOQhD4I0yYxkR3PcJBcuFysmgsXAWBTMJyBCMIQh9kGGxXIXvexCQXbHGAMrBWTbM2CCpMSMLIxehC77lSJwXGth7M0FzoVJIXXDWQnGmhOkL0ic7YhhtWdGGkAuPAjUWGoF4faCmwBkbZmyUqUCyMqMLRA4+E6IsdTjidUHKBYrh9CnpRcH0ypKxsyOGEYNIIeTCOz91OIJ1QYoB5eAMyZo+MFNnyVTZ0YiRC9EGEMOyAgshxErHsL2XK1gOUgwohtM1a5YNM7Rsu4K0ZkcbRm4mpPBRwFZ5hg9eCqkrUB+csWGGogzNkqEgrdnRhpGLkINudaLgwvVB6oqzCjCTZElb2Y4B0gUjBtEG0ARnDRLjjoG9DwcshtQGlIPTljVjwUySLWNkyRCQVHa0ZUUTRAwgF91a33BEy0VKAcVwwqwZC2bqbOlUurllOxQkJzNyINoAYqjWhYYjWg5SCiiG05Q1U8FMjTIoS8YE6YORi1BHtJ4KIcQEEtTXUWAxpK44YVlPBdO1jCdFWTZIE8bVGEYMIRPcZGBw4HKQcoBiOE1ZMzbMgVQwU6JMAdKEEcuIJogUvg1YCCE2gsCO42DlIIVAKZwpYJaSLVNnSU6XjYHUmxhTmXaFaMO3EYkLqMC+FsLlIoVAKZzMrEnBhJeLfLNlKMrYWRIDCbOkFSSVHbHM6AKRC6/ODUewNqQ+OLlZkxpjUmV8MBbMUJSxyzY3Q1IgTRgxiBRCHdem0KDAUkBh9sRwwjEnAXMMgTnKhFlUtiwkS5rGka4g9SaGgxFmRC7AzTCEEBcyA36dDSsXqAtOLkysjGMwY5XxVChjZ0kuSCo7YlkRQsQQYtDEFsegsLoCxUp7Kpgps2UslFGzJGccSYHUmxhOZqwzEZqAbfUMCisHKIZzgsCpl3MTzMwTpi1bYp2477gyFKUxS7qWbdjY2EBS2dGE0QQRA7gNCyHEdhjE8RhUDlBT9tzgmjWZMFNlSy+Urk1OzCyJlW0XkK4YOQh1cDtcgwBrQmoDWkdgboBZE8mYsJSHlnFbJ+5bwmOPJ7lZkirbC8aRsMvmgtTHjBhGE0QbwJ2egUE1ITVlUC5OmDVdYNrKuN70xM6WoShjlW4464dbtiFIWK6x7GjESEHUUe0iYncnbMdQSE0Z1ITTNOb0hRmjjLtmS9dmJ2rp1jtuKktyyrb6YLEMCUHq2dGG0QQRQ7f72kzc+cJecerne8Wvv7JNPHPvenEkz8Sh3UtFc92QyGt9Yko/HgOLAIUZlItTz5ouMF3KuE+2jFLCQ1D6lm6fLMkBacuOJowYRBUXyfjuHjF3NhdnsfjvAfH6E9vFt9XxKgikEKgJZyyYalzOLeMu2bLbULI6bh+QGwmQ+rgRlumdGEQAao+K56bEL2woVUwOiev0r8OAUjiJrMmFCbvykGxZRAmPitK1dHM7bohyMsuyi/I8f0+e57fJYIKEZXpXo9E4mOf5XTKyLLvCBLETF8uY2SKepkC+dpX4T02Ivepr4HvZcOZ5fmee54fyPL+DmTUhzAs6n4n8bN5dr9f3YdkSg8nsxG0lPBVKVpNjG0/aGhzfLDmRZdnumZmZp8+c+cdZPV555fSr7Xb7s0jJ3i5Pcue4MxKkPPkvvXTqz/B92u32l0wYOzG1fkhcd/py8Rcbyq/vFM/KY1WA95h/3zzP71bfU6JsNpsfgj+P/FlbrdaDGExYyuXvLz8H+DudODH700ajcSM3W6Yu4alQ1spCOTd38jcKocTZbh9+9NixY99XJ8AEUkcpo9W64yH197m5k7+bnZ19QT+J09NHntQhwji/Jg58qi6++ofLxJ8gSFneVw2Ka4QQDfh1Ok4dZavVmtZ/nrm5k7/Vf55O1tRhboUw5+ZOvqyOl5+R/FyOHj32PYVU/tloNG5IXcKrhJIzngwp3fNjomazea/64BuNxts646f50lWv169utw9/DmtqdJQyZFaSJVuV6nq9fqMEof5/vV6/CYBqgJDlee+yAbF/+4i4ZWqZeNfaIfHWzn+Hx0KcEuU9+s8jv3ej0bhVlXOZydX/k0iRMeb8P0D5e6tj8zy/Xb9UJIc56h/yqVOnXul8lmuZ2bJslKmbHG7XrbpCmCXFRLvdfqQD6jTS3Jiy5I4OykM6ADV+1Eu1DmV6evopBORexzDi1L+X/HnGxsb2w3Hm9PSRJ9QxWPOTZdmlKht2hi+w6dkox5bqffI8fye3hDteGqKaHVsHXihKl0tB+h0cY+lute54AGRKDCW89LNTRynHb7ChUWVVjetOnJh9EYBUyPZeNCoOtsbFQwdXi4/esELcd+tq8cCHJ8UXp+viy9efLz7AgamjlKXc1AA1m83DoIRDlFubzeb96hhZLVTlgJ24gttutx+ONa50bHZKRenaeTs1OfpAfnr6yOOdE7EZdNwmlKocntXLNkA5JTGq47Ds+Lf94lWsyfnXleLfnIwJUN4DOnNYwuUxh2A3Ln9XULrfK8t3J27Tu3BVwiOjXJqoAy8UZej1yclGo3GTLN+gu3w+z/P3YaWbQqk3Ne12e4ZC+c8rxWsYytcPiP9RpZxCqWDKnxOiBNlyAUpOnGsoh4tA2Rm8X9xqtT6md5wyZmYe+0YRKL+1S/wYQ3n8zctBl5SBUv5djivfjMOPduIzcizeiYfr9foVvUwZG+XCuzibZKnSceZ5/v4QlKp8y7ElhnJlTeTP7BI/kllRYfzrfvHqFy4UX1vaL/aVlSmROzwbwdS29T2UcEwZF+V8ozM2lu1VY812u/15akypGh3TmFJesJbHHD167IdUxz3YJy5bNySuX1mbvy55CbMLtzU6tjGlsdFptVqfUMc0Go23F4wy1l2dSnbfvpMwVPe9WWVLDsrOJaF9MFu2Wq1PqmNkGce67xiXhTjdNwdlvV6/BgxfbPfBfVCetxi6b9/rlCup65QzM48dl2OjLMv26CibzeZ96sTIzEFdpwQXz9U1yrtVlpR/Zll2Fec65Y6l4pbbx8XHH9kknvzJlPjlHy8Tp29eKT5ou0aJoIT3w3dBlLDzVpfAJEZ1XOdaJZxnOSlvPMjPzxFljIvng914RwebsjYO7uhMyHu46sOfnf3Oz2TXDW6vvYxdFoIXz3Wc8J5zs9n8iOn2IrxTc2BM3Glqdp7dI553uaOjxrhwcob+MyuUpjs6WZZdon8OcigjPx8V+u+GTWFTSWEx3WYcdJ225jNDSE4q0GHCzlueHOyujn6bUWYgeb9ZZUaQPe+GzQ+Gc8+oOGhC+c1d4gfI16n3XDAhQ7+9qE9l01E2Go132GYKyXE1NiFDTcpoNpv3LOYJGWXNErJNW9sEp63p2RKiVPMn1bS1DgxsyhoGdGpmizj+xtXiDYnx7/vFmce3iWdW1cTVGEY4hQ2ZW0nNq8Qm/M6XbXm3S100lwGedFybuvNOibLI+ZS2ceU4eAxiEuvCkfmU8ycToDxETe6FgCBQHeqyAbFvfEhcO7BwDuXFCEbTZF840XeHK0jYcbs2OIGle0mVJ/mmnClEPQqxyTY5I8/zFhif7fSZee4bnrPOU4AssnRXHaVTCTd14dRDY3UbTIiSeFhsN/aMjgnqthFx880rxX3yATL5p3y4LPXzOaBkUyBjZMlYpbtQlIOBD475ZEusjMNSvkXe6VEoJVDkeZ2dzIfIFsRzU+JF2OyM9M9fTC/6SUYOyFQPjQ2nWiUjxnPfw5EeHqMWIqAeIFsAU847lJM2JM6xsewt1OIDLs99P7ZFHNdB/upS8XtPiD7PfLuCXJNolYyyFiNI/Zit65ItrOVafFbHcFohY7hPTN21Tjz4uc3iqfsnxKdX1MTl1OoYRFaMsToGB6Trw2JFP/OdZC2hJZ7ZkrMoAbbSGmelDJ91hFKuJeS7jlBMkJnrAqqJlgMUZS/dArPlGHNdSg5M3xXXtvquuEatvIYtDRhpxbUJuIgqsU5lGWtUploK0KuEU9mSW8YpmFQ556xNuYW7NiW13B+FkMiKHIy+C6eGgBxJvMR0oSv5hi6+z4HJyZoU0M2RVvDlrOQbcxVfX5AhZbuqy0v7ZstYMLHlAVlLTF9ALLbvu9Y5Zylpn/XOsd0ibIvxr2KCLHpp6SCUIdnSZSF+WzfOhem6GD+1KwR3Z4jNjrtDpNoZwmWd8yrupZN6Hx3fbMmFSe0Swdq2ZIPjxk1112Duo8OBGLrBkw/IoncdK2XHsdC9dHz204m50xh3tzFq1zFqtzHXrfCw7OgDsqyNnZLszVijsmXgrmNcmGtS78lIoMX2aJz03fKO2sDJddPQSCDPiQ1DfWBycY6XtXstc2PQKuxgG2McmXTPb9/9vmuJYXKyJrWjbeg+3xPM4O73nWqvbyw7xgZZSJbEUBa157cNJjdr2vb+5iA1YV3HxYscj30PDCEHIgcjtfm8K8hSsmRotkwFk5s1TTghUAopB6xrjHMBBkI0YYTZ0dZlxwLpkiWDULpmy5gwqayZgZNkA7oKQQCxctByYg0XIIEQQuRitGVHblMTA2ShKGPDpC6wu+DEgJqg2rDGDBtAF4Q6RAojp1xXGmSMbImVcR+YWNY04eQCtUG1ofUJ2/uvcETIgUhhdAE5GAlkKShjwHTNmhhODKgJqQ2sC14uOgyfD0IbRF+MlQaZAiZWyn2yJsTJATqGnHQO2Jhh+xlsACFCG0QbRtdyzQFZCZSxYPpmTS7Q5cjJHYNBYIkZpu99HoUQ/o4QIYSIZUZfjJ4ZMjZI32wZBDMU5yhy8pZTULl4XYP5fagMyEVoy4oupTpGduwnkloSlKEwY+AcQU4MhRTD6ovXBRwFzwWgCSEF0QVjJUGmgEllTS5OLlCIlIN1mS9mx/cZ5eLDALpCTI2RAhkTZQqYoTgpoCPECbaBHQ2ETL3PUl98ECAXYijG0OyYAmQoTG7W5ODkAF1CnVgm2JQx4okPA+gCMTbGskBGgRmaOblAh5GTORIrfKFx4VH4EIAxIXIxlg2SBbMvECY3e7oApbDaIgQu5/2HmeEKEINYiwSRi7EQkLFgumZOCuggctKGI4ULZN/vMeSLj0AYMytWEqMLzFg4fYDaoKaC6wvOFR4FkIPQFaILxrJAOsHsc/zlfYDWXE8qF22s8Pz5KHxcgEVALBtjJXBSSEOwFhk1Zgy4hitCT4hVw+gFs8/zwxqIBbUgyK7fcyA0PD9XX4iVxhiC0xdof6STWCsoBmKF7+cVCWFXQYyBMxRpf+STX1b0x45AhN0OMSrOGEirhrY/dfQAdjvS7oy+WCF6r1RIFxXWvlTRg1YVqFWBmxZbD99ig9pt0YPQw9rD1nstVri9V+/Ve3XrS/wfim4P5fIFxLoAAAAASUVORK5CYII=";
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/WebGL.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var ManagedWebGLRenderingContext$1 = class {
	canvas;
	gl;
	restorables = new Array();
	constructor(canvasOrContext, contextConfig = { alpha: "true" }) {
		if (!(canvasOrContext instanceof WebGLRenderingContext || typeof WebGL2RenderingContext !== "undefined" && canvasOrContext instanceof WebGL2RenderingContext)) {
			let canvas = canvasOrContext;
			this.gl = canvas.getContext("webgl2", contextConfig) || canvas.getContext("webgl", contextConfig);
			this.canvas = canvas;
			canvas.addEventListener("webglcontextlost", (e) => {
				if (e) e.preventDefault();
			});
			canvas.addEventListener("webglcontextrestored", (e) => {
				for (let i = 0, n = this.restorables.length; i < n; i++) this.restorables[i].restore();
			});
		} else {
			this.gl = canvasOrContext;
			this.canvas = this.gl.canvas;
		}
	}
	addRestorable(restorable) {
		this.restorables.push(restorable);
	}
	removeRestorable(restorable) {
		let index = this.restorables.indexOf(restorable);
		if (index > -1) this.restorables.splice(index, 1);
	}
};
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/GLTexture.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var GLTexture$1 = class GLTexture$1 extends Texture$1 {
	context;
	texture = null;
	boundUnit = 0;
	useMipMaps = false;
	static DISABLE_UNPACK_PREMULTIPLIED_ALPHA_WEBGL = false;
	constructor(context, image, useMipMaps = false) {
		super(image);
		this.context = context instanceof ManagedWebGLRenderingContext$1 ? context : new ManagedWebGLRenderingContext$1(context);
		this.useMipMaps = useMipMaps;
		this.restore();
		this.context.addRestorable(this);
	}
	setFilters(minFilter, magFilter) {
		let gl = this.context.gl;
		this.bind();
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, minFilter);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, GLTexture$1.validateMagFilter(magFilter));
		this.useMipMaps = GLTexture$1.usesMipMaps(minFilter);
		if (this.useMipMaps) gl.generateMipmap(gl.TEXTURE_2D);
	}
	static validateMagFilter(magFilter) {
		switch (magFilter) {
			case TextureFilter$1.MipMapLinearLinear:
			case TextureFilter$1.MipMapLinearNearest:
			case TextureFilter$1.MipMapNearestLinear:
			case TextureFilter$1.MipMapNearestNearest: return TextureFilter$1.Linear;
			default: return magFilter;
		}
	}
	static usesMipMaps(filter) {
		switch (filter) {
			case TextureFilter$1.MipMapLinearLinear:
			case TextureFilter$1.MipMapLinearNearest:
			case TextureFilter$1.MipMapNearestLinear:
			case TextureFilter$1.MipMapNearestNearest: return true;
			default: return false;
		}
	}
	setWraps(uWrap, vWrap) {
		let gl = this.context.gl;
		this.bind();
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, uWrap);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, vWrap);
	}
	update(useMipMaps) {
		let gl = this.context.gl;
		if (!this.texture) this.texture = this.context.gl.createTexture();
		this.bind();
		if (GLTexture$1.DISABLE_UNPACK_PREMULTIPLIED_ALPHA_WEBGL) gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this._image);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, useMipMaps ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
		if (useMipMaps) gl.generateMipmap(gl.TEXTURE_2D);
	}
	restore() {
		this.texture = null;
		this.update(this.useMipMaps);
	}
	bind(unit = 0) {
		let gl = this.context.gl;
		this.boundUnit = unit;
		gl.activeTexture(gl.TEXTURE0 + unit);
		gl.bindTexture(gl.TEXTURE_2D, this.texture);
	}
	unbind() {
		let gl = this.context.gl;
		gl.activeTexture(gl.TEXTURE0 + this.boundUnit);
		gl.bindTexture(gl.TEXTURE_2D, null);
	}
	dispose() {
		this.context.removeRestorable(this);
		this.context.gl.deleteTexture(this.texture);
	}
};
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/AssetManager.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var AssetManager$1 = class extends AssetManagerBase$1 {
	constructor(context, pathPrefix = "", downloader = new Downloader()) {
		super((image) => {
			return new GLTexture$1(context, image);
		}, pathPrefix, downloader);
	}
};
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/Vector3.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Vector3$1 = class {
	x = 0;
	y = 0;
	z = 0;
	constructor(x = 0, y = 0, z = 0) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	setFrom(v) {
		this.x = v.x;
		this.y = v.y;
		this.z = v.z;
		return this;
	}
	set(x, y, z) {
		this.x = x;
		this.y = y;
		this.z = z;
		return this;
	}
	add(v) {
		this.x += v.x;
		this.y += v.y;
		this.z += v.z;
		return this;
	}
	sub(v) {
		this.x -= v.x;
		this.y -= v.y;
		this.z -= v.z;
		return this;
	}
	scale(s) {
		this.x *= s;
		this.y *= s;
		this.z *= s;
		return this;
	}
	normalize() {
		let len = this.length();
		if (len == 0) return this;
		len = 1 / len;
		this.x *= len;
		this.y *= len;
		this.z *= len;
		return this;
	}
	cross(v) {
		return this.set(this.y * v.z - this.z * v.y, this.z * v.x - this.x * v.z, this.x * v.y - this.y * v.x);
	}
	multiply(matrix) {
		let l_mat = matrix.values;
		return this.set(this.x * l_mat[0] + this.y * l_mat[4] + this.z * l_mat[8] + l_mat[12], this.x * l_mat[1] + this.y * l_mat[5] + this.z * l_mat[9] + l_mat[13], this.x * l_mat[2] + this.y * l_mat[6] + this.z * l_mat[10] + l_mat[14]);
	}
	project(matrix) {
		let l_mat = matrix.values;
		let l_w = 1 / (this.x * l_mat[3] + this.y * l_mat[7] + this.z * l_mat[11] + l_mat[15]);
		return this.set((this.x * l_mat[0] + this.y * l_mat[4] + this.z * l_mat[8] + l_mat[12]) * l_w, (this.x * l_mat[1] + this.y * l_mat[5] + this.z * l_mat[9] + l_mat[13]) * l_w, (this.x * l_mat[2] + this.y * l_mat[6] + this.z * l_mat[10] + l_mat[14]) * l_w);
	}
	dot(v) {
		return this.x * v.x + this.y * v.y + this.z * v.z;
	}
	length() {
		return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
	}
	distance(v) {
		let a = v.x - this.x;
		let b = v.y - this.y;
		let c = v.z - this.z;
		return Math.sqrt(a * a + b * b + c * c);
	}
};
var Matrix4$1 = class Matrix4$1 {
	temp = /* @__PURE__ */ new Float32Array(16);
	values = /* @__PURE__ */ new Float32Array(16);
	static xAxis = new Vector3$1();
	static yAxis = new Vector3$1();
	static zAxis = new Vector3$1();
	static tmpMatrix = new Matrix4$1();
	constructor() {
		let v = this.values;
		v[0] = 1;
		v[5] = 1;
		v[10] = 1;
		v[15] = 1;
	}
	set(values) {
		this.values.set(values);
		return this;
	}
	transpose() {
		let t = this.temp;
		let v = this.values;
		t[0] = v[0];
		t[4] = v[1];
		t[8] = v[2];
		t[12] = v[3];
		t[1] = v[4];
		t[5] = v[5];
		t[9] = v[6];
		t[13] = v[7];
		t[2] = v[8];
		t[6] = v[9];
		t[10] = v[10];
		t[14] = v[11];
		t[3] = v[12];
		t[7] = v[13];
		t[11] = v[14];
		t[15] = v[15];
		return this.set(t);
	}
	identity() {
		let v = this.values;
		v[0] = 1;
		v[4] = 0;
		v[8] = 0;
		v[12] = 0;
		v[1] = 0;
		v[5] = 1;
		v[9] = 0;
		v[13] = 0;
		v[2] = 0;
		v[6] = 0;
		v[10] = 1;
		v[14] = 0;
		v[3] = 0;
		v[7] = 0;
		v[11] = 0;
		v[15] = 1;
		return this;
	}
	invert() {
		let v = this.values;
		let t = this.temp;
		let l_det = v[3] * v[6] * v[9] * v[12] - v[2] * v[7] * v[9] * v[12] - v[3] * v[5] * v[10] * v[12] + v[1] * v[7] * v[10] * v[12] + v[2] * v[5] * v[11] * v[12] - v[1] * v[6] * v[11] * v[12] - v[3] * v[6] * v[8] * v[13] + v[2] * v[7] * v[8] * v[13] + v[3] * v[4] * v[10] * v[13] - v[0] * v[7] * v[10] * v[13] - v[2] * v[4] * v[11] * v[13] + v[0] * v[6] * v[11] * v[13] + v[3] * v[5] * v[8] * v[14] - v[1] * v[7] * v[8] * v[14] - v[3] * v[4] * v[9] * v[14] + v[0] * v[7] * v[9] * v[14] + v[1] * v[4] * v[11] * v[14] - v[0] * v[5] * v[11] * v[14] - v[2] * v[5] * v[8] * v[15] + v[1] * v[6] * v[8] * v[15] + v[2] * v[4] * v[9] * v[15] - v[0] * v[6] * v[9] * v[15] - v[1] * v[4] * v[10] * v[15] + v[0] * v[5] * v[10] * v[15];
		if (l_det == 0) throw new Error("non-invertible matrix");
		let inv_det = 1 / l_det;
		t[0] = v[9] * v[14] * v[7] - v[13] * v[10] * v[7] + v[13] * v[6] * v[11] - v[5] * v[14] * v[11] - v[9] * v[6] * v[15] + v[5] * v[10] * v[15];
		t[4] = v[12] * v[10] * v[7] - v[8] * v[14] * v[7] - v[12] * v[6] * v[11] + v[4] * v[14] * v[11] + v[8] * v[6] * v[15] - v[4] * v[10] * v[15];
		t[8] = v[8] * v[13] * v[7] - v[12] * v[9] * v[7] + v[12] * v[5] * v[11] - v[4] * v[13] * v[11] - v[8] * v[5] * v[15] + v[4] * v[9] * v[15];
		t[12] = v[12] * v[9] * v[6] - v[8] * v[13] * v[6] - v[12] * v[5] * v[10] + v[4] * v[13] * v[10] + v[8] * v[5] * v[14] - v[4] * v[9] * v[14];
		t[1] = v[13] * v[10] * v[3] - v[9] * v[14] * v[3] - v[13] * v[2] * v[11] + v[1] * v[14] * v[11] + v[9] * v[2] * v[15] - v[1] * v[10] * v[15];
		t[5] = v[8] * v[14] * v[3] - v[12] * v[10] * v[3] + v[12] * v[2] * v[11] - v[0] * v[14] * v[11] - v[8] * v[2] * v[15] + v[0] * v[10] * v[15];
		t[9] = v[12] * v[9] * v[3] - v[8] * v[13] * v[3] - v[12] * v[1] * v[11] + v[0] * v[13] * v[11] + v[8] * v[1] * v[15] - v[0] * v[9] * v[15];
		t[13] = v[8] * v[13] * v[2] - v[12] * v[9] * v[2] + v[12] * v[1] * v[10] - v[0] * v[13] * v[10] - v[8] * v[1] * v[14] + v[0] * v[9] * v[14];
		t[2] = v[5] * v[14] * v[3] - v[13] * v[6] * v[3] + v[13] * v[2] * v[7] - v[1] * v[14] * v[7] - v[5] * v[2] * v[15] + v[1] * v[6] * v[15];
		t[6] = v[12] * v[6] * v[3] - v[4] * v[14] * v[3] - v[12] * v[2] * v[7] + v[0] * v[14] * v[7] + v[4] * v[2] * v[15] - v[0] * v[6] * v[15];
		t[10] = v[4] * v[13] * v[3] - v[12] * v[5] * v[3] + v[12] * v[1] * v[7] - v[0] * v[13] * v[7] - v[4] * v[1] * v[15] + v[0] * v[5] * v[15];
		t[14] = v[12] * v[5] * v[2] - v[4] * v[13] * v[2] - v[12] * v[1] * v[6] + v[0] * v[13] * v[6] + v[4] * v[1] * v[14] - v[0] * v[5] * v[14];
		t[3] = v[9] * v[6] * v[3] - v[5] * v[10] * v[3] - v[9] * v[2] * v[7] + v[1] * v[10] * v[7] + v[5] * v[2] * v[11] - v[1] * v[6] * v[11];
		t[7] = v[4] * v[10] * v[3] - v[8] * v[6] * v[3] + v[8] * v[2] * v[7] - v[0] * v[10] * v[7] - v[4] * v[2] * v[11] + v[0] * v[6] * v[11];
		t[11] = v[8] * v[5] * v[3] - v[4] * v[9] * v[3] - v[8] * v[1] * v[7] + v[0] * v[9] * v[7] + v[4] * v[1] * v[11] - v[0] * v[5] * v[11];
		t[15] = v[4] * v[9] * v[2] - v[8] * v[5] * v[2] + v[8] * v[1] * v[6] - v[0] * v[9] * v[6] - v[4] * v[1] * v[10] + v[0] * v[5] * v[10];
		v[0] = t[0] * inv_det;
		v[4] = t[4] * inv_det;
		v[8] = t[8] * inv_det;
		v[12] = t[12] * inv_det;
		v[1] = t[1] * inv_det;
		v[5] = t[5] * inv_det;
		v[9] = t[9] * inv_det;
		v[13] = t[13] * inv_det;
		v[2] = t[2] * inv_det;
		v[6] = t[6] * inv_det;
		v[10] = t[10] * inv_det;
		v[14] = t[14] * inv_det;
		v[3] = t[3] * inv_det;
		v[7] = t[7] * inv_det;
		v[11] = t[11] * inv_det;
		v[15] = t[15] * inv_det;
		return this;
	}
	determinant() {
		let v = this.values;
		return v[3] * v[6] * v[9] * v[12] - v[2] * v[7] * v[9] * v[12] - v[3] * v[5] * v[10] * v[12] + v[1] * v[7] * v[10] * v[12] + v[2] * v[5] * v[11] * v[12] - v[1] * v[6] * v[11] * v[12] - v[3] * v[6] * v[8] * v[13] + v[2] * v[7] * v[8] * v[13] + v[3] * v[4] * v[10] * v[13] - v[0] * v[7] * v[10] * v[13] - v[2] * v[4] * v[11] * v[13] + v[0] * v[6] * v[11] * v[13] + v[3] * v[5] * v[8] * v[14] - v[1] * v[7] * v[8] * v[14] - v[3] * v[4] * v[9] * v[14] + v[0] * v[7] * v[9] * v[14] + v[1] * v[4] * v[11] * v[14] - v[0] * v[5] * v[11] * v[14] - v[2] * v[5] * v[8] * v[15] + v[1] * v[6] * v[8] * v[15] + v[2] * v[4] * v[9] * v[15] - v[0] * v[6] * v[9] * v[15] - v[1] * v[4] * v[10] * v[15] + v[0] * v[5] * v[10] * v[15];
	}
	translate(x, y, z) {
		let v = this.values;
		v[12] += x;
		v[13] += y;
		v[14] += z;
		return this;
	}
	copy() {
		return new Matrix4$1().set(this.values);
	}
	projection(near, far, fovy, aspectRatio) {
		this.identity();
		let l_fd = 1 / Math.tan(fovy * (Math.PI / 180) / 2);
		let l_a1 = (far + near) / (near - far);
		let l_a2 = 2 * far * near / (near - far);
		let v = this.values;
		v[0] = l_fd / aspectRatio;
		v[1] = 0;
		v[2] = 0;
		v[3] = 0;
		v[4] = 0;
		v[5] = l_fd;
		v[6] = 0;
		v[7] = 0;
		v[8] = 0;
		v[9] = 0;
		v[10] = l_a1;
		v[11] = -1;
		v[12] = 0;
		v[13] = 0;
		v[14] = l_a2;
		v[15] = 0;
		return this;
	}
	ortho2d(x, y, width, height) {
		return this.ortho(x, x + width, y, y + height, 0, 1);
	}
	ortho(left, right, bottom, top, near, far) {
		this.identity();
		let x_orth = 2 / (right - left);
		let y_orth = 2 / (top - bottom);
		let z_orth = -2 / (far - near);
		let tx = -(right + left) / (right - left);
		let ty = -(top + bottom) / (top - bottom);
		let tz = -(far + near) / (far - near);
		let v = this.values;
		v[0] = x_orth;
		v[1] = 0;
		v[2] = 0;
		v[3] = 0;
		v[4] = 0;
		v[5] = y_orth;
		v[6] = 0;
		v[7] = 0;
		v[8] = 0;
		v[9] = 0;
		v[10] = z_orth;
		v[11] = 0;
		v[12] = tx;
		v[13] = ty;
		v[14] = tz;
		v[15] = 1;
		return this;
	}
	multiply(matrix) {
		let t = this.temp;
		let v = this.values;
		let m = matrix.values;
		t[0] = v[0] * m[0] + v[4] * m[1] + v[8] * m[2] + v[12] * m[3];
		t[4] = v[0] * m[4] + v[4] * m[5] + v[8] * m[6] + v[12] * m[7];
		t[8] = v[0] * m[8] + v[4] * m[9] + v[8] * m[10] + v[12] * m[11];
		t[12] = v[0] * m[12] + v[4] * m[13] + v[8] * m[14] + v[12] * m[15];
		t[1] = v[1] * m[0] + v[5] * m[1] + v[9] * m[2] + v[13] * m[3];
		t[5] = v[1] * m[4] + v[5] * m[5] + v[9] * m[6] + v[13] * m[7];
		t[9] = v[1] * m[8] + v[5] * m[9] + v[9] * m[10] + v[13] * m[11];
		t[13] = v[1] * m[12] + v[5] * m[13] + v[9] * m[14] + v[13] * m[15];
		t[2] = v[2] * m[0] + v[6] * m[1] + v[10] * m[2] + v[14] * m[3];
		t[6] = v[2] * m[4] + v[6] * m[5] + v[10] * m[6] + v[14] * m[7];
		t[10] = v[2] * m[8] + v[6] * m[9] + v[10] * m[10] + v[14] * m[11];
		t[14] = v[2] * m[12] + v[6] * m[13] + v[10] * m[14] + v[14] * m[15];
		t[3] = v[3] * m[0] + v[7] * m[1] + v[11] * m[2] + v[15] * m[3];
		t[7] = v[3] * m[4] + v[7] * m[5] + v[11] * m[6] + v[15] * m[7];
		t[11] = v[3] * m[8] + v[7] * m[9] + v[11] * m[10] + v[15] * m[11];
		t[15] = v[3] * m[12] + v[7] * m[13] + v[11] * m[14] + v[15] * m[15];
		return this.set(this.temp);
	}
	multiplyLeft(matrix) {
		let t = this.temp;
		let v = this.values;
		let m = matrix.values;
		t[0] = m[0] * v[0] + m[4] * v[1] + m[8] * v[2] + m[12] * v[3];
		t[4] = m[0] * v[4] + m[4] * v[5] + m[8] * v[6] + m[12] * v[7];
		t[8] = m[0] * v[8] + m[4] * v[9] + m[8] * v[10] + m[12] * v[11];
		t[12] = m[0] * v[12] + m[4] * v[13] + m[8] * v[14] + m[12] * v[15];
		t[1] = m[1] * v[0] + m[5] * v[1] + m[9] * v[2] + m[13] * v[3];
		t[5] = m[1] * v[4] + m[5] * v[5] + m[9] * v[6] + m[13] * v[7];
		t[9] = m[1] * v[8] + m[5] * v[9] + m[9] * v[10] + m[13] * v[11];
		t[13] = m[1] * v[12] + m[5] * v[13] + m[9] * v[14] + m[13] * v[15];
		t[2] = m[2] * v[0] + m[6] * v[1] + m[10] * v[2] + m[14] * v[3];
		t[6] = m[2] * v[4] + m[6] * v[5] + m[10] * v[6] + m[14] * v[7];
		t[10] = m[2] * v[8] + m[6] * v[9] + m[10] * v[10] + m[14] * v[11];
		t[14] = m[2] * v[12] + m[6] * v[13] + m[10] * v[14] + m[14] * v[15];
		t[3] = m[3] * v[0] + m[7] * v[1] + m[11] * v[2] + m[15] * v[3];
		t[7] = m[3] * v[4] + m[7] * v[5] + m[11] * v[6] + m[15] * v[7];
		t[11] = m[3] * v[8] + m[7] * v[9] + m[11] * v[10] + m[15] * v[11];
		t[15] = m[3] * v[12] + m[7] * v[13] + m[11] * v[14] + m[15] * v[15];
		return this.set(this.temp);
	}
	lookAt(position, direction, up) {
		let xAxis = Matrix4$1.xAxis, yAxis = Matrix4$1.yAxis, zAxis = Matrix4$1.zAxis;
		zAxis.setFrom(direction).normalize();
		xAxis.setFrom(direction).normalize();
		xAxis.cross(up).normalize();
		yAxis.setFrom(xAxis).cross(zAxis).normalize();
		this.identity();
		let val = this.values;
		val[0] = xAxis.x;
		val[4] = xAxis.y;
		val[8] = xAxis.z;
		val[1] = yAxis.x;
		val[5] = yAxis.y;
		val[9] = yAxis.z;
		val[2] = -zAxis.x;
		val[6] = -zAxis.y;
		val[10] = -zAxis.z;
		Matrix4$1.tmpMatrix.identity();
		Matrix4$1.tmpMatrix.values[12] = -position.x;
		Matrix4$1.tmpMatrix.values[13] = -position.y;
		Matrix4$1.tmpMatrix.values[14] = -position.z;
		this.multiply(Matrix4$1.tmpMatrix);
		return this;
	}
};
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/Camera.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var OrthoCamera$1 = class {
	position = new Vector3$1(0, 0, 0);
	direction = new Vector3$1(0, 0, -1);
	up = new Vector3$1(0, 1, 0);
	near = 0;
	far = 100;
	zoom = 1;
	viewportWidth = 0;
	viewportHeight = 0;
	projectionView = new Matrix4$1();
	inverseProjectionView = new Matrix4$1();
	projection = new Matrix4$1();
	view = new Matrix4$1();
	constructor(viewportWidth, viewportHeight) {
		this.viewportWidth = viewportWidth;
		this.viewportHeight = viewportHeight;
		this.update();
	}
	update() {
		let projection = this.projection;
		let view = this.view;
		let projectionView = this.projectionView;
		let inverseProjectionView = this.inverseProjectionView;
		let zoom = this.zoom, viewportWidth = this.viewportWidth, viewportHeight = this.viewportHeight;
		projection.ortho(zoom * (-viewportWidth / 2), zoom * (viewportWidth / 2), zoom * (-viewportHeight / 2), zoom * (viewportHeight / 2), this.near, this.far);
		view.lookAt(this.position, this.direction, this.up);
		projectionView.set(projection.values);
		projectionView.multiply(view);
		inverseProjectionView.set(projectionView.values).invert();
	}
	screenToWorld(screenCoords, screenWidth, screenHeight) {
		let x = screenCoords.x, y = screenHeight - screenCoords.y - 1;
		screenCoords.x = 2 * x / screenWidth - 1;
		screenCoords.y = 2 * y / screenHeight - 1;
		screenCoords.z = 2 * screenCoords.z - 1;
		screenCoords.project(this.inverseProjectionView);
		return screenCoords;
	}
	worldToScreen(worldCoords, screenWidth, screenHeight) {
		worldCoords.project(this.projectionView);
		worldCoords.x = screenWidth * (worldCoords.x + 1) / 2;
		worldCoords.y = screenHeight * (worldCoords.y + 1) / 2;
		worldCoords.z = (worldCoords.z + 1) / 2;
		return worldCoords;
	}
	setViewport(viewportWidth, viewportHeight) {
		this.viewportWidth = viewportWidth;
		this.viewportHeight = viewportHeight;
	}
};
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/Input.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Input$1 = class {
	element;
	mouseX = 0;
	mouseY = 0;
	buttonDown = false;
	touch0 = null;
	touch1 = null;
	initialPinchDistance = 0;
	listeners = new Array();
	eventListeners = [];
	constructor(element) {
		this.element = element;
		this.setupCallbacks(element);
	}
	setupCallbacks(element) {
		let mouseDown = (ev) => {
			if (ev instanceof MouseEvent) {
				let rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.buttonDown = true;
				this.listeners.map((listener) => {
					if (listener.down) listener.down(this.mouseX, this.mouseY);
				});
				document.addEventListener("mousemove", mouseMove);
				document.addEventListener("mouseup", mouseUp);
			}
		};
		let mouseMove = (ev) => {
			if (ev instanceof MouseEvent) {
				let rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.listeners.map((listener) => {
					if (this.buttonDown) {
						if (listener.dragged) listener.dragged(this.mouseX, this.mouseY);
					} else if (listener.moved) listener.moved(this.mouseX, this.mouseY);
				});
			}
		};
		let mouseUp = (ev) => {
			if (ev instanceof MouseEvent) {
				let rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.buttonDown = false;
				this.listeners.map((listener) => {
					if (listener.up) listener.up(this.mouseX, this.mouseY);
				});
				document.removeEventListener("mousemove", mouseMove);
				document.removeEventListener("mouseup", mouseUp);
			}
		};
		let mouseWheel = (e) => {
			e.preventDefault();
			let deltaY = e.deltaY;
			if (e.deltaMode == WheelEvent.DOM_DELTA_LINE) deltaY *= 8;
			if (e.deltaMode == WheelEvent.DOM_DELTA_PAGE) deltaY *= 24;
			this.listeners.map((listener) => {
				if (listener.wheel) listener.wheel(e.deltaY);
			});
		};
		element.addEventListener("mousedown", mouseDown, true);
		element.addEventListener("mousemove", mouseMove, true);
		element.addEventListener("mouseup", mouseUp, true);
		element.addEventListener("wheel", mouseWheel, true);
		element.addEventListener("touchstart", (ev) => {
			if (!this.touch0 || !this.touch1) {
				let nativeTouch = ev.changedTouches.item(0);
				if (!nativeTouch) return;
				let rect = element.getBoundingClientRect();
				let x = nativeTouch.clientX - rect.left;
				let y = nativeTouch.clientY - rect.top;
				let touch = new Touch$1(nativeTouch.identifier, x, y);
				this.mouseX = x;
				this.mouseY = y;
				this.buttonDown = true;
				if (!this.touch0) {
					this.touch0 = touch;
					this.listeners.map((listener) => {
						if (listener.down) listener.down(touch.x, touch.y);
					});
				} else if (!this.touch1) {
					this.touch1 = touch;
					let dx = this.touch1.x - this.touch0.x;
					let dy = this.touch1.x - this.touch0.x;
					this.initialPinchDistance = Math.sqrt(dx * dx + dy * dy);
					this.listeners.map((listener) => {
						if (listener.zoom) listener.zoom(this.initialPinchDistance, this.initialPinchDistance);
					});
				}
			}
			ev.preventDefault();
		}, false);
		element.addEventListener("touchmove", (ev) => {
			if (this.touch0) {
				var touches = ev.changedTouches;
				let rect = element.getBoundingClientRect();
				for (var i = 0; i < touches.length; i++) {
					var nativeTouch = touches[i];
					let x = nativeTouch.clientX - rect.left;
					let y = nativeTouch.clientY - rect.top;
					if (this.touch0.identifier === nativeTouch.identifier) {
						this.touch0.x = this.mouseX = x;
						this.touch0.y = this.mouseY = y;
						this.listeners.map((listener) => {
							if (listener.dragged) listener.dragged(x, y);
						});
					}
					if (this.touch1 && this.touch1.identifier === nativeTouch.identifier) {
						this.touch1.x = this.mouseX = x;
						this.touch1.y = this.mouseY = y;
					}
				}
				if (this.touch0 && this.touch1) {
					let dx = this.touch1.x - this.touch0.x;
					let dy = this.touch1.x - this.touch0.x;
					let distance = Math.sqrt(dx * dx + dy * dy);
					this.listeners.map((listener) => {
						if (listener.zoom) listener.zoom(this.initialPinchDistance, distance);
					});
				}
			}
			ev.preventDefault();
		}, false);
		let touchEnd = (ev) => {
			if (this.touch0) {
				var touches = ev.changedTouches;
				let rect = element.getBoundingClientRect();
				for (var i = 0; i < touches.length; i++) {
					var nativeTouch = touches[i];
					let x = nativeTouch.clientX - rect.left;
					let y = nativeTouch.clientY - rect.top;
					if (this.touch0.identifier === nativeTouch.identifier) {
						this.touch0 = null;
						this.mouseX = x;
						this.mouseY = y;
						this.listeners.map((listener) => {
							if (listener.up) listener.up(x, y);
						});
						if (!this.touch1) {
							this.buttonDown = false;
							break;
						} else {
							this.touch0 = this.touch1;
							this.touch1 = null;
							this.mouseX = this.touch0.x;
							this.mouseX = this.touch0.x;
							this.buttonDown = true;
							this.listeners.map((listener) => {
								if (listener.down) listener.down(this.touch0.x, this.touch0.y);
							});
						}
					}
					if (this.touch1 && this.touch1.identifier) this.touch1 = null;
				}
			}
			ev.preventDefault();
		};
		element.addEventListener("touchend", touchEnd, false);
		element.addEventListener("touchcancel", touchEnd);
	}
	addListener(listener) {
		this.listeners.push(listener);
	}
	removeListener(listener) {
		let idx = this.listeners.indexOf(listener);
		if (idx > -1) this.listeners.splice(idx, 1);
	}
};
var Touch$1 = class {
	identifier;
	x;
	y;
	constructor(identifier, x, y) {
		this.identifier = identifier;
		this.x = x;
		this.y = y;
	}
};
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/Shader.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Shader$1 = class Shader$1 {
	vertexShader;
	fragmentShader;
	static MVP_MATRIX = "u_projTrans";
	static POSITION = "a_position";
	static COLOR = "a_color";
	static COLOR2 = "a_color2";
	static TEXCOORDS = "a_texCoords";
	static SAMPLER = "u_texture";
	context;
	vs = null;
	vsSource;
	fs = null;
	fsSource;
	program = null;
	tmp2x2 = /* @__PURE__ */ new Float32Array(4);
	tmp3x3 = /* @__PURE__ */ new Float32Array(9);
	tmp4x4 = /* @__PURE__ */ new Float32Array(16);
	getProgram() {
		return this.program;
	}
	getVertexShader() {
		return this.vertexShader;
	}
	getFragmentShader() {
		return this.fragmentShader;
	}
	getVertexShaderSource() {
		return this.vsSource;
	}
	getFragmentSource() {
		return this.fsSource;
	}
	constructor(context, vertexShader, fragmentShader) {
		this.vertexShader = vertexShader;
		this.fragmentShader = fragmentShader;
		this.vsSource = vertexShader;
		this.fsSource = fragmentShader;
		this.context = context instanceof ManagedWebGLRenderingContext$1 ? context : new ManagedWebGLRenderingContext$1(context);
		this.context.addRestorable(this);
		this.compile();
	}
	compile() {
		let gl = this.context.gl;
		try {
			this.vs = this.compileShader(gl.VERTEX_SHADER, this.vertexShader);
			if (!this.vs) throw new Error("Couldn't compile vertex shader.");
			this.fs = this.compileShader(gl.FRAGMENT_SHADER, this.fragmentShader);
			if (!this.fs) throw new Error("Couldn#t compile fragment shader.");
			this.program = this.compileProgram(this.vs, this.fs);
		} catch (e) {
			this.dispose();
			throw e;
		}
	}
	compileShader(type, source) {
		let gl = this.context.gl;
		let shader = gl.createShader(type);
		if (!shader) throw new Error("Couldn't create shader.");
		gl.shaderSource(shader, source);
		gl.compileShader(shader);
		if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
			let error = "Couldn't compile shader: " + gl.getShaderInfoLog(shader);
			gl.deleteShader(shader);
			if (!gl.isContextLost()) throw new Error(error);
		}
		return shader;
	}
	compileProgram(vs, fs) {
		let gl = this.context.gl;
		let program = gl.createProgram();
		if (!program) throw new Error("Couldn't compile program.");
		gl.attachShader(program, vs);
		gl.attachShader(program, fs);
		gl.linkProgram(program);
		if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
			let error = "Couldn't compile shader program: " + gl.getProgramInfoLog(program);
			gl.deleteProgram(program);
			if (!gl.isContextLost()) throw new Error(error);
		}
		return program;
	}
	restore() {
		this.compile();
	}
	bind() {
		this.context.gl.useProgram(this.program);
	}
	unbind() {
		this.context.gl.useProgram(null);
	}
	setUniformi(uniform, value) {
		this.context.gl.uniform1i(this.getUniformLocation(uniform), value);
	}
	setUniformf(uniform, value) {
		this.context.gl.uniform1f(this.getUniformLocation(uniform), value);
	}
	setUniform2f(uniform, value, value2) {
		this.context.gl.uniform2f(this.getUniformLocation(uniform), value, value2);
	}
	setUniform3f(uniform, value, value2, value3) {
		this.context.gl.uniform3f(this.getUniformLocation(uniform), value, value2, value3);
	}
	setUniform4f(uniform, value, value2, value3, value4) {
		this.context.gl.uniform4f(this.getUniformLocation(uniform), value, value2, value3, value4);
	}
	setUniform2x2f(uniform, value) {
		let gl = this.context.gl;
		this.tmp2x2.set(value);
		gl.uniformMatrix2fv(this.getUniformLocation(uniform), false, this.tmp2x2);
	}
	setUniform3x3f(uniform, value) {
		let gl = this.context.gl;
		this.tmp3x3.set(value);
		gl.uniformMatrix3fv(this.getUniformLocation(uniform), false, this.tmp3x3);
	}
	setUniform4x4f(uniform, value) {
		let gl = this.context.gl;
		this.tmp4x4.set(value);
		gl.uniformMatrix4fv(this.getUniformLocation(uniform), false, this.tmp4x4);
	}
	getUniformLocation(uniform) {
		let gl = this.context.gl;
		if (!this.program) throw new Error("Shader not compiled.");
		let location = gl.getUniformLocation(this.program, uniform);
		if (!location && !gl.isContextLost()) throw new Error(`Couldn't find location for uniform ${uniform}`);
		return location;
	}
	getAttributeLocation(attribute) {
		let gl = this.context.gl;
		if (!this.program) throw new Error("Shader not compiled.");
		let location = gl.getAttribLocation(this.program, attribute);
		if (location == -1 && !gl.isContextLost()) throw new Error(`Couldn't find location for attribute ${attribute}`);
		return location;
	}
	dispose() {
		this.context.removeRestorable(this);
		let gl = this.context.gl;
		if (this.vs) {
			gl.deleteShader(this.vs);
			this.vs = null;
		}
		if (this.fs) {
			gl.deleteShader(this.fs);
			this.fs = null;
		}
		if (this.program) {
			gl.deleteProgram(this.program);
			this.program = null;
		}
	}
	static newColoredTextured(context) {
		let vs = `
attribute vec4 ${Shader$1.POSITION};
attribute vec4 ${Shader$1.COLOR};
attribute vec2 ${Shader$1.TEXCOORDS};
uniform mat4 ${Shader$1.MVP_MATRIX};
varying vec4 v_color;
varying vec2 v_texCoords;

void main () {
	v_color = ${Shader$1.COLOR};
	v_texCoords = ${Shader$1.TEXCOORDS};
	gl_Position = ${Shader$1.MVP_MATRIX} * ${Shader$1.POSITION};
}
`;
		return new Shader$1(context, vs, `
#ifdef GL_ES
	#define LOWP lowp
	precision mediump float;
#else
	#define LOWP
#endif
varying LOWP vec4 v_color;
varying vec2 v_texCoords;
uniform sampler2D u_texture;

void main () {
	gl_FragColor = v_color * texture2D(u_texture, v_texCoords);
}
`);
	}
	static newTwoColoredTextured(context) {
		let vs = `
attribute vec4 ${Shader$1.POSITION};
attribute vec4 ${Shader$1.COLOR};
attribute vec4 ${Shader$1.COLOR2};
attribute vec2 ${Shader$1.TEXCOORDS};
uniform mat4 ${Shader$1.MVP_MATRIX};
varying vec4 v_light;
varying vec4 v_dark;
varying vec2 v_texCoords;

void main () {
	v_light = ${Shader$1.COLOR};
	v_dark = ${Shader$1.COLOR2};
	v_texCoords = ${Shader$1.TEXCOORDS};
	gl_Position = ${Shader$1.MVP_MATRIX} * ${Shader$1.POSITION};
}
`;
		return new Shader$1(context, vs, `
#ifdef GL_ES
	#define LOWP lowp
	precision mediump float;
#else
	#define LOWP
#endif
varying LOWP vec4 v_light;
varying LOWP vec4 v_dark;
varying vec2 v_texCoords;
uniform sampler2D u_texture;

void main () {
	vec4 texColor = texture2D(u_texture, v_texCoords);
	gl_FragColor.a = texColor.a * v_light.a;
	gl_FragColor.rgb = ((texColor.a - 1.0) * v_dark.a + 1.0 - texColor.rgb) * v_dark.rgb + texColor.rgb * v_light.rgb;
}
`);
	}
	static newColored(context) {
		let vs = `
attribute vec4 ${Shader$1.POSITION};
attribute vec4 ${Shader$1.COLOR};
uniform mat4 ${Shader$1.MVP_MATRIX};
varying vec4 v_color;

void main () {
	v_color = ${Shader$1.COLOR};
	gl_Position = ${Shader$1.MVP_MATRIX} * ${Shader$1.POSITION};
}
`;
		return new Shader$1(context, vs, `
#ifdef GL_ES
	#define LOWP lowp
	precision mediump float;
#else
	#define LOWP
#endif
varying LOWP vec4 v_color;

void main () {
	gl_FragColor = v_color;
}
`);
	}
};
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/Mesh.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Mesh$1 = class {
	attributes;
	context;
	vertices;
	verticesBuffer = null;
	verticesLength = 0;
	dirtyVertices = false;
	indices;
	indicesBuffer = null;
	indicesLength = 0;
	dirtyIndices = false;
	elementsPerVertex = 0;
	getAttributes() {
		return this.attributes;
	}
	maxVertices() {
		return this.vertices.length / this.elementsPerVertex;
	}
	numVertices() {
		return this.verticesLength / this.elementsPerVertex;
	}
	setVerticesLength(length) {
		this.dirtyVertices = true;
		this.verticesLength = length;
	}
	getVertices() {
		return this.vertices;
	}
	maxIndices() {
		return this.indices.length;
	}
	numIndices() {
		return this.indicesLength;
	}
	setIndicesLength(length) {
		this.dirtyIndices = true;
		this.indicesLength = length;
	}
	getIndices() {
		return this.indices;
	}
	getVertexSizeInFloats() {
		let size = 0;
		for (var i = 0; i < this.attributes.length; i++) {
			let attribute = this.attributes[i];
			size += attribute.numElements;
		}
		return size;
	}
	constructor(context, attributes, maxVertices, maxIndices) {
		this.attributes = attributes;
		this.context = context instanceof ManagedWebGLRenderingContext$1 ? context : new ManagedWebGLRenderingContext$1(context);
		this.elementsPerVertex = 0;
		for (let i = 0; i < attributes.length; i++) this.elementsPerVertex += attributes[i].numElements;
		this.vertices = new Float32Array(maxVertices * this.elementsPerVertex);
		this.indices = new Uint16Array(maxIndices);
		this.context.addRestorable(this);
	}
	setVertices(vertices) {
		this.dirtyVertices = true;
		if (vertices.length > this.vertices.length) throw Error("Mesh can't store more than " + this.maxVertices() + " vertices");
		this.vertices.set(vertices, 0);
		this.verticesLength = vertices.length;
	}
	setIndices(indices) {
		this.dirtyIndices = true;
		if (indices.length > this.indices.length) throw Error("Mesh can't store more than " + this.maxIndices() + " indices");
		this.indices.set(indices, 0);
		this.indicesLength = indices.length;
	}
	draw(shader, primitiveType) {
		this.drawWithOffset(shader, primitiveType, 0, this.indicesLength > 0 ? this.indicesLength : this.verticesLength / this.elementsPerVertex);
	}
	drawWithOffset(shader, primitiveType, offset, count) {
		let gl = this.context.gl;
		if (this.dirtyVertices || this.dirtyIndices) this.update();
		this.bind(shader);
		if (this.indicesLength > 0) gl.drawElements(primitiveType, count, gl.UNSIGNED_SHORT, offset * 2);
		else gl.drawArrays(primitiveType, offset, count);
		this.unbind(shader);
	}
	bind(shader) {
		let gl = this.context.gl;
		gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);
		let offset = 0;
		for (let i = 0; i < this.attributes.length; i++) {
			let attrib = this.attributes[i];
			let location = shader.getAttributeLocation(attrib.name);
			gl.enableVertexAttribArray(location);
			gl.vertexAttribPointer(location, attrib.numElements, gl.FLOAT, false, this.elementsPerVertex * 4, offset * 4);
			offset += attrib.numElements;
		}
		if (this.indicesLength > 0) gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indicesBuffer);
	}
	unbind(shader) {
		let gl = this.context.gl;
		for (let i = 0; i < this.attributes.length; i++) {
			let attrib = this.attributes[i];
			let location = shader.getAttributeLocation(attrib.name);
			gl.disableVertexAttribArray(location);
		}
		gl.bindBuffer(gl.ARRAY_BUFFER, null);
		if (this.indicesLength > 0) gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null);
	}
	update() {
		let gl = this.context.gl;
		if (this.dirtyVertices) {
			if (!this.verticesBuffer) this.verticesBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);
			gl.bufferData(gl.ARRAY_BUFFER, this.vertices.subarray(0, this.verticesLength), gl.DYNAMIC_DRAW);
			this.dirtyVertices = false;
		}
		if (this.dirtyIndices) {
			if (!this.indicesBuffer) this.indicesBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indicesBuffer);
			gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.indices.subarray(0, this.indicesLength), gl.DYNAMIC_DRAW);
			this.dirtyIndices = false;
		}
	}
	restore() {
		this.verticesBuffer = null;
		this.indicesBuffer = null;
		this.update();
	}
	dispose() {
		this.context.removeRestorable(this);
		let gl = this.context.gl;
		gl.deleteBuffer(this.verticesBuffer);
		gl.deleteBuffer(this.indicesBuffer);
	}
};
var VertexAttribute$1 = class {
	name;
	type;
	numElements;
	constructor(name, type, numElements) {
		this.name = name;
		this.type = type;
		this.numElements = numElements;
	}
};
var Position2Attribute$1 = class extends VertexAttribute$1 {
	constructor() {
		super(Shader$1.POSITION, VertexAttributeType$1.Float, 2);
	}
};
var TexCoordAttribute$1 = class extends VertexAttribute$1 {
	constructor(unit = 0) {
		super(Shader$1.TEXCOORDS + (unit == 0 ? "" : unit), VertexAttributeType$1.Float, 2);
	}
};
var ColorAttribute$1 = class extends VertexAttribute$1 {
	constructor() {
		super(Shader$1.COLOR, VertexAttributeType$1.Float, 4);
	}
};
var Color2Attribute$1 = class extends VertexAttribute$1 {
	constructor() {
		super(Shader$1.COLOR2, VertexAttributeType$1.Float, 4);
	}
};
var VertexAttributeType$1;
(function(VertexAttributeType) {
	VertexAttributeType[VertexAttributeType["Float"] = 0] = "Float";
})(VertexAttributeType$1 || (VertexAttributeType$1 = {}));
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/PolygonBatcher.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var GL_ONE$1 = 1;
var GL_ONE_MINUS_SRC_COLOR$1 = 769;
var GL_SRC_ALPHA$1 = 770;
var GL_ONE_MINUS_SRC_ALPHA$1 = 771;
var GL_DST_COLOR$1 = 774;
var PolygonBatcher$1 = class PolygonBatcher$1 {
	static disableCulling = false;
	context;
	drawCalls = 0;
	static globalDrawCalls = 0;
	isDrawing = false;
	mesh;
	shader = null;
	lastTexture = null;
	verticesLength = 0;
	indicesLength = 0;
	srcColorBlend;
	srcAlphaBlend;
	dstBlend;
	cullWasEnabled = false;
	constructor(context, twoColorTint = true, maxVertices = 10920) {
		if (maxVertices > 10920) throw new Error("Can't have more than 10920 triangles per batch: " + maxVertices);
		this.context = context instanceof ManagedWebGLRenderingContext$1 ? context : new ManagedWebGLRenderingContext$1(context);
		let attributes = twoColorTint ? [
			new Position2Attribute$1(),
			new ColorAttribute$1(),
			new TexCoordAttribute$1(),
			new Color2Attribute$1()
		] : [
			new Position2Attribute$1(),
			new ColorAttribute$1(),
			new TexCoordAttribute$1()
		];
		this.mesh = new Mesh$1(context, attributes, maxVertices, maxVertices * 3);
		let gl = this.context.gl;
		this.srcColorBlend = gl.SRC_ALPHA;
		this.srcAlphaBlend = gl.ONE;
		this.dstBlend = gl.ONE_MINUS_SRC_ALPHA;
	}
	begin(shader) {
		if (this.isDrawing) throw new Error("PolygonBatch is already drawing. Call PolygonBatch.end() before calling PolygonBatch.begin()");
		this.drawCalls = 0;
		this.shader = shader;
		this.lastTexture = null;
		this.isDrawing = true;
		let gl = this.context.gl;
		gl.enable(gl.BLEND);
		gl.blendFuncSeparate(this.srcColorBlend, this.dstBlend, this.srcAlphaBlend, this.dstBlend);
		if (PolygonBatcher$1.disableCulling) {
			this.cullWasEnabled = gl.isEnabled(gl.CULL_FACE);
			if (this.cullWasEnabled) gl.disable(gl.CULL_FACE);
		}
	}
	static blendModesGL = [
		{
			srcRgb: GL_SRC_ALPHA$1,
			srcRgbPma: GL_ONE$1,
			dstRgb: GL_ONE_MINUS_SRC_ALPHA$1,
			srcAlpha: GL_ONE$1
		},
		{
			srcRgb: GL_SRC_ALPHA$1,
			srcRgbPma: GL_ONE$1,
			dstRgb: GL_ONE$1,
			srcAlpha: GL_ONE$1
		},
		{
			srcRgb: GL_DST_COLOR$1,
			srcRgbPma: GL_DST_COLOR$1,
			dstRgb: GL_ONE_MINUS_SRC_ALPHA$1,
			srcAlpha: GL_ONE$1
		},
		{
			srcRgb: GL_ONE$1,
			srcRgbPma: GL_ONE$1,
			dstRgb: GL_ONE_MINUS_SRC_COLOR$1,
			srcAlpha: GL_ONE$1
		}
	];
	setBlendMode(blendMode, premultipliedAlpha) {
		const blendModeGL = PolygonBatcher$1.blendModesGL[blendMode];
		const srcColorBlend = premultipliedAlpha ? blendModeGL.srcRgbPma : blendModeGL.srcRgb;
		const srcAlphaBlend = blendModeGL.srcAlpha;
		const dstBlend = blendModeGL.dstRgb;
		if (this.srcColorBlend == srcColorBlend && this.srcAlphaBlend == srcAlphaBlend && this.dstBlend == dstBlend) return;
		this.srcColorBlend = srcColorBlend;
		this.srcAlphaBlend = srcAlphaBlend;
		this.dstBlend = dstBlend;
		if (this.isDrawing) this.flush();
		this.context.gl.blendFuncSeparate(srcColorBlend, dstBlend, srcAlphaBlend, dstBlend);
	}
	draw(texture, vertices, indices) {
		if (texture != this.lastTexture) {
			this.flush();
			this.lastTexture = texture;
		} else if (this.verticesLength + vertices.length > this.mesh.getVertices().length || this.indicesLength + indices.length > this.mesh.getIndices().length) this.flush();
		let indexStart = this.mesh.numVertices();
		this.mesh.getVertices().set(vertices, this.verticesLength);
		this.verticesLength += vertices.length;
		this.mesh.setVerticesLength(this.verticesLength);
		let indicesArray = this.mesh.getIndices();
		for (let i = this.indicesLength, j = 0; j < indices.length; i++, j++) indicesArray[i] = indices[j] + indexStart;
		this.indicesLength += indices.length;
		this.mesh.setIndicesLength(this.indicesLength);
	}
	flush() {
		if (this.verticesLength == 0) return;
		if (!this.lastTexture) throw new Error("No texture set.");
		if (!this.shader) throw new Error("No shader set.");
		this.lastTexture.bind();
		this.mesh.draw(this.shader, this.context.gl.TRIANGLES);
		this.verticesLength = 0;
		this.indicesLength = 0;
		this.mesh.setVerticesLength(0);
		this.mesh.setIndicesLength(0);
		this.drawCalls++;
		PolygonBatcher$1.globalDrawCalls++;
	}
	end() {
		if (!this.isDrawing) throw new Error("PolygonBatch is not drawing. Call PolygonBatch.begin() before calling PolygonBatch.end()");
		if (this.verticesLength > 0 || this.indicesLength > 0) this.flush();
		this.shader = null;
		this.lastTexture = null;
		this.isDrawing = false;
		let gl = this.context.gl;
		gl.disable(gl.BLEND);
		if (PolygonBatcher$1.disableCulling) {
			if (this.cullWasEnabled) gl.enable(gl.CULL_FACE);
		}
	}
	getDrawCalls() {
		return this.drawCalls;
	}
	static getAndResetGlobalDrawCalls() {
		let result = PolygonBatcher$1.globalDrawCalls;
		PolygonBatcher$1.globalDrawCalls = 0;
		return result;
	}
	dispose() {
		this.mesh.dispose();
	}
};
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/ShapeRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var ShapeRenderer$1 = class {
	context;
	isDrawing = false;
	mesh;
	shapeType = ShapeType$1.Filled;
	color = new Color$1(1, 1, 1, 1);
	shader = null;
	vertexIndex = 0;
	tmp = new Vector2$1();
	srcColorBlend;
	srcAlphaBlend;
	dstBlend;
	constructor(context, maxVertices = 10920) {
		if (maxVertices > 10920) throw new Error("Can't have more than 10920 triangles per batch: " + maxVertices);
		this.context = context instanceof ManagedWebGLRenderingContext$1 ? context : new ManagedWebGLRenderingContext$1(context);
		this.mesh = new Mesh$1(context, [new Position2Attribute$1(), new ColorAttribute$1()], maxVertices, 0);
		let gl = this.context.gl;
		this.srcColorBlend = gl.SRC_ALPHA;
		this.srcAlphaBlend = gl.ONE;
		this.dstBlend = gl.ONE_MINUS_SRC_ALPHA;
	}
	begin(shader) {
		if (this.isDrawing) throw new Error("ShapeRenderer.begin() has already been called");
		this.shader = shader;
		this.vertexIndex = 0;
		this.isDrawing = true;
		let gl = this.context.gl;
		gl.enable(gl.BLEND);
		gl.blendFuncSeparate(this.srcColorBlend, this.dstBlend, this.srcAlphaBlend, this.dstBlend);
	}
	setBlendMode(srcColorBlend, srcAlphaBlend, dstBlend) {
		this.srcColorBlend = srcColorBlend;
		this.srcAlphaBlend = srcAlphaBlend;
		this.dstBlend = dstBlend;
		if (this.isDrawing) {
			this.flush();
			this.context.gl.blendFuncSeparate(srcColorBlend, dstBlend, srcAlphaBlend, dstBlend);
		}
	}
	setColor(color) {
		this.color.setFromColor(color);
	}
	setColorWith(r, g, b, a) {
		this.color.set(r, g, b, a);
	}
	point(x, y, color) {
		this.check(ShapeType$1.Point, 1);
		if (!color) color = this.color;
		this.vertex(x, y, color);
	}
	line(x, y, x2, y2, color) {
		this.check(ShapeType$1.Line, 2);
		this.mesh.getVertices();
		this.vertexIndex;
		if (!color) color = this.color;
		this.vertex(x, y, color);
		this.vertex(x2, y2, color);
	}
	triangle(filled, x, y, x2, y2, x3, y3, color, color2, color3) {
		this.check(filled ? ShapeType$1.Filled : ShapeType$1.Line, 3);
		this.mesh.getVertices();
		this.vertexIndex;
		if (!color) color = this.color;
		if (!color2) color2 = this.color;
		if (!color3) color3 = this.color;
		if (filled) {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
		} else {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x2, y2, color);
			this.vertex(x3, y3, color2);
			this.vertex(x3, y3, color);
			this.vertex(x, y, color2);
		}
	}
	quad(filled, x, y, x2, y2, x3, y3, x4, y4, color, color2, color3, color4) {
		this.check(filled ? ShapeType$1.Filled : ShapeType$1.Line, 3);
		this.mesh.getVertices();
		this.vertexIndex;
		if (!color) color = this.color;
		if (!color2) color2 = this.color;
		if (!color3) color3 = this.color;
		if (!color4) color4 = this.color;
		if (filled) {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
			this.vertex(x3, y3, color3);
			this.vertex(x4, y4, color4);
			this.vertex(x, y, color);
		} else {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
			this.vertex(x3, y3, color3);
			this.vertex(x4, y4, color4);
			this.vertex(x4, y4, color4);
			this.vertex(x, y, color);
		}
	}
	rect(filled, x, y, width, height, color) {
		this.quad(filled, x, y, x + width, y, x + width, y + height, x, y + height, color, color, color, color);
	}
	rectLine(filled, x1, y1, x2, y2, width, color) {
		this.check(filled ? ShapeType$1.Filled : ShapeType$1.Line, 8);
		if (!color) color = this.color;
		let t = this.tmp.set(y2 - y1, x1 - x2);
		t.normalize();
		width *= .5;
		let tx = t.x * width;
		let ty = t.y * width;
		if (!filled) {
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
		} else {
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
		}
	}
	x(x, y, size) {
		this.line(x - size, y - size, x + size, y + size);
		this.line(x - size, y + size, x + size, y - size);
	}
	polygon(polygonVertices, offset, count, color) {
		if (count < 3) throw new Error("Polygon must contain at least 3 vertices");
		this.check(ShapeType$1.Line, count * 2);
		if (!color) color = this.color;
		this.mesh.getVertices();
		this.vertexIndex;
		offset <<= 1;
		count <<= 1;
		let firstX = polygonVertices[offset];
		let firstY = polygonVertices[offset + 1];
		let last = offset + count;
		for (let i = offset, n = offset + count - 2; i < n; i += 2) {
			let x1 = polygonVertices[i];
			let y1 = polygonVertices[i + 1];
			let x2 = 0;
			let y2 = 0;
			if (i + 2 >= last) {
				x2 = firstX;
				y2 = firstY;
			} else {
				x2 = polygonVertices[i + 2];
				y2 = polygonVertices[i + 3];
			}
			this.vertex(x1, y1, color);
			this.vertex(x2, y2, color);
		}
	}
	circle(filled, x, y, radius, color, segments = 0) {
		if (segments == 0) segments = Math.max(1, 6 * MathUtils$1.cbrt(radius) | 0);
		if (segments <= 0) throw new Error("segments must be > 0.");
		if (!color) color = this.color;
		let angle = 2 * MathUtils$1.PI / segments;
		let cos = Math.cos(angle);
		let sin = Math.sin(angle);
		let cx = radius, cy = 0;
		if (!filled) {
			this.check(ShapeType$1.Line, segments * 2 + 2);
			for (let i = 0; i < segments; i++) {
				this.vertex(x + cx, y + cy, color);
				let temp = cx;
				cx = cos * cx - sin * cy;
				cy = sin * temp + cos * cy;
				this.vertex(x + cx, y + cy, color);
			}
			this.vertex(x + cx, y + cy, color);
		} else {
			this.check(ShapeType$1.Filled, segments * 3 + 3);
			segments--;
			for (let i = 0; i < segments; i++) {
				this.vertex(x, y, color);
				this.vertex(x + cx, y + cy, color);
				let temp = cx;
				cx = cos * cx - sin * cy;
				cy = sin * temp + cos * cy;
				this.vertex(x + cx, y + cy, color);
			}
			this.vertex(x, y, color);
			this.vertex(x + cx, y + cy, color);
		}
		cx = radius;
		cy = 0;
		this.vertex(x + cx, y + cy, color);
	}
	curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color) {
		this.check(ShapeType$1.Line, segments * 2 + 2);
		if (!color) color = this.color;
		let subdiv_step = 1 / segments;
		let subdiv_step2 = subdiv_step * subdiv_step;
		let subdiv_step3 = subdiv_step * subdiv_step * subdiv_step;
		let pre1 = 3 * subdiv_step;
		let pre2 = 3 * subdiv_step2;
		let pre4 = 6 * subdiv_step2;
		let pre5 = 6 * subdiv_step3;
		let tmp1x = x1 - cx1 * 2 + cx2;
		let tmp1y = y1 - cy1 * 2 + cy2;
		let tmp2x = (cx1 - cx2) * 3 - x1 + x2;
		let tmp2y = (cy1 - cy2) * 3 - y1 + y2;
		let fx = x1;
		let fy = y1;
		let dfx = (cx1 - x1) * pre1 + tmp1x * pre2 + tmp2x * subdiv_step3;
		let dfy = (cy1 - y1) * pre1 + tmp1y * pre2 + tmp2y * subdiv_step3;
		let ddfx = tmp1x * pre4 + tmp2x * pre5;
		let ddfy = tmp1y * pre4 + tmp2y * pre5;
		let dddfx = tmp2x * pre5;
		let dddfy = tmp2y * pre5;
		while (segments-- > 0) {
			this.vertex(fx, fy, color);
			fx += dfx;
			fy += dfy;
			dfx += ddfx;
			dfy += ddfy;
			ddfx += dddfx;
			ddfy += dddfy;
			this.vertex(fx, fy, color);
		}
		this.vertex(fx, fy, color);
		this.vertex(x2, y2, color);
	}
	vertex(x, y, color) {
		let idx = this.vertexIndex;
		let vertices = this.mesh.getVertices();
		vertices[idx++] = x;
		vertices[idx++] = y;
		vertices[idx++] = color.r;
		vertices[idx++] = color.g;
		vertices[idx++] = color.b;
		vertices[idx++] = color.a;
		this.vertexIndex = idx;
	}
	end() {
		if (!this.isDrawing) throw new Error("ShapeRenderer.begin() has not been called");
		this.flush();
		let gl = this.context.gl;
		gl.disable(gl.BLEND);
		this.isDrawing = false;
	}
	flush() {
		if (this.vertexIndex == 0) return;
		if (!this.shader) throw new Error("No shader set.");
		this.mesh.setVerticesLength(this.vertexIndex);
		this.mesh.draw(this.shader, this.shapeType);
		this.vertexIndex = 0;
	}
	check(shapeType, numVertices) {
		if (!this.isDrawing) throw new Error("ShapeRenderer.begin() has not been called");
		if (this.shapeType == shapeType) {
			if (this.mesh.maxVertices() - this.mesh.numVertices() < numVertices) this.flush();
			else return;
		} else {
			this.flush();
			this.shapeType = shapeType;
		}
	}
	dispose() {
		this.mesh.dispose();
	}
};
var ShapeType$1;
(function(ShapeType) {
	ShapeType[ShapeType["Point"] = 0] = "Point";
	ShapeType[ShapeType["Line"] = 1] = "Line";
	ShapeType[ShapeType["Filled"] = 4] = "Filled";
})(ShapeType$1 || (ShapeType$1 = {}));
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/SkeletonDebugRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var SkeletonDebugRenderer$1 = class SkeletonDebugRenderer$1 {
	boneLineColor = new Color$1(1, 0, 0, 1);
	boneOriginColor = new Color$1(0, 1, 0, 1);
	attachmentLineColor = new Color$1(0, 0, 1, .5);
	triangleLineColor = new Color$1(1, .64, 0, .5);
	pathColor = new Color$1().setFromString("FF7F00");
	clipColor = new Color$1(.8, 0, 0, 2);
	aabbColor = new Color$1(0, 1, 0, .5);
	drawBones = true;
	drawRegionAttachments = true;
	drawBoundingBoxes = true;
	drawMeshHull = true;
	drawMeshTriangles = true;
	drawPaths = true;
	drawSkeletonXY = false;
	drawClipping = true;
	premultipliedAlpha = false;
	scale = 1;
	boneWidth = 2;
	context;
	bounds = new SkeletonBounds$1();
	temp = new Array();
	vertices = Utils$1.newFloatArray(2048);
	static LIGHT_GRAY = new Color$1(192 / 255, 192 / 255, 192 / 255, 1);
	static GREEN = new Color$1(0, 1, 0, 1);
	constructor(context) {
		this.context = context instanceof ManagedWebGLRenderingContext$1 ? context : new ManagedWebGLRenderingContext$1(context);
	}
	draw(shapes, skeleton, ignoredBones) {
		let skeletonX = skeleton.x;
		let skeletonY = skeleton.y;
		let gl = this.context.gl;
		let srcFunc = this.premultipliedAlpha ? gl.ONE : gl.SRC_ALPHA;
		shapes.setBlendMode(srcFunc, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
		let bones = skeleton.bones;
		if (this.drawBones) {
			shapes.setColor(this.boneLineColor);
			for (let i = 0, n = bones.length; i < n; i++) {
				let bone = bones[i];
				if (ignoredBones && ignoredBones.indexOf(bone.data.name) > -1) continue;
				if (!bone.parent) continue;
				let x = bone.data.length * bone.a + bone.worldX;
				let y = bone.data.length * bone.c + bone.worldY;
				shapes.rectLine(true, bone.worldX, bone.worldY, x, y, this.boneWidth * this.scale);
			}
			if (this.drawSkeletonXY) shapes.x(skeletonX, skeletonY, 4 * this.scale);
		}
		if (this.drawRegionAttachments) {
			shapes.setColor(this.attachmentLineColor);
			let slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				let attachment = slot.getAttachment();
				if (attachment instanceof RegionAttachment$1) {
					let regionAttachment = attachment;
					let vertices = this.vertices;
					regionAttachment.computeWorldVertices(slot, vertices, 0, 2);
					shapes.line(vertices[0], vertices[1], vertices[2], vertices[3]);
					shapes.line(vertices[2], vertices[3], vertices[4], vertices[5]);
					shapes.line(vertices[4], vertices[5], vertices[6], vertices[7]);
					shapes.line(vertices[6], vertices[7], vertices[0], vertices[1]);
				}
			}
		}
		if (this.drawMeshHull || this.drawMeshTriangles) {
			let slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				if (!slot.bone.active) continue;
				let attachment = slot.getAttachment();
				if (!(attachment instanceof MeshAttachment$1)) continue;
				let mesh = attachment;
				let vertices = this.vertices;
				mesh.computeWorldVertices(slot, 0, mesh.worldVerticesLength, vertices, 0, 2);
				let triangles = mesh.triangles;
				let hullLength = mesh.hullLength;
				if (this.drawMeshTriangles) {
					shapes.setColor(this.triangleLineColor);
					for (let ii = 0, nn = triangles.length; ii < nn; ii += 3) {
						let v1 = triangles[ii] * 2, v2 = triangles[ii + 1] * 2, v3 = triangles[ii + 2] * 2;
						shapes.triangle(false, vertices[v1], vertices[v1 + 1], vertices[v2], vertices[v2 + 1], vertices[v3], vertices[v3 + 1]);
					}
				}
				if (this.drawMeshHull && hullLength > 0) {
					shapes.setColor(this.attachmentLineColor);
					hullLength = (hullLength >> 1) * 2;
					let lastX = vertices[hullLength - 2], lastY = vertices[hullLength - 1];
					for (let ii = 0, nn = hullLength; ii < nn; ii += 2) {
						let x = vertices[ii], y = vertices[ii + 1];
						shapes.line(x, y, lastX, lastY);
						lastX = x;
						lastY = y;
					}
				}
			}
		}
		if (this.drawBoundingBoxes) {
			let bounds = this.bounds;
			bounds.update(skeleton, true);
			shapes.setColor(this.aabbColor);
			shapes.rect(false, bounds.minX, bounds.minY, bounds.getWidth(), bounds.getHeight());
			let polygons = bounds.polygons;
			let boxes = bounds.boundingBoxes;
			for (let i = 0, n = polygons.length; i < n; i++) {
				let polygon = polygons[i];
				shapes.setColor(boxes[i].color);
				shapes.polygon(polygon, 0, polygon.length);
			}
		}
		if (this.drawPaths) {
			let slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				if (!slot.bone.active) continue;
				let attachment = slot.getAttachment();
				if (!(attachment instanceof PathAttachment$1)) continue;
				let path = attachment;
				let nn = path.worldVerticesLength;
				let world = this.temp = Utils$1.setArraySize(this.temp, nn, 0);
				path.computeWorldVertices(slot, 0, nn, world, 0, 2);
				let color = this.pathColor;
				let x1 = world[2], y1 = world[3], x2 = 0, y2 = 0;
				if (path.closed) {
					shapes.setColor(color);
					let cx1 = world[0], cy1 = world[1], cx2 = world[nn - 2], cy2 = world[nn - 1];
					x2 = world[nn - 4];
					y2 = world[nn - 3];
					shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, 32);
					shapes.setColor(SkeletonDebugRenderer$1.LIGHT_GRAY);
					shapes.line(x1, y1, cx1, cy1);
					shapes.line(x2, y2, cx2, cy2);
				}
				nn -= 4;
				for (let ii = 4; ii < nn; ii += 6) {
					let cx1 = world[ii], cy1 = world[ii + 1], cx2 = world[ii + 2], cy2 = world[ii + 3];
					x2 = world[ii + 4];
					y2 = world[ii + 5];
					shapes.setColor(color);
					shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, 32);
					shapes.setColor(SkeletonDebugRenderer$1.LIGHT_GRAY);
					shapes.line(x1, y1, cx1, cy1);
					shapes.line(x2, y2, cx2, cy2);
					x1 = x2;
					y1 = y2;
				}
			}
		}
		if (this.drawBones) {
			shapes.setColor(this.boneOriginColor);
			for (let i = 0, n = bones.length; i < n; i++) {
				let bone = bones[i];
				if (ignoredBones && ignoredBones.indexOf(bone.data.name) > -1) continue;
				shapes.circle(true, bone.worldX, bone.worldY, 3 * this.scale, this.boneOriginColor, 8);
			}
		}
		if (this.drawClipping) {
			let slots = skeleton.slots;
			shapes.setColor(this.clipColor);
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				if (!slot.bone.active) continue;
				let attachment = slot.getAttachment();
				if (!(attachment instanceof ClippingAttachment$1)) continue;
				let clip = attachment;
				let nn = clip.worldVerticesLength;
				let world = this.temp = Utils$1.setArraySize(this.temp, nn, 0);
				clip.computeWorldVertices(slot, 0, nn, world, 0, 2);
				for (let i = 0, n = world.length; i < n; i += 2) {
					let x = world[i];
					let y = world[i + 1];
					let x2 = world[(i + 2) % world.length];
					let y2 = world[(i + 3) % world.length];
					shapes.line(x, y, x2, y2);
				}
			}
		}
	}
	dispose() {}
};
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/SkeletonRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Renderable$1 = class {
	vertices;
	numVertices;
	numFloats;
	constructor(vertices, numVertices, numFloats) {
		this.vertices = vertices;
		this.numVertices = numVertices;
		this.numFloats = numFloats;
	}
};
var SkeletonRenderer$1 = class SkeletonRenderer$1 {
	static QUAD_TRIANGLES = [
		0,
		1,
		2,
		2,
		3,
		0
	];
	premultipliedAlpha = false;
	tempColor = new Color$1();
	tempColor2 = new Color$1();
	vertices;
	vertexSize = 8;
	twoColorTint = false;
	renderable = new Renderable$1([], 0, 0);
	clipper = new SkeletonClipping$1();
	temp = new Vector2$1();
	temp2 = new Vector2$1();
	temp3 = new Color$1();
	temp4 = new Color$1();
	constructor(context, twoColorTint = true) {
		this.twoColorTint = twoColorTint;
		if (twoColorTint) this.vertexSize += 4;
		this.vertices = Utils$1.newFloatArray(this.vertexSize * 1024);
	}
	draw(batcher, skeleton, slotRangeStart = -1, slotRangeEnd = -1, transformer = null) {
		let clipper = this.clipper;
		let premultipliedAlpha = this.premultipliedAlpha;
		let twoColorTint = this.twoColorTint;
		let blendMode = null;
		let renderable = this.renderable;
		let uvs;
		let triangles;
		let drawOrder = skeleton.drawOrder;
		let attachmentColor;
		let skeletonColor = skeleton.color;
		let vertexSize = twoColorTint ? 12 : 8;
		let inRange = false;
		if (slotRangeStart == -1) inRange = true;
		for (let i = 0, n = drawOrder.length; i < n; i++) {
			let clippedVertexSize = clipper.isClipping() ? 2 : vertexSize;
			let slot = drawOrder[i];
			if (!slot.bone.active) {
				clipper.clipEndWithSlot(slot);
				continue;
			}
			if (slotRangeStart >= 0 && slotRangeStart == slot.data.index) inRange = true;
			if (!inRange) {
				clipper.clipEndWithSlot(slot);
				continue;
			}
			if (slotRangeEnd >= 0 && slotRangeEnd == slot.data.index) inRange = false;
			let attachment = slot.getAttachment();
			let texture;
			if (attachment instanceof RegionAttachment$1) {
				let region = attachment;
				renderable.vertices = this.vertices;
				renderable.numVertices = 4;
				renderable.numFloats = clippedVertexSize << 2;
				region.computeWorldVertices(slot, renderable.vertices, 0, clippedVertexSize);
				triangles = SkeletonRenderer$1.QUAD_TRIANGLES;
				uvs = region.uvs;
				texture = region.region.texture;
				attachmentColor = region.color;
			} else if (attachment instanceof MeshAttachment$1) {
				let mesh = attachment;
				renderable.vertices = this.vertices;
				renderable.numVertices = mesh.worldVerticesLength >> 1;
				renderable.numFloats = renderable.numVertices * clippedVertexSize;
				if (renderable.numFloats > renderable.vertices.length) renderable.vertices = this.vertices = Utils$1.newFloatArray(renderable.numFloats);
				mesh.computeWorldVertices(slot, 0, mesh.worldVerticesLength, renderable.vertices, 0, clippedVertexSize);
				triangles = mesh.triangles;
				texture = mesh.region.texture;
				uvs = mesh.uvs;
				attachmentColor = mesh.color;
			} else if (attachment instanceof ClippingAttachment$1) {
				let clip = attachment;
				clipper.clipStart(slot, clip);
				continue;
			} else {
				clipper.clipEndWithSlot(slot);
				continue;
			}
			if (texture) {
				let slotColor = slot.color;
				let finalColor = this.tempColor;
				finalColor.r = skeletonColor.r * slotColor.r * attachmentColor.r;
				finalColor.g = skeletonColor.g * slotColor.g * attachmentColor.g;
				finalColor.b = skeletonColor.b * slotColor.b * attachmentColor.b;
				finalColor.a = skeletonColor.a * slotColor.a * attachmentColor.a;
				if (premultipliedAlpha) {
					finalColor.r *= finalColor.a;
					finalColor.g *= finalColor.a;
					finalColor.b *= finalColor.a;
				}
				let darkColor = this.tempColor2;
				if (!slot.darkColor) darkColor.set(0, 0, 0, 1);
				else {
					if (premultipliedAlpha) {
						darkColor.r = slot.darkColor.r * finalColor.a;
						darkColor.g = slot.darkColor.g * finalColor.a;
						darkColor.b = slot.darkColor.b * finalColor.a;
					} else darkColor.setFromColor(slot.darkColor);
					darkColor.a = premultipliedAlpha ? 1 : 0;
				}
				let slotBlendMode = slot.data.blendMode;
				if (slotBlendMode != blendMode) {
					blendMode = slotBlendMode;
					batcher.setBlendMode(blendMode, premultipliedAlpha);
				}
				if (clipper.isClipping()) {
					clipper.clipTriangles(renderable.vertices, renderable.numFloats, triangles, triangles.length, uvs, finalColor, darkColor, twoColorTint);
					let clippedVertices = new Float32Array(clipper.clippedVertices);
					let clippedTriangles = clipper.clippedTriangles;
					if (transformer) transformer(clippedVertices, clippedVertices.length, vertexSize);
					batcher.draw(texture, clippedVertices, clippedTriangles);
				} else {
					let verts = renderable.vertices;
					if (!twoColorTint) for (let v = 2, u = 0, n = renderable.numFloats; v < n; v += vertexSize, u += 2) {
						verts[v] = finalColor.r;
						verts[v + 1] = finalColor.g;
						verts[v + 2] = finalColor.b;
						verts[v + 3] = finalColor.a;
						verts[v + 4] = uvs[u];
						verts[v + 5] = uvs[u + 1];
					}
					else for (let v = 2, u = 0, n = renderable.numFloats; v < n; v += vertexSize, u += 2) {
						verts[v] = finalColor.r;
						verts[v + 1] = finalColor.g;
						verts[v + 2] = finalColor.b;
						verts[v + 3] = finalColor.a;
						verts[v + 4] = uvs[u];
						verts[v + 5] = uvs[u + 1];
						verts[v + 6] = darkColor.r;
						verts[v + 7] = darkColor.g;
						verts[v + 8] = darkColor.b;
						verts[v + 9] = darkColor.a;
					}
					let view = renderable.vertices.subarray(0, renderable.numFloats);
					if (transformer) transformer(renderable.vertices, renderable.numFloats, vertexSize);
					batcher.draw(texture, view, triangles);
				}
			}
			clipper.clipEndWithSlot(slot);
		}
		clipper.clipEnd();
	}
};
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/SceneRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var quad$1 = [
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0
];
var QUAD_TRIANGLES$1 = [
	0,
	1,
	2,
	2,
	3,
	0
];
var WHITE$1 = new Color$1(1, 1, 1, 1);
var SceneRenderer$1 = class {
	context;
	canvas;
	camera;
	batcher;
	twoColorTint = false;
	batcherShader;
	shapes;
	shapesShader;
	activeRenderer = null;
	skeletonRenderer;
	skeletonDebugRenderer;
	constructor(canvas, context, twoColorTint = true) {
		this.canvas = canvas;
		this.context = context instanceof ManagedWebGLRenderingContext$1 ? context : new ManagedWebGLRenderingContext$1(context);
		this.twoColorTint = twoColorTint;
		this.camera = new OrthoCamera$1(canvas.width, canvas.height);
		this.batcherShader = twoColorTint ? Shader$1.newTwoColoredTextured(this.context) : Shader$1.newColoredTextured(this.context);
		this.batcher = new PolygonBatcher$1(this.context, twoColorTint);
		this.shapesShader = Shader$1.newColored(this.context);
		this.shapes = new ShapeRenderer$1(this.context);
		this.skeletonRenderer = new SkeletonRenderer$1(this.context, twoColorTint);
		this.skeletonDebugRenderer = new SkeletonDebugRenderer$1(this.context);
	}
	dispose() {
		this.batcher.dispose();
		this.batcherShader.dispose();
		this.shapes.dispose();
		this.shapesShader.dispose();
		this.skeletonDebugRenderer.dispose();
	}
	begin() {
		this.camera.update();
		this.enableRenderer(this.batcher);
	}
	drawSkeleton(skeleton, premultipliedAlpha = false, slotRangeStart = -1, slotRangeEnd = -1, transform = null) {
		this.enableRenderer(this.batcher);
		this.skeletonRenderer.premultipliedAlpha = premultipliedAlpha;
		this.skeletonRenderer.draw(this.batcher, skeleton, slotRangeStart, slotRangeEnd, transform);
	}
	drawSkeletonDebug(skeleton, premultipliedAlpha = false, ignoredBones) {
		this.enableRenderer(this.shapes);
		this.skeletonDebugRenderer.premultipliedAlpha = premultipliedAlpha;
		this.skeletonDebugRenderer.draw(this.shapes, skeleton, ignoredBones);
	}
	drawTexture(texture, x, y, width, height, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE$1;
		var i = 0;
		quad$1[i++] = x;
		quad$1[i++] = y;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = 0;
		quad$1[i++] = 1;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x + width;
		quad$1[i++] = y;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = 1;
		quad$1[i++] = 1;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x + width;
		quad$1[i++] = y + height;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = 1;
		quad$1[i++] = 0;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x;
		quad$1[i++] = y + height;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = 0;
		quad$1[i++] = 0;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i] = 0;
		}
		this.batcher.draw(texture, quad$1, QUAD_TRIANGLES$1);
	}
	drawTextureUV(texture, x, y, width, height, u, v, u2, v2, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE$1;
		var i = 0;
		quad$1[i++] = x;
		quad$1[i++] = y;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = u;
		quad$1[i++] = v;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x + width;
		quad$1[i++] = y;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = u2;
		quad$1[i++] = v;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x + width;
		quad$1[i++] = y + height;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = u2;
		quad$1[i++] = v2;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x;
		quad$1[i++] = y + height;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = u;
		quad$1[i++] = v2;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i] = 0;
		}
		this.batcher.draw(texture, quad$1, QUAD_TRIANGLES$1);
	}
	drawTextureRotated(texture, x, y, width, height, pivotX, pivotY, angle, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE$1;
		let worldOriginX = x + pivotX;
		let worldOriginY = y + pivotY;
		let fx = -pivotX;
		let fy = -pivotY;
		let fx2 = width - pivotX;
		let fy2 = height - pivotY;
		let p1x = fx;
		let p1y = fy;
		let p2x = fx;
		let p2y = fy2;
		let p3x = fx2;
		let p3y = fy2;
		let p4x = fx2;
		let p4y = fy;
		let x1 = 0;
		let y1 = 0;
		let x2 = 0;
		let y2 = 0;
		let x3 = 0;
		let y3 = 0;
		let x4 = 0;
		let y4 = 0;
		if (angle != 0) {
			let cos = MathUtils$1.cosDeg(angle);
			let sin = MathUtils$1.sinDeg(angle);
			x1 = cos * p1x - sin * p1y;
			y1 = sin * p1x + cos * p1y;
			x4 = cos * p2x - sin * p2y;
			y4 = sin * p2x + cos * p2y;
			x3 = cos * p3x - sin * p3y;
			y3 = sin * p3x + cos * p3y;
			x2 = x3 + (x1 - x4);
			y2 = y3 + (y1 - y4);
		} else {
			x1 = p1x;
			y1 = p1y;
			x4 = p2x;
			y4 = p2y;
			x3 = p3x;
			y3 = p3y;
			x2 = p4x;
			y2 = p4y;
		}
		x1 += worldOriginX;
		y1 += worldOriginY;
		x2 += worldOriginX;
		y2 += worldOriginY;
		x3 += worldOriginX;
		y3 += worldOriginY;
		x4 += worldOriginX;
		y4 += worldOriginY;
		var i = 0;
		quad$1[i++] = x1;
		quad$1[i++] = y1;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = 0;
		quad$1[i++] = 1;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x2;
		quad$1[i++] = y2;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = 1;
		quad$1[i++] = 1;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x3;
		quad$1[i++] = y3;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = 1;
		quad$1[i++] = 0;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x4;
		quad$1[i++] = y4;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = 0;
		quad$1[i++] = 0;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i] = 0;
		}
		this.batcher.draw(texture, quad$1, QUAD_TRIANGLES$1);
	}
	drawRegion(region, x, y, width, height, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE$1;
		var i = 0;
		quad$1[i++] = x;
		quad$1[i++] = y;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = region.u;
		quad$1[i++] = region.v2;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x + width;
		quad$1[i++] = y;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = region.u2;
		quad$1[i++] = region.v2;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x + width;
		quad$1[i++] = y + height;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = region.u2;
		quad$1[i++] = region.v;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
		}
		quad$1[i++] = x;
		quad$1[i++] = y + height;
		quad$1[i++] = color.r;
		quad$1[i++] = color.g;
		quad$1[i++] = color.b;
		quad$1[i++] = color.a;
		quad$1[i++] = region.u;
		quad$1[i++] = region.v;
		if (this.twoColorTint) {
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i++] = 0;
			quad$1[i] = 0;
		}
		this.batcher.draw(region.page.texture, quad$1, QUAD_TRIANGLES$1);
	}
	line(x, y, x2, y2, color, color2) {
		this.enableRenderer(this.shapes);
		this.shapes.line(x, y, x2, y2, color);
	}
	triangle(filled, x, y, x2, y2, x3, y3, color, color2, color3) {
		this.enableRenderer(this.shapes);
		this.shapes.triangle(filled, x, y, x2, y2, x3, y3, color, color2, color3);
	}
	quad(filled, x, y, x2, y2, x3, y3, x4, y4, color, color2, color3, color4) {
		this.enableRenderer(this.shapes);
		this.shapes.quad(filled, x, y, x2, y2, x3, y3, x4, y4, color, color2, color3, color4);
	}
	rect(filled, x, y, width, height, color) {
		this.enableRenderer(this.shapes);
		this.shapes.rect(filled, x, y, width, height, color);
	}
	rectLine(filled, x1, y1, x2, y2, width, color) {
		this.enableRenderer(this.shapes);
		this.shapes.rectLine(filled, x1, y1, x2, y2, width, color);
	}
	polygon(polygonVertices, offset, count, color) {
		this.enableRenderer(this.shapes);
		this.shapes.polygon(polygonVertices, offset, count, color);
	}
	circle(filled, x, y, radius, color, segments = 0) {
		this.enableRenderer(this.shapes);
		this.shapes.circle(filled, x, y, radius, color, segments);
	}
	curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color) {
		this.enableRenderer(this.shapes);
		this.shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color);
	}
	end() {
		if (this.activeRenderer === this.batcher) this.batcher.end();
		else if (this.activeRenderer === this.shapes) this.shapes.end();
		this.activeRenderer = null;
	}
	resize(resizeMode) {
		let canvas = this.canvas;
		var dpr = window.devicePixelRatio || 1;
		var w = Math.round(canvas.clientWidth * dpr);
		var h = Math.round(canvas.clientHeight * dpr);
		if (canvas.width != w || canvas.height != h) {
			canvas.width = w;
			canvas.height = h;
		}
		this.context.gl.viewport(0, 0, canvas.width, canvas.height);
		if (resizeMode === ResizeMode$1.Expand) this.camera.setViewport(w, h);
		else if (resizeMode === ResizeMode$1.Fit) {
			let sourceWidth = canvas.width, sourceHeight = canvas.height;
			let targetWidth = this.camera.viewportWidth, targetHeight = this.camera.viewportHeight;
			let scale = targetHeight / targetWidth < sourceHeight / sourceWidth ? targetWidth / sourceWidth : targetHeight / sourceHeight;
			this.camera.setViewport(sourceWidth * scale, sourceHeight * scale);
		}
		this.camera.update();
	}
	enableRenderer(renderer) {
		if (this.activeRenderer === renderer) return;
		this.end();
		if (renderer instanceof PolygonBatcher$1) {
			this.batcherShader.bind();
			this.batcherShader.setUniform4x4f(Shader$1.MVP_MATRIX, this.camera.projectionView.values);
			this.batcherShader.setUniformi("u_texture", 0);
			this.batcher.begin(this.batcherShader);
			this.activeRenderer = this.batcher;
		} else if (renderer instanceof ShapeRenderer$1) {
			this.shapesShader.bind();
			this.shapesShader.setUniform4x4f(Shader$1.MVP_MATRIX, this.camera.projectionView.values);
			this.shapes.begin(this.shapesShader);
			this.activeRenderer = this.shapes;
		} else this.activeRenderer = this.skeletonDebugRenderer;
	}
};
var ResizeMode$1;
(function(ResizeMode) {
	ResizeMode[ResizeMode["Stretch"] = 0] = "Stretch";
	ResizeMode[ResizeMode["Expand"] = 1] = "Expand";
	ResizeMode[ResizeMode["Fit"] = 2] = "Fit";
})(ResizeMode$1 || (ResizeMode$1 = {}));
//#endregion
//#region node_modules/spine-player-41/node_modules/@esotericsoftware/spine-webgl/dist/LoadingScreen.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated July 28, 2023. Replaces all prior versions.
*
* Copyright (c) 2013-2023, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software or
* otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE
* SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var spinnerImage$1;
var logoImage$1;
var loaded$1 = 0;
var FADE_IN$1 = 1;
var FADE_OUT$1 = 1;
var logoWidth$1 = 165;
var logoHeight$1 = 108;
var spinnerSize$1 = 163;
var LoadingScreen$1 = class {
	renderer;
	logo = null;
	spinner = null;
	angle = 0;
	fadeOut = 0;
	fadeIn = 0;
	timeKeeper = new TimeKeeper$1();
	backgroundColor = new Color$1(.135, .135, .135, 1);
	tempColor = new Color$1();
	constructor(renderer) {
		this.renderer = renderer;
		this.timeKeeper.maxDelta = 9;
		if (!logoImage$1) {
			let isSafari = navigator.userAgent.indexOf("Safari") > -1;
			let onload = () => loaded$1++;
			logoImage$1 = new Image();
			logoImage$1.src = SPINE_LOGO_DATA$1;
			if (!isSafari) logoImage$1.crossOrigin = "anonymous";
			logoImage$1.onload = onload;
			spinnerImage$1 = new Image();
			spinnerImage$1.src = SPINNER_DATA$1;
			if (!isSafari) spinnerImage$1.crossOrigin = "anonymous";
			spinnerImage$1.onload = onload;
		}
	}
	dispose() {
		this.logo?.dispose();
		this.spinner?.dispose();
	}
	draw(complete = false) {
		if (loaded$1 < 2 || complete && this.fadeOut > FADE_OUT$1) return;
		this.timeKeeper.update();
		let a = Math.abs(Math.sin(this.timeKeeper.totalTime + .25));
		this.angle -= this.timeKeeper.delta * 200 * (1 + 1.5 * Math.pow(a, 5));
		let tempColor = this.tempColor;
		let renderer = this.renderer;
		let canvas = renderer.canvas;
		let gl = renderer.context.gl;
		renderer.resize(ResizeMode$1.Expand);
		renderer.camera.position.set(canvas.width / 2, canvas.height / 2, 0);
		renderer.batcher.setBlendMode(BlendMode$1.Normal, true);
		if (complete) {
			this.fadeOut += this.timeKeeper.delta * (this.timeKeeper.totalTime < 1 ? 2 : 1);
			if (this.fadeOut > FADE_OUT$1) return;
			tempColor.setFromColor(this.backgroundColor);
			a = 1 - this.fadeOut / FADE_OUT$1;
			a = 1 - (a - 1) * (a - 1);
			tempColor.a *= a;
			if (tempColor.a > 0) {
				renderer.camera.zoom = 1;
				renderer.begin();
				renderer.quad(true, 0, 0, canvas.width, 0, canvas.width, canvas.height, 0, canvas.height, tempColor, tempColor, tempColor, tempColor);
				renderer.end();
			}
		} else {
			this.fadeIn += this.timeKeeper.delta;
			if (this.backgroundColor.a > 0) {
				gl.clearColor(this.backgroundColor.r, this.backgroundColor.g, this.backgroundColor.b, this.backgroundColor.a);
				gl.clear(gl.COLOR_BUFFER_BIT);
			}
			a = 1;
		}
		a *= Math.min(this.fadeIn / FADE_IN$1, 1);
		tempColor.set(a, a, a, a);
		if (!this.logo) {
			this.logo = new GLTexture$1(renderer.context, logoImage$1);
			this.spinner = new GLTexture$1(renderer.context, spinnerImage$1);
		}
		renderer.camera.zoom = Math.max(1, spinnerSize$1 / canvas.height);
		renderer.begin();
		renderer.drawTexture(this.logo, (canvas.width - logoWidth$1) / 2, (canvas.height - logoHeight$1) / 2, logoWidth$1, logoHeight$1, tempColor);
		if (this.spinner) renderer.drawTextureRotated(this.spinner, (canvas.width - spinnerSize$1) / 2, (canvas.height - spinnerSize$1) / 2, spinnerSize$1, spinnerSize$1, spinnerSize$1 / 2, spinnerSize$1 / 2, this.angle, tempColor);
		renderer.end();
	}
};
var SPINNER_DATA$1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKMAAACjCAYAAADmbK6AAAALKElEQVR42u2de2iW5R/GPzuqcwfnnKfNmafl5tTNHWzqNi3DEMQykcAoJSsySkspjSIk0iD/07Kf4R+FnVBDUTshZGpWUEJaaiWFgZlUFmXmIe3HNXthyebeZ77P9H13ffBG8Y8H7ut7vff93N/7fu4vGGPiFZiez/Qtw9lytJajfzfw9z/j+efPOv7cV8W+lUNY2a8T/ayTCRsWFLJA5rtUO1LLkV5p9LJeJizQiHeqnlOtmVFtdTGrrZkJCxYXsTgaI6r9MY4/UpNItW4mFDaXsTlaM6qVZlBq3UwofFrJp0HMWJ9DvXUzobCznJ1BzFjWlTLrZkJh/TDWBzFjTgo51s2EgnKI0Rrx+FiOWzNzVaym91Syx5qZsGBWb2ZFa0ZN6dbMhAWTcpkUrRmXD2K5NTNhgVbH0Zpxbl/mWjMTFvRIo0e0ZpzcncnWzISKtvmiMWNRJ4qslwmVXRXsas2Ix8ZwzFqZsGFREYtaM+Oaa1ljrUzYkJ9G/ok6TlzKjJWZVFor0y7c1Zu7WjLiqiGsskamXdHopyT4vALmzS9k/t19uHtKHlOSIMn6xAtARjIZ1sFcUSZ0Y4La+G6M18hS2IlCn4a+WoC0JNL0d/dUupdnUj40g6EJ2VEdMnhrOG/p5f/jUXz8SgmvaGU6KpNRNsLVQV0OdXf24s63h/P2gWoOrBjMCr2GJFQnnxnIM3q5P1PPmaYv+4ev4/C6UtbpV2gzXCkgL5W8Bwt48OIc6ul6Tp+s4+SyASxLiI4+PYCn1bHzDZxvaQW6vZzto7MYnQIpNkf7kp5EuozYUroqEjcNKHHd0Tl9mBPN1pk+hFeieGBnBtog7UXjsj9pWg+m6duecw2cay1OC/uxMC47KmP9OIYfoz1YoC20J/rzRG4quTZK2EAyJGs20qwUbYw0aNRmUxtvfUW/uEtNzc1NB1/X8LVyd15hh82F43AvD+VlXcsSJEZa1CQ3ejleAO7oxR3RDP0XN91X4+NXYb8nkv7UNTwV7e0YTdu7I3g33t7tuaEbNwSZpps2fSyvs4M2Tjhot+jb0Xzbltj8r5j/xVt/6Z1Ob93U1ZYO691EhhzchcHeXosVjcNZysyezLw4xRZt05R+fTeuj8vOj+zKyG0j2aZcVVs6v+QalnjrMFZASQYl2nBoSyz06e3j/Xk8rgWYmMvEICu2pm1HOTuc7okV8FgRj0XukwzanhvCc/F+72TjoQjdObN1OFuDLmh0xP+WHtxiI10ukJlCprb4guiv1fP+avZrS1C7NAkliHZjDtZwMMgqbukAltpMlwuMy2FcEBPqvfLLar5Uqi0hBdEwryy+Mv5n6zkbjTBa+dlMlwvUZFETZKGiFM7tvbhdJ3gSVRO0wzIjnxmvl/J6a6JsGMYGrahtpssFeqbR841S3mhN80OjOaSDEdqd6SjaMKgzgzRK7q1ib3PT9sYyNo7JZoyNFNvRcVMZmy7WOvIuryv/Zvdmdt90+nY0bRp3AvROohFwdwW7dTG7RFlbwlqdrbOBYg005NAQmZU0HWt1rXMBH1Xw0dQ8pmqzoaPmdhun7bHZjNVe9qP9eFQfO1VkUmHjhAVUZ1GtnKFSbjrkrPfy4i4UW5t/6ZxM54J0CqxFe81KpGsQyE4h23oYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjLna+bdOy+IiFquIpGq16Pb79cNYv3IIK/X/ugx+Ui6TVKvYVU9Nc8gX8od8Ir/IN/KPfCQ/yVfyl/6/pfJvLChkQdD6wyqntquCXYuKWJSfRr6D0dEAxV3xlw/khyD+kd/ku/88cHo+09tS3LBpO1HHCVUqcIA6CqB4K+6X6x35L/JM2loXurlWmUmlA5XogOIcK8/If5HncrSWo7F6cKIWPjT/RXGOlWfkv8hzaWsN4uaaysE6WIkOKM6x8oz8F3kusXqo2vxC5jtYiQ4ozrH0TeS5qIZcrB7qkrwdA8U5Vp6R/yLPZV8V+2L14Cl5THGwEh1QnGPlGfkv8lyUlIzFQ1cNYVVHrcjZ0VCcFe9Y+Eb+izy3ceclUl43aFN52DXXssYpnY6a4qFS8ZcP2uIf+e7inRh6pdFrdTGrm8uiHx/L8T2V7NGWzvJBLJ/bl7mTuzO5qBNFDoiJID/IF/KHfCK/yDfyT3O7d/KbfNfS80hNIrU0g9L6HOq1x5iTQo6FNpeLfCQ/yVfyl3xmXYwxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHNk9z4JwJ0SqKTdQkbyEwhU393T6V7zzR6pieR3tE1ITeVXImhe6BXDGZFdRbVeank2TBhcaEMr0rwbixj49IBLL2/L/ffmMuNHfqO9tFZjJYBd1ewO3Lx+IcVfKhqna5nHZYR6XFPH+5R3eeI5t9fx/fvjeC9Jdew5OKZKqFR/RDVKL6vL/f9PJafmyvHsL+a/ff24V6NmjZQbGchVbY6UM2BluqHv1rCqzVZ1KQlkZboepCdQvacPsz5bjTfXao+yMEaDt7Wk9tSIMVGig3TejCtJSM2bSpkPjWPqd1S6Zao+lORSYWmgkOjORRNwZqd5ezMSiHLRooNr5XwWjS6/1XHX9vL2T67N7M1iyXa9JCrYjVrS1gbpJyw6hBfsmiNCYT0P9/A+Wj1/6qGr5YNYFlJBiWJogEzezLz/ZG8/9s4fgtSyuvNYbyp1IONFBtu7sHNv4/j9yAxUHWrdaWsG9+N8XHd+YxkMpSy+aySz841cC5oXbmHCnnI74yxAgZ3YbDeB4PEQCOpBpFNZWwa2ZWRcdnxLsl00crtRB0n2lLg8JNRfDKoM4NsolgBSmw/UMADba1+qpmqfyf6x1u/0a/og3I+aEunP6/i86osqmygcGarF4p54dex/Bo0LqfqOfVwIQ/HW5/RSkwV1oN2WLlHTc82TljAwM4M1O5LWwYKZTjibYXNS0N5KcjKTe10PadfLObFuJwK4ozp+UzXDBTUjL+M5ZcBnRkQV53dMIwNQTu6bSTbVEzbi5awuVByd2E/FgaN0Tc1fKOzBHHV2aAdVSdv6s5NNkp7cSH/++xAng2yyHx+CM/H21YhfdPp+0U1X0TbSZnXx8faG9Aop0MS0cToh1p+iLcpOkLj9t/JOk5eqoPHxnDsyf486an5yqCDK7XZ1O4oZ4dWyy3FSXHUAYq47uyYbMZoGmhpG3DlEFb6uNiVBhpyaHhnBO8oJmfqOROJjzIiP43hJ8UxITqqX56S2Hur2KsOnq3nrE6PPNKPRwrSKbAZrjTQNZmuE7oxYXMZmxWbw9dxWFu4W4ezVedOE6qzI7oyYkY+M7TPeWsPbk2UX1qioSN+E3OZqOR2cReKE+qQRFN0Pi7y73g/UawU1KzezJpXwLz5hczX1ueUPKYkNb6GJQZ+j7/aAfRZREsv+quGsMoamXZBW2Gt5eU0alorEzYsKmJRa/m4NdeyxlqZsCGa84DKnVorEzboC7podis69DfIJmwufHMc7famvvmxZiYsKOtKWbRm1OcW1syEBboSJFozLh/EcmtmwgIluaM14/phrLdmJixYXMTiaM24p5I91syEBTphFOR7Y2tmwgJNvUFOr+tov3UzoaAv44KYUatv62ZCoemdhtG0+hzqrZsJBR08DWLG0gxKrZu50qvpxos3U5NItW4mFPp1ot+lPlpq2lYXs9qamVBZUMiC1ox4pJYjvlfStAu6GmTLcLboMtPIV4/6im5fFfuUi9QIap2MiWP+D96R1vPmsD/fAAAAAElFTkSuQmCC";
var SPINE_LOGO_DATA$1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKUAAABsCAYAAAALzHKmAAAQ7klEQVR42u3da4xdVRUA4D0zd2Y6nZY59DVtZ1puS9+lzC0YAi2UQ8AAQczFpPgA9VIeIQbirRqJ0cBUBVGjDr/QCKSNRSMmpuODxAdxqhgwxkhFjf6Sxh/+UUNVNGJCzR7uTvas7LXX2q9zzp3em6y0gTN3Zu75utZe5+yztxC9V+/Ve5X9En1Vjd7J6SFbLNF7naPw+l2jh7YHMBWssqMHtlsRdim4qsLtIawaPiHEQOLoNrA9iIkQDnRrVA1qD2LZ8ISoxYqKo13sQAtBWBayQWZUAXGRQM9JjCngDVY0UqJNDbQrMcaGmArdUKpIjbYiQLsCZCyIMQBy8QwnilR4Q5AuCpxFYvRFmBLbEiwKwpsSaWycVQGZBKMrwBjA9BhxDe57u2L2hOoKNCbOrgAZitEVYUxoKSMErQvSxYIzCkguRg5EF4AUhqUlhy/YUKSxcRaKsioYOQhD4I0yYxkR3PcJBcuFysmgsXAWBTMJyBCMIQh9kGGxXIXvexCQXbHGAMrBWTbM2CCpMSMLIxehC77lSJwXGth7M0FzoVJIXXDWQnGmhOkL0ic7YhhtWdGGkAuPAjUWGoF4faCmwBkbZmyUqUCyMqMLRA4+E6IsdTjidUHKBYrh9CnpRcH0ypKxsyOGEYNIIeTCOz91OIJ1QYoB5eAMyZo+MFNnyVTZ0YiRC9EGEMOyAgshxErHsL2XK1gOUgwohtM1a5YNM7Rsu4K0ZkcbRm4mpPBRwFZ5hg9eCqkrUB+csWGGogzNkqEgrdnRhpGLkINudaLgwvVB6oqzCjCTZElb2Y4B0gUjBtEG0ARnDRLjjoG9DwcshtQGlIPTljVjwUySLWNkyRCQVHa0ZUUTRAwgF91a33BEy0VKAcVwwqwZC2bqbOlUurllOxQkJzNyINoAYqjWhYYjWg5SCiiG05Q1U8FMjTIoS8YE6YORi1BHtJ4KIcQEEtTXUWAxpK44YVlPBdO1jCdFWTZIE8bVGEYMIRPcZGBw4HKQcoBiOE1ZMzbMgVQwU6JMAdKEEcuIJogUvg1YCCE2gsCO42DlIIVAKZwpYJaSLVNnSU6XjYHUmxhTmXaFaMO3EYkLqMC+FsLlIoVAKZzMrEnBhJeLfLNlKMrYWRIDCbOkFSSVHbHM6AKRC6/ODUewNqQ+OLlZkxpjUmV8MBbMUJSxyzY3Q1IgTRgxiBRCHdem0KDAUkBh9sRwwjEnAXMMgTnKhFlUtiwkS5rGka4g9SaGgxFmRC7AzTCEEBcyA36dDSsXqAtOLkysjGMwY5XxVChjZ0kuSCo7YlkRQsQQYtDEFsegsLoCxUp7Kpgps2UslFGzJGccSYHUmxhOZqwzEZqAbfUMCisHKIZzgsCpl3MTzMwTpi1bYp2477gyFKUxS7qWbdjY2EBS2dGE0QQRA7gNCyHEdhjE8RhUDlBT9tzgmjWZMFNlSy+Urk1OzCyJlW0XkK4YOQh1cDtcgwBrQmoDWkdgboBZE8mYsJSHlnFbJ+5bwmOPJ7lZkirbC8aRsMvmgtTHjBhGE0QbwJ2egUE1ITVlUC5OmDVdYNrKuN70xM6WoShjlW4464dbtiFIWK6x7GjESEHUUe0iYncnbMdQSE0Z1ITTNOb0hRmjjLtmS9dmJ2rp1jtuKktyyrb6YLEMCUHq2dGG0QQRQ7f72kzc+cJecerne8Wvv7JNPHPvenEkz8Sh3UtFc92QyGt9Yko/HgOLAIUZlItTz5ouMF3KuE+2jFLCQ1D6lm6fLMkBacuOJowYRBUXyfjuHjF3NhdnsfjvAfH6E9vFt9XxKgikEKgJZyyYalzOLeMu2bLbULI6bh+QGwmQ+rgRlumdGEQAao+K56bEL2woVUwOiev0r8OAUjiJrMmFCbvykGxZRAmPitK1dHM7bohyMsuyi/I8f0+e57fJYIKEZXpXo9E4mOf5XTKyLLvCBLETF8uY2SKepkC+dpX4T02Ivepr4HvZcOZ5fmee54fyPL+DmTUhzAs6n4n8bN5dr9f3YdkSg8nsxG0lPBVKVpNjG0/aGhzfLDmRZdnumZmZp8+c+cdZPV555fSr7Xb7s0jJ3i5Pcue4MxKkPPkvvXTqz/B92u32l0wYOzG1fkhcd/py8Rcbyq/vFM/KY1WA95h/3zzP71bfU6JsNpsfgj+P/FlbrdaDGExYyuXvLz8H+DudODH700ajcSM3W6Yu4alQ1spCOTd38jcKocTZbh9+9NixY99XJ8AEUkcpo9W64yH197m5k7+bnZ19QT+J09NHntQhwji/Jg58qi6++ofLxJ8gSFneVw2Ka4QQDfh1Ok4dZavVmtZ/nrm5k7/Vf55O1tRhboUw5+ZOvqyOl5+R/FyOHj32PYVU/tloNG5IXcKrhJIzngwp3fNjomazea/64BuNxts646f50lWv169utw9/DmtqdJQyZFaSJVuV6nq9fqMEof5/vV6/CYBqgJDlee+yAbF/+4i4ZWqZeNfaIfHWzn+Hx0KcEuU9+s8jv3ej0bhVlXOZydX/k0iRMeb8P0D5e6tj8zy/Xb9UJIc56h/yqVOnXul8lmuZ2bJslKmbHG7XrbpCmCXFRLvdfqQD6jTS3Jiy5I4OykM6ADV+1Eu1DmV6evopBORexzDi1L+X/HnGxsb2w3Hm9PSRJ9QxWPOTZdmlKht2hi+w6dkox5bqffI8fye3hDteGqKaHVsHXihKl0tB+h0cY+lute54AGRKDCW89LNTRynHb7ChUWVVjetOnJh9EYBUyPZeNCoOtsbFQwdXi4/esELcd+tq8cCHJ8UXp+viy9efLz7AgamjlKXc1AA1m83DoIRDlFubzeb96hhZLVTlgJ24gttutx+ONa50bHZKRenaeTs1OfpAfnr6yOOdE7EZdNwmlKocntXLNkA5JTGq47Ds+Lf94lWsyfnXleLfnIwJUN4DOnNYwuUxh2A3Ln9XULrfK8t3J27Tu3BVwiOjXJqoAy8UZej1yclGo3GTLN+gu3w+z/P3YaWbQqk3Ne12e4ZC+c8rxWsYytcPiP9RpZxCqWDKnxOiBNlyAUpOnGsoh4tA2Rm8X9xqtT6md5wyZmYe+0YRKL+1S/wYQ3n8zctBl5SBUv5djivfjMOPduIzcizeiYfr9foVvUwZG+XCuzibZKnSceZ5/v4QlKp8y7ElhnJlTeTP7BI/kllRYfzrfvHqFy4UX1vaL/aVlSmROzwbwdS29T2UcEwZF+V8ozM2lu1VY812u/15akypGh3TmFJesJbHHD167IdUxz3YJy5bNySuX1mbvy55CbMLtzU6tjGlsdFptVqfUMc0Go23F4wy1l2dSnbfvpMwVPe9WWVLDsrOJaF9MFu2Wq1PqmNkGce67xiXhTjdNwdlvV6/BgxfbPfBfVCetxi6b9/rlCup65QzM48dl2OjLMv26CibzeZ96sTIzEFdpwQXz9U1yrtVlpR/Zll2Fec65Y6l4pbbx8XHH9kknvzJlPjlHy8Tp29eKT5ou0aJoIT3w3dBlLDzVpfAJEZ1XOdaJZxnOSlvPMjPzxFljIvng914RwebsjYO7uhMyHu46sOfnf3Oz2TXDW6vvYxdFoIXz3Wc8J5zs9n8iOn2IrxTc2BM3Glqdp7dI553uaOjxrhwcob+MyuUpjs6WZZdon8OcigjPx8V+u+GTWFTSWEx3WYcdJ225jNDSE4q0GHCzlueHOyujn6bUWYgeb9ZZUaQPe+GzQ+Gc8+oOGhC+c1d4gfI16n3XDAhQ7+9qE9l01E2Go132GYKyXE1NiFDTcpoNpv3LOYJGWXNErJNW9sEp63p2RKiVPMn1bS1DgxsyhoGdGpmizj+xtXiDYnx7/vFmce3iWdW1cTVGEY4hQ2ZW0nNq8Qm/M6XbXm3S100lwGedFybuvNOibLI+ZS2ceU4eAxiEuvCkfmU8ycToDxETe6FgCBQHeqyAbFvfEhcO7BwDuXFCEbTZF840XeHK0jYcbs2OIGle0mVJ/mmnClEPQqxyTY5I8/zFhif7fSZee4bnrPOU4AssnRXHaVTCTd14dRDY3UbTIiSeFhsN/aMjgnqthFx880rxX3yATL5p3y4LPXzOaBkUyBjZMlYpbtQlIOBD475ZEusjMNSvkXe6VEoJVDkeZ2dzIfIFsRzU+JF2OyM9M9fTC/6SUYOyFQPjQ2nWiUjxnPfw5EeHqMWIqAeIFsAU847lJM2JM6xsewt1OIDLs99P7ZFHNdB/upS8XtPiD7PfLuCXJNolYyyFiNI/Zit65ItrOVafFbHcFohY7hPTN21Tjz4uc3iqfsnxKdX1MTl1OoYRFaMsToGB6Trw2JFP/OdZC2hJZ7ZkrMoAbbSGmelDJ91hFKuJeS7jlBMkJnrAqqJlgMUZS/dArPlGHNdSg5M3xXXtvquuEatvIYtDRhpxbUJuIgqsU5lGWtUploK0KuEU9mSW8YpmFQ556xNuYW7NiW13B+FkMiKHIy+C6eGgBxJvMR0oSv5hi6+z4HJyZoU0M2RVvDlrOQbcxVfX5AhZbuqy0v7ZstYMLHlAVlLTF9ALLbvu9Y5Zylpn/XOsd0ibIvxr2KCLHpp6SCUIdnSZSF+WzfOhem6GD+1KwR3Z4jNjrtDpNoZwmWd8yrupZN6Hx3fbMmFSe0Swdq2ZIPjxk1112Duo8OBGLrBkw/IoncdK2XHsdC9dHz204m50xh3tzFq1zFqtzHXrfCw7OgDsqyNnZLszVijsmXgrmNcmGtS78lIoMX2aJz03fKO2sDJddPQSCDPiQ1DfWBycY6XtXstc2PQKuxgG2McmXTPb9/9vmuJYXKyJrWjbeg+3xPM4O73nWqvbyw7xgZZSJbEUBa157cNJjdr2vb+5iA1YV3HxYscj30PDCEHIgcjtfm8K8hSsmRotkwFk5s1TTghUAopB6xrjHMBBkI0YYTZ0dZlxwLpkiWDULpmy5gwqayZgZNkA7oKQQCxctByYg0XIIEQQuRitGVHblMTA2ShKGPDpC6wu+DEgJqg2rDGDBtAF4Q6RAojp1xXGmSMbImVcR+YWNY04eQCtUG1ofUJ2/uvcETIgUhhdAE5GAlkKShjwHTNmhhODKgJqQ2sC14uOgyfD0IbRF+MlQaZAiZWyn2yJsTJATqGnHQO2Jhh+xlsACFCG0QbRtdyzQFZCZSxYPpmTS7Q5cjJHYNBYIkZpu99HoUQ/o4QIYSIZUZfjJ4ZMjZI32wZBDMU5yhy8pZTULl4XYP5fagMyEVoy4oupTpGduwnkloSlKEwY+AcQU4MhRTD6ovXBRwFzwWgCSEF0QVjJUGmgEllTS5OLlCIlIN1mS9mx/cZ5eLDALpCTI2RAhkTZQqYoTgpoCPECbaBHQ2ETL3PUl98ECAXYijG0OyYAmQoTG7W5ODkAF1CnVgm2JQx4okPA+gCMTbGskBGgRmaOblAh5GTORIrfKFx4VH4EIAxIXIxlg2SBbMvECY3e7oApbDaIgQu5/2HmeEKEINYiwSRi7EQkLFgumZOCuggctKGI4ULZN/vMeSLj0AYMytWEqMLzFg4fYDaoKaC6wvOFR4FkIPQFaILxrJAOsHsc/zlfYDWXE8qF22s8Pz5KHxcgEVALBtjJXBSSEOwFhk1Zgy4hitCT4hVw+gFs8/zwxqIBbUgyK7fcyA0PD9XX4iVxhiC0xdof6STWCsoBmKF7+cVCWFXQYyBMxRpf+STX1b0x45AhN0OMSrOGEirhrY/dfQAdjvS7oy+WCF6r1RIFxXWvlTRg1YVqFWBmxZbD99ig9pt0YPQw9rD1nstVri9V+/Ve3XrS/wfim4P5fIFxLoAAAAASUVORK5CYII=";
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/WebGL.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var ManagedWebGLRenderingContext = class {
	canvas;
	gl;
	restorables = [];
	constructor(canvasOrContext, contextConfig = { alpha: true }) {
		if (!(canvasOrContext instanceof WebGLRenderingContext || typeof WebGL2RenderingContext !== "undefined" && canvasOrContext instanceof WebGL2RenderingContext)) {
			const canvas = canvasOrContext;
			this.gl = canvas.getContext("webgl2", contextConfig) || canvas.getContext("webgl", contextConfig);
			this.canvas = canvas;
			canvas.addEventListener("webglcontextlost", this.contextLostHandler);
			canvas.addEventListener("webglcontextrestored", this.contextRestoredHandler);
		} else {
			this.gl = canvasOrContext;
			this.canvas = this.gl.canvas;
		}
	}
	contextLostHandler = (e) => {
		if (e) e.preventDefault();
	};
	contextRestoredHandler = () => {
		for (let i = 0, n = this.restorables.length; i < n; i++) this.restorables[i].restore();
	};
	dispose() {
		this.canvas.removeEventListener("webglcontextlost", this.contextLostHandler);
		this.canvas.removeEventListener("webglcontextrestored", this.contextRestoredHandler);
	}
	addRestorable(restorable) {
		this.restorables.push(restorable);
	}
	removeRestorable(restorable) {
		const index = this.restorables.indexOf(restorable);
		if (index > -1) this.restorables.splice(index, 1);
	}
};
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/GLTexture.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var GLTexture = class GLTexture extends Texture$2 {
	context;
	texture = null;
	boundUnit = 0;
	useMipMaps = false;
	static DISABLE_UNPACK_PREMULTIPLIED_ALPHA_WEBGL = false;
	constructor(context, image, useMipMaps = false) {
		super(image);
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		this.useMipMaps = useMipMaps;
		this.restore();
		this.context.addRestorable(this);
	}
	setFilters(minFilter, magFilter) {
		let gl = this.context.gl;
		this.bind();
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, minFilter);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, GLTexture.validateMagFilter(magFilter));
		this.useMipMaps = GLTexture.usesMipMaps(minFilter);
		if (this.useMipMaps) gl.generateMipmap(gl.TEXTURE_2D);
	}
	static validateMagFilter(magFilter) {
		switch (magFilter) {
			case TextureFilter$2.MipMapLinearLinear:
			case TextureFilter$2.MipMapLinearNearest:
			case TextureFilter$2.MipMapNearestLinear:
			case TextureFilter$2.MipMapNearestNearest: return TextureFilter$2.Linear;
			default: return magFilter;
		}
	}
	static usesMipMaps(filter) {
		switch (filter) {
			case TextureFilter$2.MipMapLinearLinear:
			case TextureFilter$2.MipMapLinearNearest:
			case TextureFilter$2.MipMapNearestLinear:
			case TextureFilter$2.MipMapNearestNearest: return true;
			default: return false;
		}
	}
	setWraps(uWrap, vWrap) {
		let gl = this.context.gl;
		this.bind();
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, uWrap);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, vWrap);
	}
	update(useMipMaps) {
		let gl = this.context.gl;
		if (!this.texture) this.texture = this.context.gl.createTexture();
		this.bind();
		if (GLTexture.DISABLE_UNPACK_PREMULTIPLIED_ALPHA_WEBGL) gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this._image);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, useMipMaps ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
		if (useMipMaps) gl.generateMipmap(gl.TEXTURE_2D);
	}
	restore() {
		this.texture = null;
		this.update(this.useMipMaps);
	}
	bind(unit = 0) {
		let gl = this.context.gl;
		this.boundUnit = unit;
		gl.activeTexture(gl.TEXTURE0 + unit);
		gl.bindTexture(gl.TEXTURE_2D, this.texture);
	}
	unbind() {
		let gl = this.context.gl;
		gl.activeTexture(gl.TEXTURE0 + this.boundUnit);
		gl.bindTexture(gl.TEXTURE_2D, null);
	}
	dispose() {
		this.context.removeRestorable(this);
		this.context.gl.deleteTexture(this.texture);
	}
};
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/AssetManager.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var AssetManager = class extends AssetManagerBase$2 {
	constructor(context, pathPrefix = "", downloader = new Downloader$1()) {
		super((image) => {
			return new GLTexture(context, image);
		}, pathPrefix, downloader);
	}
};
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/Vector3.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Vector3 = class {
	x = 0;
	y = 0;
	z = 0;
	constructor(x = 0, y = 0, z = 0) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	setFrom(v) {
		this.x = v.x;
		this.y = v.y;
		this.z = v.z;
		return this;
	}
	set(x, y, z) {
		this.x = x;
		this.y = y;
		this.z = z;
		return this;
	}
	add(v) {
		this.x += v.x;
		this.y += v.y;
		this.z += v.z;
		return this;
	}
	sub(v) {
		this.x -= v.x;
		this.y -= v.y;
		this.z -= v.z;
		return this;
	}
	scale(s) {
		this.x *= s;
		this.y *= s;
		this.z *= s;
		return this;
	}
	normalize() {
		let len = this.length();
		if (len == 0) return this;
		len = 1 / len;
		this.x *= len;
		this.y *= len;
		this.z *= len;
		return this;
	}
	cross(v) {
		return this.set(this.y * v.z - this.z * v.y, this.z * v.x - this.x * v.z, this.x * v.y - this.y * v.x);
	}
	multiply(matrix) {
		let l_mat = matrix.values;
		return this.set(this.x * l_mat[0] + this.y * l_mat[4] + this.z * l_mat[8] + l_mat[12], this.x * l_mat[1] + this.y * l_mat[5] + this.z * l_mat[9] + l_mat[13], this.x * l_mat[2] + this.y * l_mat[6] + this.z * l_mat[10] + l_mat[14]);
	}
	project(matrix) {
		let l_mat = matrix.values;
		let l_w = 1 / (this.x * l_mat[3] + this.y * l_mat[7] + this.z * l_mat[11] + l_mat[15]);
		return this.set((this.x * l_mat[0] + this.y * l_mat[4] + this.z * l_mat[8] + l_mat[12]) * l_w, (this.x * l_mat[1] + this.y * l_mat[5] + this.z * l_mat[9] + l_mat[13]) * l_w, (this.x * l_mat[2] + this.y * l_mat[6] + this.z * l_mat[10] + l_mat[14]) * l_w);
	}
	dot(v) {
		return this.x * v.x + this.y * v.y + this.z * v.z;
	}
	length() {
		return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
	}
	distance(v) {
		let a = v.x - this.x;
		let b = v.y - this.y;
		let c = v.z - this.z;
		return Math.sqrt(a * a + b * b + c * c);
	}
};
var Matrix4 = class Matrix4 {
	temp = /* @__PURE__ */ new Float32Array(16);
	values = /* @__PURE__ */ new Float32Array(16);
	static xAxis = new Vector3();
	static yAxis = new Vector3();
	static zAxis = new Vector3();
	static tmpMatrix = new Matrix4();
	constructor() {
		let v = this.values;
		v[0] = 1;
		v[5] = 1;
		v[10] = 1;
		v[15] = 1;
	}
	set(values) {
		this.values.set(values);
		return this;
	}
	transpose() {
		let t = this.temp;
		let v = this.values;
		t[0] = v[0];
		t[4] = v[1];
		t[8] = v[2];
		t[12] = v[3];
		t[1] = v[4];
		t[5] = v[5];
		t[9] = v[6];
		t[13] = v[7];
		t[2] = v[8];
		t[6] = v[9];
		t[10] = v[10];
		t[14] = v[11];
		t[3] = v[12];
		t[7] = v[13];
		t[11] = v[14];
		t[15] = v[15];
		return this.set(t);
	}
	identity() {
		let v = this.values;
		v[0] = 1;
		v[4] = 0;
		v[8] = 0;
		v[12] = 0;
		v[1] = 0;
		v[5] = 1;
		v[9] = 0;
		v[13] = 0;
		v[2] = 0;
		v[6] = 0;
		v[10] = 1;
		v[14] = 0;
		v[3] = 0;
		v[7] = 0;
		v[11] = 0;
		v[15] = 1;
		return this;
	}
	invert() {
		let v = this.values;
		let t = this.temp;
		let l_det = v[3] * v[6] * v[9] * v[12] - v[2] * v[7] * v[9] * v[12] - v[3] * v[5] * v[10] * v[12] + v[1] * v[7] * v[10] * v[12] + v[2] * v[5] * v[11] * v[12] - v[1] * v[6] * v[11] * v[12] - v[3] * v[6] * v[8] * v[13] + v[2] * v[7] * v[8] * v[13] + v[3] * v[4] * v[10] * v[13] - v[0] * v[7] * v[10] * v[13] - v[2] * v[4] * v[11] * v[13] + v[0] * v[6] * v[11] * v[13] + v[3] * v[5] * v[8] * v[14] - v[1] * v[7] * v[8] * v[14] - v[3] * v[4] * v[9] * v[14] + v[0] * v[7] * v[9] * v[14] + v[1] * v[4] * v[11] * v[14] - v[0] * v[5] * v[11] * v[14] - v[2] * v[5] * v[8] * v[15] + v[1] * v[6] * v[8] * v[15] + v[2] * v[4] * v[9] * v[15] - v[0] * v[6] * v[9] * v[15] - v[1] * v[4] * v[10] * v[15] + v[0] * v[5] * v[10] * v[15];
		if (l_det == 0) throw new Error("non-invertible matrix");
		let inv_det = 1 / l_det;
		t[0] = v[9] * v[14] * v[7] - v[13] * v[10] * v[7] + v[13] * v[6] * v[11] - v[5] * v[14] * v[11] - v[9] * v[6] * v[15] + v[5] * v[10] * v[15];
		t[4] = v[12] * v[10] * v[7] - v[8] * v[14] * v[7] - v[12] * v[6] * v[11] + v[4] * v[14] * v[11] + v[8] * v[6] * v[15] - v[4] * v[10] * v[15];
		t[8] = v[8] * v[13] * v[7] - v[12] * v[9] * v[7] + v[12] * v[5] * v[11] - v[4] * v[13] * v[11] - v[8] * v[5] * v[15] + v[4] * v[9] * v[15];
		t[12] = v[12] * v[9] * v[6] - v[8] * v[13] * v[6] - v[12] * v[5] * v[10] + v[4] * v[13] * v[10] + v[8] * v[5] * v[14] - v[4] * v[9] * v[14];
		t[1] = v[13] * v[10] * v[3] - v[9] * v[14] * v[3] - v[13] * v[2] * v[11] + v[1] * v[14] * v[11] + v[9] * v[2] * v[15] - v[1] * v[10] * v[15];
		t[5] = v[8] * v[14] * v[3] - v[12] * v[10] * v[3] + v[12] * v[2] * v[11] - v[0] * v[14] * v[11] - v[8] * v[2] * v[15] + v[0] * v[10] * v[15];
		t[9] = v[12] * v[9] * v[3] - v[8] * v[13] * v[3] - v[12] * v[1] * v[11] + v[0] * v[13] * v[11] + v[8] * v[1] * v[15] - v[0] * v[9] * v[15];
		t[13] = v[8] * v[13] * v[2] - v[12] * v[9] * v[2] + v[12] * v[1] * v[10] - v[0] * v[13] * v[10] - v[8] * v[1] * v[14] + v[0] * v[9] * v[14];
		t[2] = v[5] * v[14] * v[3] - v[13] * v[6] * v[3] + v[13] * v[2] * v[7] - v[1] * v[14] * v[7] - v[5] * v[2] * v[15] + v[1] * v[6] * v[15];
		t[6] = v[12] * v[6] * v[3] - v[4] * v[14] * v[3] - v[12] * v[2] * v[7] + v[0] * v[14] * v[7] + v[4] * v[2] * v[15] - v[0] * v[6] * v[15];
		t[10] = v[4] * v[13] * v[3] - v[12] * v[5] * v[3] + v[12] * v[1] * v[7] - v[0] * v[13] * v[7] - v[4] * v[1] * v[15] + v[0] * v[5] * v[15];
		t[14] = v[12] * v[5] * v[2] - v[4] * v[13] * v[2] - v[12] * v[1] * v[6] + v[0] * v[13] * v[6] + v[4] * v[1] * v[14] - v[0] * v[5] * v[14];
		t[3] = v[9] * v[6] * v[3] - v[5] * v[10] * v[3] - v[9] * v[2] * v[7] + v[1] * v[10] * v[7] + v[5] * v[2] * v[11] - v[1] * v[6] * v[11];
		t[7] = v[4] * v[10] * v[3] - v[8] * v[6] * v[3] + v[8] * v[2] * v[7] - v[0] * v[10] * v[7] - v[4] * v[2] * v[11] + v[0] * v[6] * v[11];
		t[11] = v[8] * v[5] * v[3] - v[4] * v[9] * v[3] - v[8] * v[1] * v[7] + v[0] * v[9] * v[7] + v[4] * v[1] * v[11] - v[0] * v[5] * v[11];
		t[15] = v[4] * v[9] * v[2] - v[8] * v[5] * v[2] + v[8] * v[1] * v[6] - v[0] * v[9] * v[6] - v[4] * v[1] * v[10] + v[0] * v[5] * v[10];
		v[0] = t[0] * inv_det;
		v[4] = t[4] * inv_det;
		v[8] = t[8] * inv_det;
		v[12] = t[12] * inv_det;
		v[1] = t[1] * inv_det;
		v[5] = t[5] * inv_det;
		v[9] = t[9] * inv_det;
		v[13] = t[13] * inv_det;
		v[2] = t[2] * inv_det;
		v[6] = t[6] * inv_det;
		v[10] = t[10] * inv_det;
		v[14] = t[14] * inv_det;
		v[3] = t[3] * inv_det;
		v[7] = t[7] * inv_det;
		v[11] = t[11] * inv_det;
		v[15] = t[15] * inv_det;
		return this;
	}
	determinant() {
		let v = this.values;
		return v[3] * v[6] * v[9] * v[12] - v[2] * v[7] * v[9] * v[12] - v[3] * v[5] * v[10] * v[12] + v[1] * v[7] * v[10] * v[12] + v[2] * v[5] * v[11] * v[12] - v[1] * v[6] * v[11] * v[12] - v[3] * v[6] * v[8] * v[13] + v[2] * v[7] * v[8] * v[13] + v[3] * v[4] * v[10] * v[13] - v[0] * v[7] * v[10] * v[13] - v[2] * v[4] * v[11] * v[13] + v[0] * v[6] * v[11] * v[13] + v[3] * v[5] * v[8] * v[14] - v[1] * v[7] * v[8] * v[14] - v[3] * v[4] * v[9] * v[14] + v[0] * v[7] * v[9] * v[14] + v[1] * v[4] * v[11] * v[14] - v[0] * v[5] * v[11] * v[14] - v[2] * v[5] * v[8] * v[15] + v[1] * v[6] * v[8] * v[15] + v[2] * v[4] * v[9] * v[15] - v[0] * v[6] * v[9] * v[15] - v[1] * v[4] * v[10] * v[15] + v[0] * v[5] * v[10] * v[15];
	}
	translate(x, y, z) {
		let v = this.values;
		v[12] += x;
		v[13] += y;
		v[14] += z;
		return this;
	}
	copy() {
		return new Matrix4().set(this.values);
	}
	projection(near, far, fovy, aspectRatio) {
		this.identity();
		let l_fd = 1 / Math.tan(fovy * (Math.PI / 180) / 2);
		let l_a1 = (far + near) / (near - far);
		let l_a2 = 2 * far * near / (near - far);
		let v = this.values;
		v[0] = l_fd / aspectRatio;
		v[1] = 0;
		v[2] = 0;
		v[3] = 0;
		v[4] = 0;
		v[5] = l_fd;
		v[6] = 0;
		v[7] = 0;
		v[8] = 0;
		v[9] = 0;
		v[10] = l_a1;
		v[11] = -1;
		v[12] = 0;
		v[13] = 0;
		v[14] = l_a2;
		v[15] = 0;
		return this;
	}
	ortho2d(x, y, width, height) {
		return this.ortho(x, x + width, y, y + height, 0, 1);
	}
	ortho(left, right, bottom, top, near, far) {
		this.identity();
		let x_orth = 2 / (right - left);
		let y_orth = 2 / (top - bottom);
		let z_orth = -2 / (far - near);
		let tx = -(right + left) / (right - left);
		let ty = -(top + bottom) / (top - bottom);
		let tz = -(far + near) / (far - near);
		let v = this.values;
		v[0] = x_orth;
		v[1] = 0;
		v[2] = 0;
		v[3] = 0;
		v[4] = 0;
		v[5] = y_orth;
		v[6] = 0;
		v[7] = 0;
		v[8] = 0;
		v[9] = 0;
		v[10] = z_orth;
		v[11] = 0;
		v[12] = tx;
		v[13] = ty;
		v[14] = tz;
		v[15] = 1;
		return this;
	}
	multiply(matrix) {
		let t = this.temp;
		let v = this.values;
		let m = matrix.values;
		t[0] = v[0] * m[0] + v[4] * m[1] + v[8] * m[2] + v[12] * m[3];
		t[4] = v[0] * m[4] + v[4] * m[5] + v[8] * m[6] + v[12] * m[7];
		t[8] = v[0] * m[8] + v[4] * m[9] + v[8] * m[10] + v[12] * m[11];
		t[12] = v[0] * m[12] + v[4] * m[13] + v[8] * m[14] + v[12] * m[15];
		t[1] = v[1] * m[0] + v[5] * m[1] + v[9] * m[2] + v[13] * m[3];
		t[5] = v[1] * m[4] + v[5] * m[5] + v[9] * m[6] + v[13] * m[7];
		t[9] = v[1] * m[8] + v[5] * m[9] + v[9] * m[10] + v[13] * m[11];
		t[13] = v[1] * m[12] + v[5] * m[13] + v[9] * m[14] + v[13] * m[15];
		t[2] = v[2] * m[0] + v[6] * m[1] + v[10] * m[2] + v[14] * m[3];
		t[6] = v[2] * m[4] + v[6] * m[5] + v[10] * m[6] + v[14] * m[7];
		t[10] = v[2] * m[8] + v[6] * m[9] + v[10] * m[10] + v[14] * m[11];
		t[14] = v[2] * m[12] + v[6] * m[13] + v[10] * m[14] + v[14] * m[15];
		t[3] = v[3] * m[0] + v[7] * m[1] + v[11] * m[2] + v[15] * m[3];
		t[7] = v[3] * m[4] + v[7] * m[5] + v[11] * m[6] + v[15] * m[7];
		t[11] = v[3] * m[8] + v[7] * m[9] + v[11] * m[10] + v[15] * m[11];
		t[15] = v[3] * m[12] + v[7] * m[13] + v[11] * m[14] + v[15] * m[15];
		return this.set(this.temp);
	}
	multiplyLeft(matrix) {
		let t = this.temp;
		let v = this.values;
		let m = matrix.values;
		t[0] = m[0] * v[0] + m[4] * v[1] + m[8] * v[2] + m[12] * v[3];
		t[4] = m[0] * v[4] + m[4] * v[5] + m[8] * v[6] + m[12] * v[7];
		t[8] = m[0] * v[8] + m[4] * v[9] + m[8] * v[10] + m[12] * v[11];
		t[12] = m[0] * v[12] + m[4] * v[13] + m[8] * v[14] + m[12] * v[15];
		t[1] = m[1] * v[0] + m[5] * v[1] + m[9] * v[2] + m[13] * v[3];
		t[5] = m[1] * v[4] + m[5] * v[5] + m[9] * v[6] + m[13] * v[7];
		t[9] = m[1] * v[8] + m[5] * v[9] + m[9] * v[10] + m[13] * v[11];
		t[13] = m[1] * v[12] + m[5] * v[13] + m[9] * v[14] + m[13] * v[15];
		t[2] = m[2] * v[0] + m[6] * v[1] + m[10] * v[2] + m[14] * v[3];
		t[6] = m[2] * v[4] + m[6] * v[5] + m[10] * v[6] + m[14] * v[7];
		t[10] = m[2] * v[8] + m[6] * v[9] + m[10] * v[10] + m[14] * v[11];
		t[14] = m[2] * v[12] + m[6] * v[13] + m[10] * v[14] + m[14] * v[15];
		t[3] = m[3] * v[0] + m[7] * v[1] + m[11] * v[2] + m[15] * v[3];
		t[7] = m[3] * v[4] + m[7] * v[5] + m[11] * v[6] + m[15] * v[7];
		t[11] = m[3] * v[8] + m[7] * v[9] + m[11] * v[10] + m[15] * v[11];
		t[15] = m[3] * v[12] + m[7] * v[13] + m[11] * v[14] + m[15] * v[15];
		return this.set(this.temp);
	}
	lookAt(position, direction, up) {
		let xAxis = Matrix4.xAxis, yAxis = Matrix4.yAxis, zAxis = Matrix4.zAxis;
		zAxis.setFrom(direction).normalize();
		xAxis.setFrom(direction).normalize();
		xAxis.cross(up).normalize();
		yAxis.setFrom(xAxis).cross(zAxis).normalize();
		this.identity();
		let val = this.values;
		val[0] = xAxis.x;
		val[4] = xAxis.y;
		val[8] = xAxis.z;
		val[1] = yAxis.x;
		val[5] = yAxis.y;
		val[9] = yAxis.z;
		val[2] = -zAxis.x;
		val[6] = -zAxis.y;
		val[10] = -zAxis.z;
		Matrix4.tmpMatrix.identity();
		Matrix4.tmpMatrix.values[12] = -position.x;
		Matrix4.tmpMatrix.values[13] = -position.y;
		Matrix4.tmpMatrix.values[14] = -position.z;
		this.multiply(Matrix4.tmpMatrix);
		return this;
	}
};
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/Camera.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var OrthoCamera = class {
	position = new Vector3(0, 0, 0);
	direction = new Vector3(0, 0, -1);
	up = new Vector3(0, 1, 0);
	near = 0;
	far = 100;
	zoom = 1;
	viewportWidth = 0;
	viewportHeight = 0;
	projectionView = new Matrix4();
	inverseProjectionView = new Matrix4();
	projection = new Matrix4();
	view = new Matrix4();
	constructor(viewportWidth, viewportHeight) {
		this.viewportWidth = viewportWidth;
		this.viewportHeight = viewportHeight;
		this.update();
	}
	update() {
		let projection = this.projection;
		let view = this.view;
		let projectionView = this.projectionView;
		let inverseProjectionView = this.inverseProjectionView;
		let zoom = this.zoom, viewportWidth = this.viewportWidth, viewportHeight = this.viewportHeight;
		projection.ortho(zoom * (-viewportWidth / 2), zoom * (viewportWidth / 2), zoom * (-viewportHeight / 2), zoom * (viewportHeight / 2), this.near, this.far);
		view.lookAt(this.position, this.direction, this.up);
		projectionView.set(projection.values);
		projectionView.multiply(view);
		inverseProjectionView.set(projectionView.values).invert();
	}
	screenToWorld(screenCoords, screenWidth, screenHeight) {
		let x = screenCoords.x, y = screenHeight - screenCoords.y - 1;
		screenCoords.x = 2 * x / screenWidth - 1;
		screenCoords.y = 2 * y / screenHeight - 1;
		screenCoords.z = 2 * screenCoords.z - 1;
		screenCoords.project(this.inverseProjectionView);
		return screenCoords;
	}
	worldToScreen(worldCoords, screenWidth, screenHeight) {
		worldCoords.project(this.projectionView);
		worldCoords.x = screenWidth * (worldCoords.x + 1) / 2;
		worldCoords.y = screenHeight * (worldCoords.y + 1) / 2;
		worldCoords.z = (worldCoords.z + 1) / 2;
		return worldCoords;
	}
	setViewport(viewportWidth, viewportHeight) {
		this.viewportWidth = viewportWidth;
		this.viewportHeight = viewportHeight;
	}
};
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/Input.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Input = class {
	element;
	mouseX = 0;
	mouseY = 0;
	buttonDown = false;
	touch0 = null;
	touch1 = null;
	initialPinchDistance = 0;
	listeners = new Array();
	autoPreventDefault;
	isTouch = false;
	callbacks;
	constructor(element, autoPreventDefault = true) {
		this.element = element;
		this.autoPreventDefault = autoPreventDefault;
		this.callbacks = this.setupCallbacks(element);
	}
	setupCallbacks(element) {
		const mouseDown = (ev) => {
			if (ev instanceof MouseEvent && !this.isTouch) {
				let rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.buttonDown = true;
				this.listeners.map((listener) => {
					if (listener.down) listener.down(this.mouseX, this.mouseY, ev);
				});
			}
		};
		const mouseMove = (ev) => {
			if (ev instanceof MouseEvent && !this.isTouch) {
				let rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.listeners.map((listener) => {
					if (this.buttonDown) {
						if (listener.dragged) listener.dragged(this.mouseX, this.mouseY, ev);
					} else if (listener.moved) listener.moved(this.mouseX, this.mouseY, ev);
				});
			}
		};
		const mouseUp = (ev) => {
			if (ev instanceof MouseEvent && !this.isTouch) {
				let rect = element.getBoundingClientRect();
				this.mouseX = ev.clientX - rect.left;
				this.mouseY = ev.clientY - rect.top;
				this.buttonDown = false;
				this.listeners.map((listener) => {
					if (listener.up) listener.up(this.mouseX, this.mouseY, ev);
				});
			}
		};
		const mouseWheel = (ev) => {
			if (this.autoPreventDefault) ev.preventDefault();
			let deltaY = ev.deltaY;
			if (ev.deltaMode == WheelEvent.DOM_DELTA_LINE) deltaY *= 8;
			if (ev.deltaMode == WheelEvent.DOM_DELTA_PAGE) deltaY *= 24;
			this.listeners.map((listener) => {
				if (listener.wheel) listener.wheel(ev.deltaY, ev);
			});
		};
		const touchStart = (ev) => {
			this.isTouch = true;
			if (!this.touch0 || !this.touch1) {
				let nativeTouch = ev.changedTouches.item(0);
				if (!nativeTouch) return;
				let rect = element.getBoundingClientRect();
				let x = nativeTouch.clientX - rect.left;
				let y = nativeTouch.clientY - rect.top;
				let touch = new Touch(nativeTouch.identifier, x, y);
				this.mouseX = x;
				this.mouseY = y;
				this.buttonDown = true;
				if (!this.touch0) {
					this.touch0 = touch;
					this.listeners.map((listener) => {
						if (listener.down) listener.down(touch.x, touch.y, ev);
					});
				} else if (!this.touch1) {
					this.touch1 = touch;
					let dx = this.touch1.x - this.touch0.x;
					let dy = this.touch1.x - this.touch0.x;
					this.initialPinchDistance = Math.sqrt(dx * dx + dy * dy);
					this.listeners.map((listener) => {
						if (listener.zoom) listener.zoom(this.initialPinchDistance, this.initialPinchDistance, ev);
					});
				}
			}
			if (this.autoPreventDefault) ev.preventDefault();
		};
		const touchMove = (ev) => {
			this.isTouch = true;
			if (this.touch0) {
				var touches = ev.changedTouches;
				let rect = element.getBoundingClientRect();
				for (var i = 0; i < touches.length; i++) {
					var nativeTouch = touches[i];
					let x = nativeTouch.clientX - rect.left;
					let y = nativeTouch.clientY - rect.top;
					if (this.touch0.identifier === nativeTouch.identifier) {
						this.touch0.x = this.mouseX = x;
						this.touch0.y = this.mouseY = y;
						this.listeners.map((listener) => {
							if (listener.dragged) listener.dragged(x, y, ev);
						});
					}
					if (this.touch1 && this.touch1.identifier === nativeTouch.identifier) {
						this.touch1.x = this.mouseX = x;
						this.touch1.y = this.mouseY = y;
					}
				}
				if (this.touch0 && this.touch1) {
					let dx = this.touch1.x - this.touch0.x;
					let dy = this.touch1.x - this.touch0.x;
					let distance = Math.sqrt(dx * dx + dy * dy);
					this.listeners.map((listener) => {
						if (listener.zoom) listener.zoom(this.initialPinchDistance, distance, ev);
					});
				}
			}
			if (this.autoPreventDefault) ev.preventDefault();
		};
		const touchEnd = (ev) => {
			this.isTouch = true;
			if (this.touch0) {
				var touches = ev.changedTouches;
				let rect = element.getBoundingClientRect();
				for (var i = 0; i < touches.length; i++) {
					var nativeTouch = touches[i];
					let x = nativeTouch.clientX - rect.left;
					let y = nativeTouch.clientY - rect.top;
					if (this.touch0.identifier === nativeTouch.identifier) {
						this.touch0 = null;
						this.mouseX = x;
						this.mouseY = y;
						this.listeners.map((listener) => {
							if (listener.up) listener.up(x, y, ev);
						});
						if (!this.touch1) {
							this.buttonDown = false;
							break;
						} else {
							this.touch0 = this.touch1;
							this.touch1 = null;
							this.mouseX = this.touch0.x;
							this.mouseX = this.touch0.x;
							this.buttonDown = true;
							this.listeners.map((listener) => {
								if (listener.down) listener.down(this.touch0.x, this.touch0.y, ev);
							});
						}
					}
					if (this.touch1 && this.touch1.identifier) this.touch1 = null;
				}
			}
			if (this.autoPreventDefault) ev.preventDefault();
		};
		element.addEventListener("mousedown", mouseDown, true);
		element.addEventListener("mousemove", mouseMove, true);
		element.addEventListener("mouseup", mouseUp, true);
		element.addEventListener("wheel", mouseWheel, true);
		element.addEventListener("touchstart", touchStart, {
			passive: false,
			capture: false
		});
		element.addEventListener("touchmove", touchMove, {
			passive: false,
			capture: false
		});
		element.addEventListener("touchend", touchEnd, {
			passive: false,
			capture: false
		});
		element.addEventListener("touchcancel", touchEnd);
		return {
			mouseDown,
			mouseMove,
			mouseUp,
			mouseWheel,
			touchStart,
			touchMove,
			touchEnd
		};
	}
	dispose() {
		const element = this.element;
		element.removeEventListener("mousedown", this.callbacks.mouseDown, true);
		element.removeEventListener("mousemove", this.callbacks.mouseMove, true);
		element.removeEventListener("mouseup", this.callbacks.mouseUp, true);
		element.removeEventListener("wheel", this.callbacks.mouseWheel, true);
		element.removeEventListener("touchstart", this.callbacks.touchStart, { capture: false });
		element.removeEventListener("touchmove", this.callbacks.touchMove, { capture: false });
		element.removeEventListener("touchend", this.callbacks.touchEnd, { capture: false });
		element.removeEventListener("touchcancel", this.callbacks.touchEnd);
		this.listeners.length = 0;
	}
	addListener(listener) {
		this.listeners.push(listener);
	}
	removeListener(listener) {
		let idx = this.listeners.indexOf(listener);
		if (idx > -1) this.listeners.splice(idx, 1);
	}
};
var Touch = class {
	identifier;
	x;
	y;
	constructor(identifier, x, y) {
		this.identifier = identifier;
		this.x = x;
		this.y = y;
	}
};
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/Shader.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Shader = class Shader {
	vertexShader;
	fragmentShader;
	static MVP_MATRIX = "u_projTrans";
	static POSITION = "a_position";
	static COLOR = "a_color";
	static COLOR2 = "a_color2";
	static TEXCOORDS = "a_texCoords";
	static SAMPLER = "u_texture";
	context;
	vs = null;
	vsSource;
	fs = null;
	fsSource;
	program = null;
	tmp2x2 = /* @__PURE__ */ new Float32Array(4);
	tmp3x3 = /* @__PURE__ */ new Float32Array(9);
	tmp4x4 = /* @__PURE__ */ new Float32Array(16);
	getProgram() {
		return this.program;
	}
	getVertexShader() {
		return this.vertexShader;
	}
	getFragmentShader() {
		return this.fragmentShader;
	}
	getVertexShaderSource() {
		return this.vsSource;
	}
	getFragmentSource() {
		return this.fsSource;
	}
	constructor(context, vertexShader, fragmentShader) {
		this.vertexShader = vertexShader;
		this.fragmentShader = fragmentShader;
		this.vsSource = vertexShader;
		this.fsSource = fragmentShader;
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		this.context.addRestorable(this);
		this.compile();
	}
	compile() {
		let gl = this.context.gl;
		try {
			this.vs = this.compileShader(gl.VERTEX_SHADER, this.vertexShader);
			if (!this.vs) throw new Error("Couldn't compile vertex shader.");
			this.fs = this.compileShader(gl.FRAGMENT_SHADER, this.fragmentShader);
			if (!this.fs) throw new Error("Couldn#t compile fragment shader.");
			this.program = this.compileProgram(this.vs, this.fs);
		} catch (e) {
			this.dispose();
			throw e;
		}
	}
	compileShader(type, source) {
		let gl = this.context.gl;
		let shader = gl.createShader(type);
		if (!shader) throw new Error("Couldn't create shader.");
		gl.shaderSource(shader, source);
		gl.compileShader(shader);
		if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
			let error = "Couldn't compile shader: " + gl.getShaderInfoLog(shader);
			gl.deleteShader(shader);
			if (!gl.isContextLost()) throw new Error(error);
		}
		return shader;
	}
	compileProgram(vs, fs) {
		let gl = this.context.gl;
		let program = gl.createProgram();
		if (!program) throw new Error("Couldn't compile program.");
		gl.attachShader(program, vs);
		gl.attachShader(program, fs);
		gl.linkProgram(program);
		if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
			let error = "Couldn't compile shader program: " + gl.getProgramInfoLog(program);
			gl.deleteProgram(program);
			if (!gl.isContextLost()) throw new Error(error);
		}
		return program;
	}
	restore() {
		this.compile();
	}
	bind() {
		this.context.gl.useProgram(this.program);
	}
	unbind() {
		this.context.gl.useProgram(null);
	}
	setUniformi(uniform, value) {
		this.context.gl.uniform1i(this.getUniformLocation(uniform), value);
	}
	setUniformf(uniform, value) {
		this.context.gl.uniform1f(this.getUniformLocation(uniform), value);
	}
	setUniform2f(uniform, value, value2) {
		this.context.gl.uniform2f(this.getUniformLocation(uniform), value, value2);
	}
	setUniform3f(uniform, value, value2, value3) {
		this.context.gl.uniform3f(this.getUniformLocation(uniform), value, value2, value3);
	}
	setUniform4f(uniform, value, value2, value3, value4) {
		this.context.gl.uniform4f(this.getUniformLocation(uniform), value, value2, value3, value4);
	}
	setUniform2x2f(uniform, value) {
		let gl = this.context.gl;
		this.tmp2x2.set(value);
		gl.uniformMatrix2fv(this.getUniformLocation(uniform), false, this.tmp2x2);
	}
	setUniform3x3f(uniform, value) {
		let gl = this.context.gl;
		this.tmp3x3.set(value);
		gl.uniformMatrix3fv(this.getUniformLocation(uniform), false, this.tmp3x3);
	}
	setUniform4x4f(uniform, value) {
		let gl = this.context.gl;
		this.tmp4x4.set(value);
		gl.uniformMatrix4fv(this.getUniformLocation(uniform), false, this.tmp4x4);
	}
	getUniformLocation(uniform) {
		let gl = this.context.gl;
		if (!this.program) throw new Error("Shader not compiled.");
		let location = gl.getUniformLocation(this.program, uniform);
		if (!location && !gl.isContextLost()) throw new Error(`Couldn't find location for uniform ${uniform}`);
		return location;
	}
	getAttributeLocation(attribute) {
		let gl = this.context.gl;
		if (!this.program) throw new Error("Shader not compiled.");
		let location = gl.getAttribLocation(this.program, attribute);
		if (location == -1 && !gl.isContextLost()) throw new Error(`Couldn't find location for attribute ${attribute}`);
		return location;
	}
	dispose() {
		this.context.removeRestorable(this);
		let gl = this.context.gl;
		if (this.vs) {
			gl.deleteShader(this.vs);
			this.vs = null;
		}
		if (this.fs) {
			gl.deleteShader(this.fs);
			this.fs = null;
		}
		if (this.program) {
			gl.deleteProgram(this.program);
			this.program = null;
		}
	}
	static newColoredTextured(context) {
		let vs = `
attribute vec4 ${Shader.POSITION};
attribute vec4 ${Shader.COLOR};
attribute vec2 ${Shader.TEXCOORDS};
uniform mat4 ${Shader.MVP_MATRIX};
varying vec4 v_color;
varying vec2 v_texCoords;

void main () {
	v_color = ${Shader.COLOR};
	v_texCoords = ${Shader.TEXCOORDS};
	gl_Position = ${Shader.MVP_MATRIX} * ${Shader.POSITION};
}
`;
		return new Shader(context, vs, `
#ifdef GL_ES
	#define LOWP lowp
	precision mediump float;
#else
	#define LOWP
#endif
varying LOWP vec4 v_color;
varying vec2 v_texCoords;
uniform sampler2D u_texture;

void main () {
	gl_FragColor = v_color * texture2D(u_texture, v_texCoords);
}
`);
	}
	static newTwoColoredTextured(context) {
		let vs = `
attribute vec4 ${Shader.POSITION};
attribute vec4 ${Shader.COLOR};
attribute vec4 ${Shader.COLOR2};
attribute vec2 ${Shader.TEXCOORDS};
uniform mat4 ${Shader.MVP_MATRIX};
varying vec4 v_light;
varying vec4 v_dark;
varying vec2 v_texCoords;

void main () {
	v_light = ${Shader.COLOR};
	v_dark = ${Shader.COLOR2};
	v_texCoords = ${Shader.TEXCOORDS};
	gl_Position = ${Shader.MVP_MATRIX} * ${Shader.POSITION};
}
`;
		return new Shader(context, vs, `
#ifdef GL_ES
	#define LOWP lowp
	precision mediump float;
#else
	#define LOWP
#endif
varying LOWP vec4 v_light;
varying LOWP vec4 v_dark;
varying vec2 v_texCoords;
uniform sampler2D u_texture;

void main () {
	vec4 texColor = texture2D(u_texture, v_texCoords);
	gl_FragColor.a = texColor.a * v_light.a;
	gl_FragColor.rgb = ((texColor.a - 1.0) * v_dark.a + 1.0 - texColor.rgb) * v_dark.rgb + texColor.rgb * v_light.rgb;
}
`);
	}
	static newColored(context) {
		let vs = `
attribute vec4 ${Shader.POSITION};
attribute vec4 ${Shader.COLOR};
uniform mat4 ${Shader.MVP_MATRIX};
varying vec4 v_color;

void main () {
	v_color = ${Shader.COLOR};
	gl_Position = ${Shader.MVP_MATRIX} * ${Shader.POSITION};
}
`;
		return new Shader(context, vs, `
#ifdef GL_ES
	#define LOWP lowp
	precision mediump float;
#else
	#define LOWP
#endif
varying LOWP vec4 v_color;

void main () {
	gl_FragColor = v_color;
}
`);
	}
};
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/Mesh.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Mesh = class {
	attributes;
	context;
	vertices;
	verticesBuffer = null;
	verticesLength = 0;
	dirtyVertices = false;
	indices;
	indicesBuffer = null;
	indicesLength = 0;
	dirtyIndices = false;
	elementsPerVertex = 0;
	getAttributes() {
		return this.attributes;
	}
	maxVertices() {
		return this.vertices.length / this.elementsPerVertex;
	}
	numVertices() {
		return this.verticesLength / this.elementsPerVertex;
	}
	setVerticesLength(length) {
		this.dirtyVertices = true;
		this.verticesLength = length;
	}
	getVertices() {
		return this.vertices;
	}
	maxIndices() {
		return this.indices.length;
	}
	numIndices() {
		return this.indicesLength;
	}
	setIndicesLength(length) {
		this.dirtyIndices = true;
		this.indicesLength = length;
	}
	getIndices() {
		return this.indices;
	}
	getVertexSizeInFloats() {
		let size = 0;
		for (var i = 0; i < this.attributes.length; i++) {
			let attribute = this.attributes[i];
			size += attribute.numElements;
		}
		return size;
	}
	constructor(context, attributes, maxVertices, maxIndices) {
		this.attributes = attributes;
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		this.elementsPerVertex = 0;
		for (let i = 0; i < attributes.length; i++) this.elementsPerVertex += attributes[i].numElements;
		this.vertices = new Float32Array(maxVertices * this.elementsPerVertex);
		this.indices = new Uint16Array(maxIndices);
		this.context.addRestorable(this);
	}
	setVertices(vertices) {
		this.dirtyVertices = true;
		if (vertices.length > this.vertices.length) throw Error("Mesh can't store more than " + this.maxVertices() + " vertices");
		this.vertices.set(vertices, 0);
		this.verticesLength = vertices.length;
	}
	setIndices(indices) {
		this.dirtyIndices = true;
		if (indices.length > this.indices.length) throw Error("Mesh can't store more than " + this.maxIndices() + " indices");
		this.indices.set(indices, 0);
		this.indicesLength = indices.length;
	}
	draw(shader, primitiveType) {
		this.drawWithOffset(shader, primitiveType, 0, this.indicesLength > 0 ? this.indicesLength : this.verticesLength / this.elementsPerVertex);
	}
	drawWithOffset(shader, primitiveType, offset, count) {
		let gl = this.context.gl;
		if (this.dirtyVertices || this.dirtyIndices) this.update();
		this.bind(shader);
		if (this.indicesLength > 0) gl.drawElements(primitiveType, count, gl.UNSIGNED_SHORT, offset * 2);
		else gl.drawArrays(primitiveType, offset, count);
		this.unbind(shader);
	}
	bind(shader) {
		let gl = this.context.gl;
		gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);
		let offset = 0;
		for (let i = 0; i < this.attributes.length; i++) {
			let attrib = this.attributes[i];
			let location = shader.getAttributeLocation(attrib.name);
			gl.enableVertexAttribArray(location);
			gl.vertexAttribPointer(location, attrib.numElements, gl.FLOAT, false, this.elementsPerVertex * 4, offset * 4);
			offset += attrib.numElements;
		}
		if (this.indicesLength > 0) gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indicesBuffer);
	}
	unbind(shader) {
		let gl = this.context.gl;
		for (let i = 0; i < this.attributes.length; i++) {
			let attrib = this.attributes[i];
			let location = shader.getAttributeLocation(attrib.name);
			gl.disableVertexAttribArray(location);
		}
		gl.bindBuffer(gl.ARRAY_BUFFER, null);
		if (this.indicesLength > 0) gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null);
	}
	update() {
		let gl = this.context.gl;
		if (this.dirtyVertices) {
			if (!this.verticesBuffer) this.verticesBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);
			gl.bufferData(gl.ARRAY_BUFFER, this.vertices.subarray(0, this.verticesLength), gl.DYNAMIC_DRAW);
			this.dirtyVertices = false;
		}
		if (this.dirtyIndices) {
			if (!this.indicesBuffer) this.indicesBuffer = gl.createBuffer();
			gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indicesBuffer);
			gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.indices.subarray(0, this.indicesLength), gl.DYNAMIC_DRAW);
			this.dirtyIndices = false;
		}
	}
	restore() {
		this.verticesBuffer = null;
		this.indicesBuffer = null;
		this.update();
	}
	dispose() {
		this.context.removeRestorable(this);
		let gl = this.context.gl;
		gl.deleteBuffer(this.verticesBuffer);
		gl.deleteBuffer(this.indicesBuffer);
	}
};
var VertexAttribute = class {
	name;
	type;
	numElements;
	constructor(name, type, numElements) {
		this.name = name;
		this.type = type;
		this.numElements = numElements;
	}
};
var Position2Attribute = class extends VertexAttribute {
	constructor() {
		super(Shader.POSITION, VertexAttributeType.Float, 2);
	}
};
var TexCoordAttribute = class extends VertexAttribute {
	constructor(unit = 0) {
		super(Shader.TEXCOORDS + (unit == 0 ? "" : unit), VertexAttributeType.Float, 2);
	}
};
var ColorAttribute = class extends VertexAttribute {
	constructor() {
		super(Shader.COLOR, VertexAttributeType.Float, 4);
	}
};
var Color2Attribute = class extends VertexAttribute {
	constructor() {
		super(Shader.COLOR2, VertexAttributeType.Float, 4);
	}
};
var VertexAttributeType;
(function(VertexAttributeType) {
	VertexAttributeType[VertexAttributeType["Float"] = 0] = "Float";
})(VertexAttributeType || (VertexAttributeType = {}));
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/PolygonBatcher.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var GL_ONE = 1;
var GL_ONE_MINUS_SRC_COLOR = 769;
var GL_SRC_ALPHA = 770;
var GL_ONE_MINUS_SRC_ALPHA = 771;
var GL_DST_COLOR = 774;
var PolygonBatcher = class PolygonBatcher {
	static disableCulling = false;
	context;
	drawCalls = 0;
	static globalDrawCalls = 0;
	isDrawing = false;
	mesh;
	shader = null;
	lastTexture = null;
	verticesLength = 0;
	indicesLength = 0;
	srcColorBlend;
	srcAlphaBlend;
	dstBlend;
	cullWasEnabled = false;
	constructor(context, twoColorTint = true, maxVertices = 10920) {
		if (maxVertices > 10920) throw new Error("Can't have more than 10920 triangles per batch: " + maxVertices);
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		let attributes = twoColorTint ? [
			new Position2Attribute(),
			new ColorAttribute(),
			new TexCoordAttribute(),
			new Color2Attribute()
		] : [
			new Position2Attribute(),
			new ColorAttribute(),
			new TexCoordAttribute()
		];
		this.mesh = new Mesh(context, attributes, maxVertices, maxVertices * 3);
		let gl = this.context.gl;
		this.srcColorBlend = gl.SRC_ALPHA;
		this.srcAlphaBlend = gl.ONE;
		this.dstBlend = gl.ONE_MINUS_SRC_ALPHA;
	}
	begin(shader) {
		if (this.isDrawing) throw new Error("PolygonBatch is already drawing. Call PolygonBatch.end() before calling PolygonBatch.begin()");
		this.drawCalls = 0;
		this.shader = shader;
		this.lastTexture = null;
		this.isDrawing = true;
		let gl = this.context.gl;
		gl.enable(gl.BLEND);
		gl.blendFuncSeparate(this.srcColorBlend, this.dstBlend, this.srcAlphaBlend, this.dstBlend);
		if (PolygonBatcher.disableCulling) {
			this.cullWasEnabled = gl.isEnabled(gl.CULL_FACE);
			if (this.cullWasEnabled) gl.disable(gl.CULL_FACE);
		}
	}
	static blendModesGL = [
		{
			srcRgb: GL_SRC_ALPHA,
			srcRgbPma: GL_ONE,
			dstRgb: GL_ONE_MINUS_SRC_ALPHA,
			srcAlpha: GL_ONE
		},
		{
			srcRgb: GL_SRC_ALPHA,
			srcRgbPma: GL_ONE,
			dstRgb: GL_ONE,
			srcAlpha: GL_ONE
		},
		{
			srcRgb: GL_DST_COLOR,
			srcRgbPma: GL_DST_COLOR,
			dstRgb: GL_ONE_MINUS_SRC_ALPHA,
			srcAlpha: GL_ONE
		},
		{
			srcRgb: GL_ONE,
			srcRgbPma: GL_ONE,
			dstRgb: GL_ONE_MINUS_SRC_COLOR,
			srcAlpha: GL_ONE
		}
	];
	setBlendMode(blendMode, premultipliedAlpha) {
		const blendModeGL = PolygonBatcher.blendModesGL[blendMode];
		const srcColorBlend = premultipliedAlpha ? blendModeGL.srcRgbPma : blendModeGL.srcRgb;
		const srcAlphaBlend = blendModeGL.srcAlpha;
		const dstBlend = blendModeGL.dstRgb;
		if (this.srcColorBlend == srcColorBlend && this.srcAlphaBlend == srcAlphaBlend && this.dstBlend == dstBlend) return;
		this.srcColorBlend = srcColorBlend;
		this.srcAlphaBlend = srcAlphaBlend;
		this.dstBlend = dstBlend;
		if (this.isDrawing) this.flush();
		this.context.gl.blendFuncSeparate(srcColorBlend, dstBlend, srcAlphaBlend, dstBlend);
	}
	draw(texture, vertices, indices) {
		if (texture != this.lastTexture) {
			this.flush();
			this.lastTexture = texture;
		} else if (this.verticesLength + vertices.length > this.mesh.getVertices().length || this.indicesLength + indices.length > this.mesh.getIndices().length) this.flush();
		let indexStart = this.mesh.numVertices();
		this.mesh.getVertices().set(vertices, this.verticesLength);
		this.verticesLength += vertices.length;
		this.mesh.setVerticesLength(this.verticesLength);
		let indicesArray = this.mesh.getIndices();
		for (let i = this.indicesLength, j = 0; j < indices.length; i++, j++) indicesArray[i] = indices[j] + indexStart;
		this.indicesLength += indices.length;
		this.mesh.setIndicesLength(this.indicesLength);
	}
	flush() {
		if (this.verticesLength == 0) return;
		if (!this.lastTexture) throw new Error("No texture set.");
		if (!this.shader) throw new Error("No shader set.");
		this.lastTexture.bind();
		this.mesh.draw(this.shader, this.context.gl.TRIANGLES);
		this.verticesLength = 0;
		this.indicesLength = 0;
		this.mesh.setVerticesLength(0);
		this.mesh.setIndicesLength(0);
		this.drawCalls++;
		PolygonBatcher.globalDrawCalls++;
	}
	end() {
		if (!this.isDrawing) throw new Error("PolygonBatch is not drawing. Call PolygonBatch.begin() before calling PolygonBatch.end()");
		if (this.verticesLength > 0 || this.indicesLength > 0) this.flush();
		this.shader = null;
		this.lastTexture = null;
		this.isDrawing = false;
		let gl = this.context.gl;
		gl.disable(gl.BLEND);
		if (PolygonBatcher.disableCulling) {
			if (this.cullWasEnabled) gl.enable(gl.CULL_FACE);
		}
	}
	getDrawCalls() {
		return this.drawCalls;
	}
	static getAndResetGlobalDrawCalls() {
		let result = PolygonBatcher.globalDrawCalls;
		PolygonBatcher.globalDrawCalls = 0;
		return result;
	}
	dispose() {
		this.mesh.dispose();
	}
};
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/ShapeRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var ShapeRenderer = class {
	context;
	isDrawing = false;
	mesh;
	shapeType = ShapeType.Filled;
	color = new Color$2(1, 1, 1, 1);
	shader = null;
	vertexIndex = 0;
	tmp = new Vector2$2();
	srcColorBlend;
	srcAlphaBlend;
	dstBlend;
	constructor(context, maxVertices = 10920) {
		if (maxVertices > 10920) throw new Error("Can't have more than 10920 triangles per batch: " + maxVertices);
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		this.mesh = new Mesh(context, [new Position2Attribute(), new ColorAttribute()], maxVertices, 0);
		let gl = this.context.gl;
		this.srcColorBlend = gl.SRC_ALPHA;
		this.srcAlphaBlend = gl.ONE;
		this.dstBlend = gl.ONE_MINUS_SRC_ALPHA;
	}
	begin(shader) {
		if (this.isDrawing) throw new Error("ShapeRenderer.begin() has already been called");
		this.shader = shader;
		this.vertexIndex = 0;
		this.isDrawing = true;
		let gl = this.context.gl;
		gl.enable(gl.BLEND);
		gl.blendFuncSeparate(this.srcColorBlend, this.dstBlend, this.srcAlphaBlend, this.dstBlend);
	}
	setBlendMode(srcColorBlend, srcAlphaBlend, dstBlend) {
		this.srcColorBlend = srcColorBlend;
		this.srcAlphaBlend = srcAlphaBlend;
		this.dstBlend = dstBlend;
		if (this.isDrawing) {
			this.flush();
			this.context.gl.blendFuncSeparate(srcColorBlend, dstBlend, srcAlphaBlend, dstBlend);
		}
	}
	setColor(color) {
		this.color.setFromColor(color);
	}
	setColorWith(r, g, b, a) {
		this.color.set(r, g, b, a);
	}
	point(x, y, color) {
		this.check(ShapeType.Point, 1);
		if (!color) color = this.color;
		this.vertex(x, y, color);
	}
	line(x, y, x2, y2, color) {
		this.check(ShapeType.Line, 2);
		this.mesh.getVertices();
		this.vertexIndex;
		if (!color) color = this.color;
		this.vertex(x, y, color);
		this.vertex(x2, y2, color);
	}
	triangle(filled, x, y, x2, y2, x3, y3, color, color2, color3) {
		this.check(filled ? ShapeType.Filled : ShapeType.Line, 3);
		this.mesh.getVertices();
		this.vertexIndex;
		if (!color) color = this.color;
		if (!color2) color2 = this.color;
		if (!color3) color3 = this.color;
		if (filled) {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
		} else {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x2, y2, color);
			this.vertex(x3, y3, color2);
			this.vertex(x3, y3, color);
			this.vertex(x, y, color2);
		}
	}
	quad(filled, x, y, x2, y2, x3, y3, x4, y4, color, color2, color3, color4) {
		this.check(filled ? ShapeType.Filled : ShapeType.Line, 3);
		this.mesh.getVertices();
		this.vertexIndex;
		if (!color) color = this.color;
		if (!color2) color2 = this.color;
		if (!color3) color3 = this.color;
		if (!color4) color4 = this.color;
		if (filled) {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
			this.vertex(x3, y3, color3);
			this.vertex(x4, y4, color4);
			this.vertex(x, y, color);
		} else {
			this.vertex(x, y, color);
			this.vertex(x2, y2, color2);
			this.vertex(x2, y2, color2);
			this.vertex(x3, y3, color3);
			this.vertex(x3, y3, color3);
			this.vertex(x4, y4, color4);
			this.vertex(x4, y4, color4);
			this.vertex(x, y, color);
		}
	}
	rect(filled, x, y, width, height, color) {
		this.quad(filled, x, y, x + width, y, x + width, y + height, x, y + height, color, color, color, color);
	}
	rectLine(filled, x1, y1, x2, y2, width, color) {
		this.check(filled ? ShapeType.Filled : ShapeType.Line, 8);
		if (!color) color = this.color;
		let t = this.tmp.set(y2 - y1, x1 - x2);
		t.normalize();
		width *= .5;
		let tx = t.x * width;
		let ty = t.y * width;
		if (!filled) {
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
		} else {
			this.vertex(x1 + tx, y1 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x2 - tx, y2 - ty, color);
			this.vertex(x2 + tx, y2 + ty, color);
			this.vertex(x1 - tx, y1 - ty, color);
		}
	}
	x(x, y, size) {
		this.line(x - size, y - size, x + size, y + size);
		this.line(x - size, y + size, x + size, y - size);
	}
	polygon(polygonVertices, offset, count, color) {
		if (count < 3) throw new Error("Polygon must contain at least 3 vertices");
		this.check(ShapeType.Line, count * 2);
		if (!color) color = this.color;
		this.mesh.getVertices();
		this.vertexIndex;
		offset <<= 1;
		count <<= 1;
		let firstX = polygonVertices[offset];
		let firstY = polygonVertices[offset + 1];
		let last = offset + count;
		for (let i = offset, n = offset + count - 2; i < n; i += 2) {
			let x1 = polygonVertices[i];
			let y1 = polygonVertices[i + 1];
			let x2 = 0;
			let y2 = 0;
			if (i + 2 >= last) {
				x2 = firstX;
				y2 = firstY;
			} else {
				x2 = polygonVertices[i + 2];
				y2 = polygonVertices[i + 3];
			}
			this.vertex(x1, y1, color);
			this.vertex(x2, y2, color);
		}
	}
	circle(filled, x, y, radius, color, segments = 0) {
		if (segments == 0) segments = Math.max(1, 6 * MathUtils$2.cbrt(radius) | 0);
		if (segments <= 0) throw new Error("segments must be > 0.");
		if (!color) color = this.color;
		let angle = 2 * MathUtils$2.PI / segments;
		let cos = Math.cos(angle);
		let sin = Math.sin(angle);
		let cx = radius, cy = 0;
		if (!filled) {
			this.check(ShapeType.Line, segments * 2 + 2);
			for (let i = 0; i < segments; i++) {
				this.vertex(x + cx, y + cy, color);
				let temp = cx;
				cx = cos * cx - sin * cy;
				cy = sin * temp + cos * cy;
				this.vertex(x + cx, y + cy, color);
			}
			this.vertex(x + cx, y + cy, color);
		} else {
			this.check(ShapeType.Filled, segments * 3 + 3);
			segments--;
			for (let i = 0; i < segments; i++) {
				this.vertex(x, y, color);
				this.vertex(x + cx, y + cy, color);
				let temp = cx;
				cx = cos * cx - sin * cy;
				cy = sin * temp + cos * cy;
				this.vertex(x + cx, y + cy, color);
			}
			this.vertex(x, y, color);
			this.vertex(x + cx, y + cy, color);
		}
		cx = radius;
		cy = 0;
		this.vertex(x + cx, y + cy, color);
	}
	curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color) {
		this.check(ShapeType.Line, segments * 2 + 2);
		if (!color) color = this.color;
		let subdiv_step = 1 / segments;
		let subdiv_step2 = subdiv_step * subdiv_step;
		let subdiv_step3 = subdiv_step * subdiv_step * subdiv_step;
		let pre1 = 3 * subdiv_step;
		let pre2 = 3 * subdiv_step2;
		let pre4 = 6 * subdiv_step2;
		let pre5 = 6 * subdiv_step3;
		let tmp1x = x1 - cx1 * 2 + cx2;
		let tmp1y = y1 - cy1 * 2 + cy2;
		let tmp2x = (cx1 - cx2) * 3 - x1 + x2;
		let tmp2y = (cy1 - cy2) * 3 - y1 + y2;
		let fx = x1;
		let fy = y1;
		let dfx = (cx1 - x1) * pre1 + tmp1x * pre2 + tmp2x * subdiv_step3;
		let dfy = (cy1 - y1) * pre1 + tmp1y * pre2 + tmp2y * subdiv_step3;
		let ddfx = tmp1x * pre4 + tmp2x * pre5;
		let ddfy = tmp1y * pre4 + tmp2y * pre5;
		let dddfx = tmp2x * pre5;
		let dddfy = tmp2y * pre5;
		while (segments-- > 0) {
			this.vertex(fx, fy, color);
			fx += dfx;
			fy += dfy;
			dfx += ddfx;
			dfy += ddfy;
			ddfx += dddfx;
			ddfy += dddfy;
			this.vertex(fx, fy, color);
		}
		this.vertex(fx, fy, color);
		this.vertex(x2, y2, color);
	}
	vertex(x, y, color) {
		let idx = this.vertexIndex;
		let vertices = this.mesh.getVertices();
		vertices[idx++] = x;
		vertices[idx++] = y;
		vertices[idx++] = color.r;
		vertices[idx++] = color.g;
		vertices[idx++] = color.b;
		vertices[idx++] = color.a;
		this.vertexIndex = idx;
	}
	end() {
		if (!this.isDrawing) throw new Error("ShapeRenderer.begin() has not been called");
		this.flush();
		let gl = this.context.gl;
		gl.disable(gl.BLEND);
		this.isDrawing = false;
	}
	flush() {
		if (this.vertexIndex == 0) return;
		if (!this.shader) throw new Error("No shader set.");
		this.mesh.setVerticesLength(this.vertexIndex);
		this.mesh.draw(this.shader, this.shapeType);
		this.vertexIndex = 0;
	}
	check(shapeType, numVertices) {
		if (!this.isDrawing) throw new Error("ShapeRenderer.begin() has not been called");
		if (this.shapeType == shapeType) {
			if (this.mesh.maxVertices() - this.mesh.numVertices() < numVertices) this.flush();
			else return;
		} else {
			this.flush();
			this.shapeType = shapeType;
		}
	}
	dispose() {
		this.mesh.dispose();
	}
};
var ShapeType;
(function(ShapeType) {
	ShapeType[ShapeType["Point"] = 0] = "Point";
	ShapeType[ShapeType["Line"] = 1] = "Line";
	ShapeType[ShapeType["Filled"] = 4] = "Filled";
})(ShapeType || (ShapeType = {}));
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/SkeletonDebugRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var SkeletonDebugRenderer = class SkeletonDebugRenderer {
	boneLineColor = new Color$2(1, 0, 0, 1);
	boneOriginColor = new Color$2(0, 1, 0, 1);
	attachmentLineColor = new Color$2(0, 0, 1, .5);
	triangleLineColor = new Color$2(1, .64, 0, .5);
	pathColor = new Color$2().setFromString("FF7F00");
	clipColor = new Color$2(.8, 0, 0, 2);
	aabbColor = new Color$2(0, 1, 0, .5);
	drawBones = true;
	drawRegionAttachments = true;
	drawBoundingBoxes = true;
	drawMeshHull = true;
	drawMeshTriangles = true;
	drawPaths = true;
	drawSkeletonXY = false;
	drawClipping = true;
	premultipliedAlpha = false;
	scale = 1;
	boneWidth = 2;
	context;
	bounds = new SkeletonBounds$2();
	temp = new Array();
	vertices = Utils$2.newFloatArray(2048);
	static LIGHT_GRAY = new Color$2(192 / 255, 192 / 255, 192 / 255, 1);
	static GREEN = new Color$2(0, 1, 0, 1);
	constructor(context) {
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
	}
	draw(shapes, skeleton, ignoredBones) {
		let skeletonX = skeleton.x;
		let skeletonY = skeleton.y;
		let gl = this.context.gl;
		let srcFunc = this.premultipliedAlpha ? gl.ONE : gl.SRC_ALPHA;
		shapes.setBlendMode(srcFunc, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
		let bones = skeleton.bones;
		if (this.drawBones) {
			shapes.setColor(this.boneLineColor);
			for (let i = 0, n = bones.length; i < n; i++) {
				let bone = bones[i];
				if (ignoredBones && ignoredBones.indexOf(bone.data.name) > -1) continue;
				if (!bone.parent) continue;
				let x = bone.data.length * bone.a + bone.worldX;
				let y = bone.data.length * bone.c + bone.worldY;
				shapes.rectLine(true, bone.worldX, bone.worldY, x, y, this.boneWidth * this.scale);
			}
			if (this.drawSkeletonXY) shapes.x(skeletonX, skeletonY, 4 * this.scale);
		}
		if (this.drawRegionAttachments) {
			shapes.setColor(this.attachmentLineColor);
			let slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				let attachment = slot.getAttachment();
				if (attachment instanceof RegionAttachment$2) {
					let regionAttachment = attachment;
					let vertices = this.vertices;
					regionAttachment.computeWorldVertices(slot, vertices, 0, 2);
					shapes.line(vertices[0], vertices[1], vertices[2], vertices[3]);
					shapes.line(vertices[2], vertices[3], vertices[4], vertices[5]);
					shapes.line(vertices[4], vertices[5], vertices[6], vertices[7]);
					shapes.line(vertices[6], vertices[7], vertices[0], vertices[1]);
				}
			}
		}
		if (this.drawMeshHull || this.drawMeshTriangles) {
			let slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				if (!slot.bone.active) continue;
				let attachment = slot.getAttachment();
				if (!(attachment instanceof MeshAttachment$2)) continue;
				let mesh = attachment;
				let vertices = this.vertices;
				mesh.computeWorldVertices(slot, 0, mesh.worldVerticesLength, vertices, 0, 2);
				let triangles = mesh.triangles;
				let hullLength = mesh.hullLength;
				if (this.drawMeshTriangles) {
					shapes.setColor(this.triangleLineColor);
					for (let ii = 0, nn = triangles.length; ii < nn; ii += 3) {
						let v1 = triangles[ii] * 2, v2 = triangles[ii + 1] * 2, v3 = triangles[ii + 2] * 2;
						shapes.triangle(false, vertices[v1], vertices[v1 + 1], vertices[v2], vertices[v2 + 1], vertices[v3], vertices[v3 + 1]);
					}
				}
				if (this.drawMeshHull && hullLength > 0) {
					shapes.setColor(this.attachmentLineColor);
					hullLength = (hullLength >> 1) * 2;
					let lastX = vertices[hullLength - 2], lastY = vertices[hullLength - 1];
					for (let ii = 0, nn = hullLength; ii < nn; ii += 2) {
						let x = vertices[ii], y = vertices[ii + 1];
						shapes.line(x, y, lastX, lastY);
						lastX = x;
						lastY = y;
					}
				}
			}
		}
		if (this.drawBoundingBoxes) {
			let bounds = this.bounds;
			bounds.update(skeleton, true);
			shapes.setColor(this.aabbColor);
			shapes.rect(false, bounds.minX, bounds.minY, bounds.getWidth(), bounds.getHeight());
			let polygons = bounds.polygons;
			let boxes = bounds.boundingBoxes;
			for (let i = 0, n = polygons.length; i < n; i++) {
				let polygon = polygons[i];
				shapes.setColor(boxes[i].color);
				shapes.polygon(polygon, 0, polygon.length);
			}
		}
		if (this.drawPaths) {
			let slots = skeleton.slots;
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				if (!slot.bone.active) continue;
				let attachment = slot.getAttachment();
				if (!(attachment instanceof PathAttachment$2)) continue;
				let path = attachment;
				let nn = path.worldVerticesLength;
				let world = this.temp = Utils$2.setArraySize(this.temp, nn, 0);
				path.computeWorldVertices(slot, 0, nn, world, 0, 2);
				let color = this.pathColor;
				let x1 = world[2], y1 = world[3], x2 = 0, y2 = 0;
				if (path.closed) {
					shapes.setColor(color);
					let cx1 = world[0], cy1 = world[1], cx2 = world[nn - 2], cy2 = world[nn - 1];
					x2 = world[nn - 4];
					y2 = world[nn - 3];
					shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, 32);
					shapes.setColor(SkeletonDebugRenderer.LIGHT_GRAY);
					shapes.line(x1, y1, cx1, cy1);
					shapes.line(x2, y2, cx2, cy2);
				}
				nn -= 4;
				for (let ii = 4; ii < nn; ii += 6) {
					let cx1 = world[ii], cy1 = world[ii + 1], cx2 = world[ii + 2], cy2 = world[ii + 3];
					x2 = world[ii + 4];
					y2 = world[ii + 5];
					shapes.setColor(color);
					shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, 32);
					shapes.setColor(SkeletonDebugRenderer.LIGHT_GRAY);
					shapes.line(x1, y1, cx1, cy1);
					shapes.line(x2, y2, cx2, cy2);
					x1 = x2;
					y1 = y2;
				}
			}
		}
		if (this.drawBones) {
			shapes.setColor(this.boneOriginColor);
			for (let i = 0, n = bones.length; i < n; i++) {
				let bone = bones[i];
				if (ignoredBones && ignoredBones.indexOf(bone.data.name) > -1) continue;
				shapes.circle(true, bone.worldX, bone.worldY, 3 * this.scale, this.boneOriginColor, 8);
			}
		}
		if (this.drawClipping) {
			let slots = skeleton.slots;
			shapes.setColor(this.clipColor);
			for (let i = 0, n = slots.length; i < n; i++) {
				let slot = slots[i];
				if (!slot.bone.active) continue;
				let attachment = slot.getAttachment();
				if (!(attachment instanceof ClippingAttachment$2)) continue;
				let clip = attachment;
				let nn = clip.worldVerticesLength;
				let world = this.temp = Utils$2.setArraySize(this.temp, nn, 0);
				clip.computeWorldVertices(slot, 0, nn, world, 0, 2);
				for (let i = 0, n = world.length; i < n; i += 2) {
					let x = world[i];
					let y = world[i + 1];
					let x2 = world[(i + 2) % world.length];
					let y2 = world[(i + 3) % world.length];
					shapes.line(x, y, x2, y2);
				}
			}
		}
	}
	dispose() {}
};
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/SkeletonRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var Renderable = class {
	vertices;
	numVertices;
	numFloats;
	constructor(vertices, numVertices, numFloats) {
		this.vertices = vertices;
		this.numVertices = numVertices;
		this.numFloats = numFloats;
	}
};
var SkeletonRenderer = class SkeletonRenderer {
	static QUAD_TRIANGLES = [
		0,
		1,
		2,
		2,
		3,
		0
	];
	premultipliedAlpha = false;
	tempColor = new Color$2();
	tempColor2 = new Color$2();
	vertices;
	vertexSize = 8;
	twoColorTint = false;
	renderable = new Renderable([], 0, 0);
	clipper = new SkeletonClipping$2();
	temp = new Vector2$2();
	temp2 = new Vector2$2();
	temp3 = new Color$2();
	temp4 = new Color$2();
	/**
	* Batches additive slots together with normal slots by rendering additive slots with premultiplied alpha RGB and zero alpha,
	* while using normal PMA blending. This reduces draw calls for normal/additive/normal sequences with the same texture.
	*
	* Disabled by default in 4.2 to preserve exact additive alpha accumulation for transparent targets.
	*/
	pmaAdditiveBatching = false;
	constructor(context, twoColorTint = true) {
		this.twoColorTint = twoColorTint;
		if (twoColorTint) this.vertexSize += 4;
		this.vertices = Utils$2.newFloatArray(this.vertexSize * 1024);
	}
	draw(batcher, skeleton, slotRangeStart = -1, slotRangeEnd = -1, transformer = null) {
		let clipper = this.clipper;
		let premultipliedAlpha = this.premultipliedAlpha;
		let twoColorTint = this.twoColorTint;
		let blendMode = null;
		let renderable = this.renderable;
		let uvs;
		let triangles;
		let drawOrder = skeleton.drawOrder;
		let attachmentColor;
		let skeletonColor = skeleton.color;
		let vertexSize = twoColorTint ? 12 : 8;
		let inRange = false;
		if (slotRangeStart == -1) inRange = true;
		for (let i = 0, n = drawOrder.length; i < n; i++) {
			let clippedVertexSize = clipper.isClipping() ? 2 : vertexSize;
			let slot = drawOrder[i];
			if (!slot.bone.active) {
				clipper.clipEndWithSlot(slot);
				continue;
			}
			if (slotRangeStart >= 0 && slotRangeStart == slot.data.index) inRange = true;
			if (!inRange) {
				clipper.clipEndWithSlot(slot);
				continue;
			}
			if (slotRangeEnd >= 0 && slotRangeEnd == slot.data.index) inRange = false;
			let attachment = slot.getAttachment();
			let texture;
			if (attachment instanceof RegionAttachment$2) {
				let region = attachment;
				renderable.vertices = this.vertices;
				renderable.numVertices = 4;
				renderable.numFloats = clippedVertexSize << 2;
				region.computeWorldVertices(slot, renderable.vertices, 0, clippedVertexSize);
				triangles = SkeletonRenderer.QUAD_TRIANGLES;
				uvs = region.uvs;
				texture = region.region.texture;
				attachmentColor = region.color;
			} else if (attachment instanceof MeshAttachment$2) {
				let mesh = attachment;
				renderable.vertices = this.vertices;
				renderable.numVertices = mesh.worldVerticesLength >> 1;
				renderable.numFloats = renderable.numVertices * clippedVertexSize;
				if (renderable.numFloats > renderable.vertices.length) renderable.vertices = this.vertices = Utils$2.newFloatArray(renderable.numFloats);
				mesh.computeWorldVertices(slot, 0, mesh.worldVerticesLength, renderable.vertices, 0, clippedVertexSize);
				triangles = mesh.triangles;
				texture = mesh.region.texture;
				uvs = mesh.uvs;
				attachmentColor = mesh.color;
			} else if (attachment instanceof ClippingAttachment$2) {
				let clip = attachment;
				clipper.clipStart(slot, clip);
				continue;
			} else {
				clipper.clipEndWithSlot(slot);
				continue;
			}
			if (texture) {
				let slotColor = slot.color;
				let finalColor = this.tempColor;
				let slotBlendMode = slot.data.blendMode;
				let additiveBlend = this.pmaAdditiveBatching && premultipliedAlpha && slotBlendMode == BlendMode$2.Additive;
				let alpha = skeletonColor.a * slotColor.a * attachmentColor.a;
				finalColor.r = skeletonColor.r * slotColor.r * attachmentColor.r;
				finalColor.g = skeletonColor.g * slotColor.g * attachmentColor.g;
				finalColor.b = skeletonColor.b * slotColor.b * attachmentColor.b;
				finalColor.a = additiveBlend ? 0 : alpha;
				if (premultipliedAlpha) {
					finalColor.r *= alpha;
					finalColor.g *= alpha;
					finalColor.b *= alpha;
				}
				let darkColor = this.tempColor2;
				if (!slot.darkColor) darkColor.set(0, 0, 0, 1);
				else {
					if (premultipliedAlpha) {
						darkColor.r = slot.darkColor.r * finalColor.a;
						darkColor.g = slot.darkColor.g * finalColor.a;
						darkColor.b = slot.darkColor.b * finalColor.a;
					} else darkColor.setFromColor(slot.darkColor);
					darkColor.a = premultipliedAlpha ? 1 : 0;
				}
				let batchBlendMode = additiveBlend ? BlendMode$2.Normal : slotBlendMode;
				if (batchBlendMode != blendMode) {
					blendMode = batchBlendMode;
					batcher.setBlendMode(blendMode, premultipliedAlpha);
				}
				if (clipper.isClipping()) {
					clipper.clipTriangles(renderable.vertices, triangles, triangles.length, uvs, finalColor, darkColor, twoColorTint);
					let clippedVertices = new Float32Array(clipper.clippedVertices);
					let clippedTriangles = clipper.clippedTriangles;
					if (transformer) transformer(clippedVertices, clippedVertices.length, vertexSize);
					batcher.draw(texture, clippedVertices, clippedTriangles);
				} else {
					let verts = renderable.vertices;
					if (!twoColorTint) for (let v = 2, u = 0, n = renderable.numFloats; v < n; v += vertexSize, u += 2) {
						verts[v] = finalColor.r;
						verts[v + 1] = finalColor.g;
						verts[v + 2] = finalColor.b;
						verts[v + 3] = finalColor.a;
						verts[v + 4] = uvs[u];
						verts[v + 5] = uvs[u + 1];
					}
					else for (let v = 2, u = 0, n = renderable.numFloats; v < n; v += vertexSize, u += 2) {
						verts[v] = finalColor.r;
						verts[v + 1] = finalColor.g;
						verts[v + 2] = finalColor.b;
						verts[v + 3] = finalColor.a;
						verts[v + 4] = uvs[u];
						verts[v + 5] = uvs[u + 1];
						verts[v + 6] = darkColor.r;
						verts[v + 7] = darkColor.g;
						verts[v + 8] = darkColor.b;
						verts[v + 9] = darkColor.a;
					}
					let view = renderable.vertices.subarray(0, renderable.numFloats);
					if (transformer) transformer(renderable.vertices, renderable.numFloats, vertexSize);
					batcher.draw(texture, view, triangles);
				}
			}
			clipper.clipEndWithSlot(slot);
		}
		clipper.clipEnd();
	}
	/** Returns the {@link SkeletonClipping} used by this renderer for use with e.g. {@link Skeleton.getBounds} **/
	getSkeletonClipping() {
		return this.clipper;
	}
};
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/SceneRenderer.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var quad = [
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0
];
var QUAD_TRIANGLES = [
	0,
	1,
	2,
	2,
	3,
	0
];
var WHITE = new Color$2(1, 1, 1, 1);
var SceneRenderer = class {
	context;
	canvas;
	camera;
	batcher;
	twoColorTint = false;
	batcherShader;
	shapes;
	shapesShader;
	activeRenderer = null;
	maxCanvasWidth = 0;
	maxCanvasHeight = 0;
	skeletonRenderer;
	skeletonDebugRenderer;
	constructor(canvas, context, twoColorTint = true) {
		this.canvas = canvas;
		this.context = context instanceof ManagedWebGLRenderingContext ? context : new ManagedWebGLRenderingContext(context);
		this.twoColorTint = twoColorTint;
		this.camera = new OrthoCamera(canvas.width, canvas.height);
		this.batcherShader = twoColorTint ? Shader.newTwoColoredTextured(this.context) : Shader.newColoredTextured(this.context);
		this.batcher = new PolygonBatcher(this.context, twoColorTint);
		this.shapesShader = Shader.newColored(this.context);
		this.shapes = new ShapeRenderer(this.context);
		this.skeletonRenderer = new SkeletonRenderer(this.context, twoColorTint);
		this.skeletonDebugRenderer = new SkeletonDebugRenderer(this.context);
	}
	dispose() {
		this.batcher.dispose();
		this.batcherShader.dispose();
		this.shapes.dispose();
		this.shapesShader.dispose();
		this.skeletonDebugRenderer.dispose();
	}
	begin() {
		this.camera.update();
		this.enableRenderer(this.batcher);
	}
	drawSkeleton(skeleton, premultipliedAlpha = false, slotRangeStart = -1, slotRangeEnd = -1, transform = null) {
		this.enableRenderer(this.batcher);
		this.skeletonRenderer.premultipliedAlpha = premultipliedAlpha;
		this.skeletonRenderer.draw(this.batcher, skeleton, slotRangeStart, slotRangeEnd, transform);
	}
	drawSkeletonDebug(skeleton, premultipliedAlpha = false, ignoredBones) {
		this.enableRenderer(this.shapes);
		this.skeletonDebugRenderer.premultipliedAlpha = premultipliedAlpha;
		this.skeletonDebugRenderer.draw(this.shapes, skeleton, ignoredBones);
	}
	drawTexture(texture, x, y, width, height, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE;
		var i = 0;
		quad[i++] = x;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 0;
		quad[i++] = 1;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 1;
		quad[i++] = 1;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 1;
		quad[i++] = 0;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 0;
		quad[i++] = 0;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i] = 0;
		}
		this.batcher.draw(texture, quad, QUAD_TRIANGLES);
	}
	drawTextureUV(texture, x, y, width, height, u, v, u2, v2, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE;
		var i = 0;
		quad[i++] = x;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = u;
		quad[i++] = v;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = u2;
		quad[i++] = v;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = u2;
		quad[i++] = v2;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = u;
		quad[i++] = v2;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i] = 0;
		}
		this.batcher.draw(texture, quad, QUAD_TRIANGLES);
	}
	drawTextureRotated(texture, x, y, width, height, pivotX, pivotY, angle, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE;
		let worldOriginX = x + pivotX;
		let worldOriginY = y + pivotY;
		let fx = -pivotX;
		let fy = -pivotY;
		let fx2 = width - pivotX;
		let fy2 = height - pivotY;
		let p1x = fx;
		let p1y = fy;
		let p2x = fx;
		let p2y = fy2;
		let p3x = fx2;
		let p3y = fy2;
		let p4x = fx2;
		let p4y = fy;
		let x1 = 0;
		let y1 = 0;
		let x2 = 0;
		let y2 = 0;
		let x3 = 0;
		let y3 = 0;
		let x4 = 0;
		let y4 = 0;
		if (angle != 0) {
			let cos = MathUtils$2.cosDeg(angle);
			let sin = MathUtils$2.sinDeg(angle);
			x1 = cos * p1x - sin * p1y;
			y1 = sin * p1x + cos * p1y;
			x4 = cos * p2x - sin * p2y;
			y4 = sin * p2x + cos * p2y;
			x3 = cos * p3x - sin * p3y;
			y3 = sin * p3x + cos * p3y;
			x2 = x3 + (x1 - x4);
			y2 = y3 + (y1 - y4);
		} else {
			x1 = p1x;
			y1 = p1y;
			x4 = p2x;
			y4 = p2y;
			x3 = p3x;
			y3 = p3y;
			x2 = p4x;
			y2 = p4y;
		}
		x1 += worldOriginX;
		y1 += worldOriginY;
		x2 += worldOriginX;
		y2 += worldOriginY;
		x3 += worldOriginX;
		y3 += worldOriginY;
		x4 += worldOriginX;
		y4 += worldOriginY;
		var i = 0;
		quad[i++] = x1;
		quad[i++] = y1;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 0;
		quad[i++] = 1;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x2;
		quad[i++] = y2;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 1;
		quad[i++] = 1;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x3;
		quad[i++] = y3;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 1;
		quad[i++] = 0;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x4;
		quad[i++] = y4;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = 0;
		quad[i++] = 0;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i] = 0;
		}
		this.batcher.draw(texture, quad, QUAD_TRIANGLES);
	}
	drawRegion(region, x, y, width, height, color) {
		this.enableRenderer(this.batcher);
		if (!color) color = WHITE;
		var i = 0;
		quad[i++] = x;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = region.u;
		quad[i++] = region.v2;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = region.u2;
		quad[i++] = region.v2;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x + width;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = region.u2;
		quad[i++] = region.v;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
		}
		quad[i++] = x;
		quad[i++] = y + height;
		quad[i++] = color.r;
		quad[i++] = color.g;
		quad[i++] = color.b;
		quad[i++] = color.a;
		quad[i++] = region.u;
		quad[i++] = region.v;
		if (this.twoColorTint) {
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i++] = 0;
			quad[i] = 0;
		}
		this.batcher.draw(region.page.texture, quad, QUAD_TRIANGLES);
	}
	line(x, y, x2, y2, color, color2) {
		this.enableRenderer(this.shapes);
		this.shapes.line(x, y, x2, y2, color);
	}
	triangle(filled, x, y, x2, y2, x3, y3, color, color2, color3) {
		this.enableRenderer(this.shapes);
		this.shapes.triangle(filled, x, y, x2, y2, x3, y3, color, color2, color3);
	}
	quad(filled, x, y, x2, y2, x3, y3, x4, y4, color, color2, color3, color4) {
		this.enableRenderer(this.shapes);
		this.shapes.quad(filled, x, y, x2, y2, x3, y3, x4, y4, color, color2, color3, color4);
	}
	rect(filled, x, y, width, height, color) {
		this.enableRenderer(this.shapes);
		this.shapes.rect(filled, x, y, width, height, color);
	}
	rectLine(filled, x1, y1, x2, y2, width, color) {
		this.enableRenderer(this.shapes);
		this.shapes.rectLine(filled, x1, y1, x2, y2, width, color);
	}
	polygon(polygonVertices, offset, count, color) {
		this.enableRenderer(this.shapes);
		this.shapes.polygon(polygonVertices, offset, count, color);
	}
	circle(filled, x, y, radius, color, segments = 0) {
		this.enableRenderer(this.shapes);
		this.shapes.circle(filled, x, y, radius, color, segments);
	}
	curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color) {
		this.enableRenderer(this.shapes);
		this.shapes.curve(x1, y1, cx1, cy1, cx2, cy2, x2, y2, segments, color);
	}
	end() {
		if (this.activeRenderer === this.batcher) this.batcher.end();
		else if (this.activeRenderer === this.shapes) this.shapes.end();
		this.activeRenderer = null;
	}
	resize(resizeMode) {
		let canvas = this.canvas;
		var dpr = this.getSafeDevicePixelRatio(canvas.clientWidth, canvas.clientHeight);
		var w = Math.round(canvas.clientWidth * dpr);
		var h = Math.round(canvas.clientHeight * dpr);
		if (canvas.width != w || canvas.height != h) {
			canvas.width = w;
			canvas.height = h;
		}
		this.context.gl.viewport(0, 0, canvas.width, canvas.height);
		if (resizeMode === ResizeMode.Expand) this.camera.setViewport(w, h);
		else if (resizeMode === ResizeMode.Fit) {
			let sourceWidth = canvas.width, sourceHeight = canvas.height;
			let targetWidth = this.camera.viewportWidth, targetHeight = this.camera.viewportHeight;
			let scale = targetHeight / targetWidth < sourceHeight / sourceWidth ? targetWidth / sourceWidth : targetHeight / sourceHeight;
			this.camera.setViewport(sourceWidth * scale, sourceHeight * scale);
		}
		this.camera.update();
	}
	getSafeDevicePixelRatio(cssWidth, cssHeight) {
		const dpr = window.devicePixelRatio || 1;
		if (cssWidth <= 0 || cssHeight <= 0) return dpr;
		if (this.maxCanvasWidth === 0 || this.maxCanvasHeight === 0) {
			const gl = this.context.gl;
			const maxRenderbufferSize = gl.getParameter(gl.MAX_RENDERBUFFER_SIZE);
			const maxViewportDims = gl.getParameter(gl.MAX_VIEWPORT_DIMS);
			this.maxCanvasWidth = Math.min(maxRenderbufferSize, maxViewportDims[0]);
			this.maxCanvasHeight = Math.min(maxRenderbufferSize, maxViewportDims[1]);
		}
		return Math.min(dpr, this.maxCanvasWidth / cssWidth, this.maxCanvasHeight / cssHeight);
	}
	enableRenderer(renderer) {
		if (this.activeRenderer === renderer) return;
		this.end();
		if (renderer instanceof PolygonBatcher) {
			this.batcherShader.bind();
			this.batcherShader.setUniform4x4f(Shader.MVP_MATRIX, this.camera.projectionView.values);
			this.batcherShader.setUniformi("u_texture", 0);
			this.batcher.begin(this.batcherShader);
			this.activeRenderer = this.batcher;
		} else if (renderer instanceof ShapeRenderer) {
			this.shapesShader.bind();
			this.shapesShader.setUniform4x4f(Shader.MVP_MATRIX, this.camera.projectionView.values);
			this.shapes.begin(this.shapesShader);
			this.activeRenderer = this.shapes;
		} else this.activeRenderer = this.skeletonDebugRenderer;
	}
};
var ResizeMode;
(function(ResizeMode) {
	ResizeMode[ResizeMode["Stretch"] = 0] = "Stretch";
	ResizeMode[ResizeMode["Expand"] = 1] = "Expand";
	ResizeMode[ResizeMode["Fit"] = 2] = "Fit";
})(ResizeMode || (ResizeMode = {}));
//#endregion
//#region node_modules/spine-player-42/node_modules/@esotericsoftware/spine-webgl/dist/LoadingScreen.js
/******************************************************************************
* Spine Runtimes License Agreement
* Last updated April 5, 2025. Replaces all prior versions.
*
* Copyright (c) 2013-2025, Esoteric Software LLC
*
* Integration of the Spine Runtimes into software or otherwise creating
* derivative works of the Spine Runtimes is permitted under the terms and
* conditions of Section 2 of the Spine Editor License Agreement:
* http://esotericsoftware.com/spine-editor-license
*
* Otherwise, it is permitted to integrate the Spine Runtimes into software
* or otherwise create derivative works of the Spine Runtimes (collectively,
* "Products"), provided that each user of the Products must obtain their own
* Spine Editor license and redistribution of the Products in any form must
* include this license and copyright notice.
*
* THE SPINE RUNTIMES ARE PROVIDED BY ESOTERIC SOFTWARE LLC "AS IS" AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL ESOTERIC SOFTWARE LLC BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES,
* BUSINESS INTERRUPTION, OR LOSS OF USE, DATA, OR PROFITS) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
* THE SPINE RUNTIMES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
var spinnerImage;
var logoImage;
var loaded = 0;
var FADE_IN = 1;
var FADE_OUT = 1;
var logoWidth = 165;
var logoHeight = 108;
var spinnerSize = 163;
var LoadingScreen = class {
	renderer;
	logo = null;
	spinner = null;
	angle = 0;
	fadeOut = 0;
	fadeIn = 0;
	timeKeeper = new TimeKeeper$2();
	backgroundColor = new Color$2(.135, .135, .135, 1);
	tempColor = new Color$2();
	constructor(renderer) {
		this.renderer = renderer;
		this.timeKeeper.maxDelta = 9;
		if (!logoImage) {
			let isSafari = navigator.userAgent.indexOf("Safari") > -1;
			let onload = () => loaded++;
			logoImage = new Image();
			logoImage.src = SPINE_LOGO_DATA;
			if (!isSafari) logoImage.crossOrigin = "anonymous";
			logoImage.onload = onload;
			spinnerImage = new Image();
			spinnerImage.src = SPINNER_DATA;
			if (!isSafari) spinnerImage.crossOrigin = "anonymous";
			spinnerImage.onload = onload;
		}
	}
	dispose() {
		this.logo?.dispose();
		this.spinner?.dispose();
	}
	draw(complete = false) {
		if (loaded < 2 || complete && this.fadeOut > FADE_OUT) return;
		this.timeKeeper.update();
		let a = Math.abs(Math.sin(this.timeKeeper.totalTime + .25));
		this.angle -= this.timeKeeper.delta * 200 * (1 + 1.5 * Math.pow(a, 5));
		let tempColor = this.tempColor;
		let renderer = this.renderer;
		let canvas = renderer.canvas;
		let gl = renderer.context.gl;
		renderer.resize(ResizeMode.Expand);
		renderer.camera.position.set(canvas.width / 2, canvas.height / 2, 0);
		renderer.batcher.setBlendMode(BlendMode$2.Normal, true);
		if (complete) {
			this.fadeOut += this.timeKeeper.delta * (this.timeKeeper.totalTime < 1 ? 2 : 1);
			if (this.fadeOut > FADE_OUT) return;
			tempColor.setFromColor(this.backgroundColor);
			a = 1 - this.fadeOut / FADE_OUT;
			a = 1 - (a - 1) * (a - 1);
			tempColor.a *= a;
			if (tempColor.a > 0) {
				renderer.camera.zoom = 1;
				renderer.begin();
				renderer.quad(true, 0, 0, canvas.width, 0, canvas.width, canvas.height, 0, canvas.height, tempColor, tempColor, tempColor, tempColor);
				renderer.end();
			}
		} else {
			this.fadeIn += this.timeKeeper.delta;
			if (this.backgroundColor.a > 0) {
				gl.clearColor(this.backgroundColor.r, this.backgroundColor.g, this.backgroundColor.b, this.backgroundColor.a);
				gl.clear(gl.COLOR_BUFFER_BIT);
			}
			a = 1;
		}
		a *= Math.min(this.fadeIn / FADE_IN, 1);
		tempColor.set(a, a, a, a);
		if (!this.logo) {
			this.logo = new GLTexture(renderer.context, logoImage);
			this.spinner = new GLTexture(renderer.context, spinnerImage);
		}
		renderer.camera.zoom = Math.max(1, spinnerSize / canvas.height);
		renderer.begin();
		renderer.drawTexture(this.logo, (canvas.width - logoWidth) / 2, (canvas.height - logoHeight) / 2, logoWidth, logoHeight, tempColor);
		if (this.spinner) renderer.drawTextureRotated(this.spinner, (canvas.width - spinnerSize) / 2, (canvas.height - spinnerSize) / 2, spinnerSize, spinnerSize, spinnerSize / 2, spinnerSize / 2, this.angle, tempColor);
		renderer.end();
	}
	drawInCoordinates(x, y) {
		if (loaded < 2) return;
		this.timeKeeper.update();
		let renderer = this.renderer;
		renderer.batcher.setBlendMode(BlendMode$2.Normal, true);
		if (!this.logo) {
			this.logo = new GLTexture(renderer.context, logoImage);
			this.spinner = new GLTexture(renderer.context, spinnerImage);
		}
		const shiftedX = x - logoWidth / 2;
		const shiftedY = y - logoHeight / 2;
		renderer.drawTexture(this.logo, shiftedX, shiftedY, logoWidth, logoHeight);
		this.angle -= this.timeKeeper.delta * 500;
		if (this.spinner) renderer.drawTextureRotated(this.spinner, shiftedX, shiftedY - 25, spinnerSize, spinnerSize, spinnerSize / 2, spinnerSize / 2, this.angle);
	}
};
var SPINNER_DATA = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKMAAACjCAYAAADmbK6AAAALKElEQVR42u2de2iW5R/GPzuqcwfnnKfNmafl5tTNHWzqNi3DEMQykcAoJSsySkspjSIk0iD/07Kf4R+FnVBDUTshZGpWUEJaaiWFgZlUFmXmIe3HNXthyebeZ77P9H13ffBG8Y8H7ut7vff93N/7fu4vGGPiFZiez/Qtw9lytJajfzfw9z/j+efPOv7cV8W+lUNY2a8T/ayTCRsWFLJA5rtUO1LLkV5p9LJeJizQiHeqnlOtmVFtdTGrrZkJCxYXsTgaI6r9MY4/UpNItW4mFDaXsTlaM6qVZlBq3UwofFrJp0HMWJ9DvXUzobCznJ1BzFjWlTLrZkJh/TDWBzFjTgo51s2EgnKI0Rrx+FiOWzNzVaym91Syx5qZsGBWb2ZFa0ZN6dbMhAWTcpkUrRmXD2K5NTNhgVbH0Zpxbl/mWjMTFvRIo0e0ZpzcncnWzISKtvmiMWNRJ4qslwmVXRXsas2Ix8ZwzFqZsGFREYtaM+Oaa1ljrUzYkJ9G/ok6TlzKjJWZVFor0y7c1Zu7WjLiqiGsskamXdHopyT4vALmzS9k/t19uHtKHlOSIMn6xAtARjIZ1sFcUSZ0Y4La+G6M18hS2IlCn4a+WoC0JNL0d/dUupdnUj40g6EJ2VEdMnhrOG/p5f/jUXz8SgmvaGU6KpNRNsLVQV0OdXf24s63h/P2gWoOrBjMCr2GJFQnnxnIM3q5P1PPmaYv+4ev4/C6UtbpV2gzXCkgL5W8Bwt48OIc6ul6Tp+s4+SyASxLiI4+PYCn1bHzDZxvaQW6vZzto7MYnQIpNkf7kp5EuozYUroqEjcNKHHd0Tl9mBPN1pk+hFeieGBnBtog7UXjsj9pWg+m6duecw2cay1OC/uxMC47KmP9OIYfoz1YoC20J/rzRG4quTZK2EAyJGs20qwUbYw0aNRmUxtvfUW/uEtNzc1NB1/X8LVyd15hh82F43AvD+VlXcsSJEZa1CQ3ejleAO7oxR3RDP0XN91X4+NXYb8nkv7UNTwV7e0YTdu7I3g33t7tuaEbNwSZpps2fSyvs4M2Tjhot+jb0Xzbltj8r5j/xVt/6Z1Ob93U1ZYO691EhhzchcHeXosVjcNZysyezLw4xRZt05R+fTeuj8vOj+zKyG0j2aZcVVs6v+QalnjrMFZASQYl2nBoSyz06e3j/Xk8rgWYmMvEICu2pm1HOTuc7okV8FgRj0XukwzanhvCc/F+72TjoQjdObN1OFuDLmh0xP+WHtxiI10ukJlCprb4guiv1fP+avZrS1C7NAkliHZjDtZwMMgqbukAltpMlwuMy2FcEBPqvfLLar5Uqi0hBdEwryy+Mv5n6zkbjTBa+dlMlwvUZFETZKGiFM7tvbhdJ3gSVRO0wzIjnxmvl/J6a6JsGMYGrahtpssFeqbR841S3mhN80OjOaSDEdqd6SjaMKgzgzRK7q1ib3PT9sYyNo7JZoyNFNvRcVMZmy7WOvIuryv/Zvdmdt90+nY0bRp3AvROohFwdwW7dTG7RFlbwlqdrbOBYg005NAQmZU0HWt1rXMBH1Xw0dQ8pmqzoaPmdhun7bHZjNVe9qP9eFQfO1VkUmHjhAVUZ1GtnKFSbjrkrPfy4i4UW5t/6ZxM54J0CqxFe81KpGsQyE4h23oYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjLna+bdOy+IiFquIpGq16Pb79cNYv3IIK/X/ugx+Ui6TVKvYVU9Nc8gX8od8Ir/IN/KPfCQ/yVfyl/6/pfJvLChkQdD6wyqntquCXYuKWJSfRr6D0dEAxV3xlw/khyD+kd/ku/88cHo+09tS3LBpO1HHCVUqcIA6CqB4K+6X6x35L/JM2loXurlWmUmlA5XogOIcK8/If5HncrSWo7F6cKIWPjT/RXGOlWfkv8hzaWsN4uaaysE6WIkOKM6x8oz8F3kusXqo2vxC5jtYiQ4ozrH0TeS5qIZcrB7qkrwdA8U5Vp6R/yLPZV8V+2L14Cl5THGwEh1QnGPlGfkv8lyUlIzFQ1cNYVVHrcjZ0VCcFe9Y+Eb+izy3ceclUl43aFN52DXXssYpnY6a4qFS8ZcP2uIf+e7inRh6pdFrdTGrm8uiHx/L8T2V7NGWzvJBLJ/bl7mTuzO5qBNFDoiJID/IF/KHfCK/yDfyT3O7d/KbfNfS80hNIrU0g9L6HOq1x5iTQo6FNpeLfCQ/yVfyl3xmXYwxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHNk9z4JwJ0SqKTdQkbyEwhU393T6V7zzR6pieR3tE1ITeVXImhe6BXDGZFdRbVeank2TBhcaEMr0rwbixj49IBLL2/L/ffmMuNHfqO9tFZjJYBd1ewO3Lx+IcVfKhqna5nHZYR6XFPH+5R3eeI5t9fx/fvjeC9Jdew5OKZKqFR/RDVKL6vL/f9PJafmyvHsL+a/ff24V6NmjZQbGchVbY6UM2BluqHv1rCqzVZ1KQlkZboepCdQvacPsz5bjTfXao+yMEaDt7Wk9tSIMVGig3TejCtJSM2bSpkPjWPqd1S6Zao+lORSYWmgkOjORRNwZqd5ezMSiHLRooNr5XwWjS6/1XHX9vL2T67N7M1iyXa9JCrYjVrS1gbpJyw6hBfsmiNCYT0P9/A+Wj1/6qGr5YNYFlJBiWJogEzezLz/ZG8/9s4fgtSyuvNYbyp1IONFBtu7sHNv4/j9yAxUHWrdaWsG9+N8XHd+YxkMpSy+aySz841cC5oXbmHCnnI74yxAgZ3YbDeB4PEQCOpBpFNZWwa2ZWRcdnxLsl00crtRB0n2lLg8JNRfDKoM4NsolgBSmw/UMADba1+qpmqfyf6x1u/0a/og3I+aEunP6/i86osqmygcGarF4p54dex/Bo0LqfqOfVwIQ/HW5/RSkwV1oN2WLlHTc82TljAwM4M1O5LWwYKZTjibYXNS0N5KcjKTe10PadfLObFuJwK4ozp+UzXDBTUjL+M5ZcBnRkQV53dMIwNQTu6bSTbVEzbi5awuVByd2E/FgaN0Tc1fKOzBHHV2aAdVSdv6s5NNkp7cSH/++xAng2yyHx+CM/H21YhfdPp+0U1X0TbSZnXx8faG9Aop0MS0cToh1p+iLcpOkLj9t/JOk5eqoPHxnDsyf486an5yqCDK7XZ1O4oZ4dWyy3FSXHUAYq47uyYbMZoGmhpG3DlEFb6uNiVBhpyaHhnBO8oJmfqOROJjzIiP43hJ8UxITqqX56S2Hur2KsOnq3nrE6PPNKPRwrSKbAZrjTQNZmuE7oxYXMZmxWbw9dxWFu4W4ezVedOE6qzI7oyYkY+M7TPeWsPbk2UX1qioSN+E3OZqOR2cReKE+qQRFN0Pi7y73g/UawU1KzezJpXwLz5hczX1ueUPKYkNb6GJQZ+j7/aAfRZREsv+quGsMoamXZBW2Gt5eU0alorEzYsKmJRa/m4NdeyxlqZsCGa84DKnVorEzboC7podis69DfIJmwufHMc7famvvmxZiYsKOtKWbRm1OcW1syEBboSJFozLh/EcmtmwgIluaM14/phrLdmJixYXMTiaM24p5I91syEBTphFOR7Y2tmwgJNvUFOr+tov3UzoaAv44KYUatv62ZCoemdhtG0+hzqrZsJBR08DWLG0gxKrZu50qvpxos3U5NItW4mFPp1ot+lPlpq2lYXs9qamVBZUMiC1ox4pJYjvlfStAu6GmTLcLboMtPIV4/6im5fFfuUi9QIap2MiWP+D96R1vPmsD/fAAAAAElFTkSuQmCC";
var SPINE_LOGO_DATA = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKUAAABsCAYAAAALzHKmAAAQ7klEQVR42u3da4xdVRUA4D0zd2Y6nZY59DVtZ1puS9+lzC0YAi2UQ8AAQczFpPgA9VIeIQbirRqJ0cBUBVGjDr/QCKSNRSMmpuODxAdxqhgwxkhFjf6Sxh/+UUNVNGJCzR7uTvas7LXX2q9zzp3em6y0gTN3Zu75utZe5+yztxC9V+/Ve5X9En1Vjd7J6SFbLNF7naPw+l2jh7YHMBWssqMHtlsRdim4qsLtIawaPiHEQOLoNrA9iIkQDnRrVA1qD2LZ8ISoxYqKo13sQAtBWBayQWZUAXGRQM9JjCngDVY0UqJNDbQrMcaGmArdUKpIjbYiQLsCZCyIMQBy8QwnilR4Q5AuCpxFYvRFmBLbEiwKwpsSaWycVQGZBKMrwBjA9BhxDe57u2L2hOoKNCbOrgAZitEVYUxoKSMErQvSxYIzCkguRg5EF4AUhqUlhy/YUKSxcRaKsioYOQhD4I0yYxkR3PcJBcuFysmgsXAWBTMJyBCMIQh9kGGxXIXvexCQXbHGAMrBWTbM2CCpMSMLIxehC77lSJwXGth7M0FzoVJIXXDWQnGmhOkL0ic7YhhtWdGGkAuPAjUWGoF4faCmwBkbZmyUqUCyMqMLRA4+E6IsdTjidUHKBYrh9CnpRcH0ypKxsyOGEYNIIeTCOz91OIJ1QYoB5eAMyZo+MFNnyVTZ0YiRC9EGEMOyAgshxErHsL2XK1gOUgwohtM1a5YNM7Rsu4K0ZkcbRm4mpPBRwFZ5hg9eCqkrUB+csWGGogzNkqEgrdnRhpGLkINudaLgwvVB6oqzCjCTZElb2Y4B0gUjBtEG0ARnDRLjjoG9DwcshtQGlIPTljVjwUySLWNkyRCQVHa0ZUUTRAwgF91a33BEy0VKAcVwwqwZC2bqbOlUurllOxQkJzNyINoAYqjWhYYjWg5SCiiG05Q1U8FMjTIoS8YE6YORi1BHtJ4KIcQEEtTXUWAxpK44YVlPBdO1jCdFWTZIE8bVGEYMIRPcZGBw4HKQcoBiOE1ZMzbMgVQwU6JMAdKEEcuIJogUvg1YCCE2gsCO42DlIIVAKZwpYJaSLVNnSU6XjYHUmxhTmXaFaMO3EYkLqMC+FsLlIoVAKZzMrEnBhJeLfLNlKMrYWRIDCbOkFSSVHbHM6AKRC6/ODUewNqQ+OLlZkxpjUmV8MBbMUJSxyzY3Q1IgTRgxiBRCHdem0KDAUkBh9sRwwjEnAXMMgTnKhFlUtiwkS5rGka4g9SaGgxFmRC7AzTCEEBcyA36dDSsXqAtOLkysjGMwY5XxVChjZ0kuSCo7YlkRQsQQYtDEFsegsLoCxUp7Kpgps2UslFGzJGccSYHUmxhOZqwzEZqAbfUMCisHKIZzgsCpl3MTzMwTpi1bYp2477gyFKUxS7qWbdjY2EBS2dGE0QQRA7gNCyHEdhjE8RhUDlBT9tzgmjWZMFNlSy+Urk1OzCyJlW0XkK4YOQh1cDtcgwBrQmoDWkdgboBZE8mYsJSHlnFbJ+5bwmOPJ7lZkirbC8aRsMvmgtTHjBhGE0QbwJ2egUE1ITVlUC5OmDVdYNrKuN70xM6WoShjlW4464dbtiFIWK6x7GjESEHUUe0iYncnbMdQSE0Z1ITTNOb0hRmjjLtmS9dmJ2rp1jtuKktyyrb6YLEMCUHq2dGG0QQRQ7f72kzc+cJecerne8Wvv7JNPHPvenEkz8Sh3UtFc92QyGt9Yko/HgOLAIUZlItTz5ouMF3KuE+2jFLCQ1D6lm6fLMkBacuOJowYRBUXyfjuHjF3NhdnsfjvAfH6E9vFt9XxKgikEKgJZyyYalzOLeMu2bLbULI6bh+QGwmQ+rgRlumdGEQAao+K56bEL2woVUwOiev0r8OAUjiJrMmFCbvykGxZRAmPitK1dHM7bohyMsuyi/I8f0+e57fJYIKEZXpXo9E4mOf5XTKyLLvCBLETF8uY2SKepkC+dpX4T02Ivepr4HvZcOZ5fmee54fyPL+DmTUhzAs6n4n8bN5dr9f3YdkSg8nsxG0lPBVKVpNjG0/aGhzfLDmRZdnumZmZp8+c+cdZPV555fSr7Xb7s0jJ3i5Pcue4MxKkPPkvvXTqz/B92u32l0wYOzG1fkhcd/py8Rcbyq/vFM/KY1WA95h/3zzP71bfU6JsNpsfgj+P/FlbrdaDGExYyuXvLz8H+DudODH700ajcSM3W6Yu4alQ1spCOTd38jcKocTZbh9+9NixY99XJ8AEUkcpo9W64yH197m5k7+bnZ19QT+J09NHntQhwji/Jg58qi6++ofLxJ8gSFneVw2Ka4QQDfh1Ok4dZavVmtZ/nrm5k7/Vf55O1tRhboUw5+ZOvqyOl5+R/FyOHj32PYVU/tloNG5IXcKrhJIzngwp3fNjomazea/64BuNxts646f50lWv169utw9/DmtqdJQyZFaSJVuV6nq9fqMEof5/vV6/CYBqgJDlee+yAbF/+4i4ZWqZeNfaIfHWzn+Hx0KcEuU9+s8jv3ej0bhVlXOZydX/k0iRMeb8P0D5e6tj8zy/Xb9UJIc56h/yqVOnXul8lmuZ2bJslKmbHG7XrbpCmCXFRLvdfqQD6jTS3Jiy5I4OykM6ADV+1Eu1DmV6evopBORexzDi1L+X/HnGxsb2w3Hm9PSRJ9QxWPOTZdmlKht2hi+w6dkox5bqffI8fye3hDteGqKaHVsHXihKl0tB+h0cY+lute54AGRKDCW89LNTRynHb7ChUWVVjetOnJh9EYBUyPZeNCoOtsbFQwdXi4/esELcd+tq8cCHJ8UXp+viy9efLz7AgamjlKXc1AA1m83DoIRDlFubzeb96hhZLVTlgJ24gttutx+ONa50bHZKRenaeTs1OfpAfnr6yOOdE7EZdNwmlKocntXLNkA5JTGq47Ds+Lf94lWsyfnXleLfnIwJUN4DOnNYwuUxh2A3Ln9XULrfK8t3J27Tu3BVwiOjXJqoAy8UZej1yclGo3GTLN+gu3w+z/P3YaWbQqk3Ne12e4ZC+c8rxWsYytcPiP9RpZxCqWDKnxOiBNlyAUpOnGsoh4tA2Rm8X9xqtT6md5wyZmYe+0YRKL+1S/wYQ3n8zctBl5SBUv5djivfjMOPduIzcizeiYfr9foVvUwZG+XCuzibZKnSceZ5/v4QlKp8y7ElhnJlTeTP7BI/kllRYfzrfvHqFy4UX1vaL/aVlSmROzwbwdS29T2UcEwZF+V8ozM2lu1VY812u/15akypGh3TmFJesJbHHD167IdUxz3YJy5bNySuX1mbvy55CbMLtzU6tjGlsdFptVqfUMc0Go23F4wy1l2dSnbfvpMwVPe9WWVLDsrOJaF9MFu2Wq1PqmNkGce67xiXhTjdNwdlvV6/BgxfbPfBfVCetxi6b9/rlCup65QzM48dl2OjLMv26CibzeZ96sTIzEFdpwQXz9U1yrtVlpR/Zll2Fec65Y6l4pbbx8XHH9kknvzJlPjlHy8Tp29eKT5ou0aJoIT3w3dBlLDzVpfAJEZ1XOdaJZxnOSlvPMjPzxFljIvng914RwebsjYO7uhMyHu46sOfnf3Oz2TXDW6vvYxdFoIXz3Wc8J5zs9n8iOn2IrxTc2BM3Glqdp7dI553uaOjxrhwcob+MyuUpjs6WZZdon8OcigjPx8V+u+GTWFTSWEx3WYcdJ225jNDSE4q0GHCzlueHOyujn6bUWYgeb9ZZUaQPe+GzQ+Gc8+oOGhC+c1d4gfI16n3XDAhQ7+9qE9l01E2Go132GYKyXE1NiFDTcpoNpv3LOYJGWXNErJNW9sEp63p2RKiVPMn1bS1DgxsyhoGdGpmizj+xtXiDYnx7/vFmce3iWdW1cTVGEY4hQ2ZW0nNq8Qm/M6XbXm3S100lwGedFybuvNOibLI+ZS2ceU4eAxiEuvCkfmU8ycToDxETe6FgCBQHeqyAbFvfEhcO7BwDuXFCEbTZF840XeHK0jYcbs2OIGle0mVJ/mmnClEPQqxyTY5I8/zFhif7fSZee4bnrPOU4AssnRXHaVTCTd14dRDY3UbTIiSeFhsN/aMjgnqthFx880rxX3yATL5p3y4LPXzOaBkUyBjZMlYpbtQlIOBD475ZEusjMNSvkXe6VEoJVDkeZ2dzIfIFsRzU+JF2OyM9M9fTC/6SUYOyFQPjQ2nWiUjxnPfw5EeHqMWIqAeIFsAU847lJM2JM6xsewt1OIDLs99P7ZFHNdB/upS8XtPiD7PfLuCXJNolYyyFiNI/Zit65ItrOVafFbHcFohY7hPTN21Tjz4uc3iqfsnxKdX1MTl1OoYRFaMsToGB6Trw2JFP/OdZC2hJZ7ZkrMoAbbSGmelDJ91hFKuJeS7jlBMkJnrAqqJlgMUZS/dArPlGHNdSg5M3xXXtvquuEatvIYtDRhpxbUJuIgqsU5lGWtUploK0KuEU9mSW8YpmFQ556xNuYW7NiW13B+FkMiKHIy+C6eGgBxJvMR0oSv5hi6+z4HJyZoU0M2RVvDlrOQbcxVfX5AhZbuqy0v7ZstYMLHlAVlLTF9ALLbvu9Y5Zylpn/XOsd0ibIvxr2KCLHpp6SCUIdnSZSF+WzfOhem6GD+1KwR3Z4jNjrtDpNoZwmWd8yrupZN6Hx3fbMmFSe0Swdq2ZIPjxk1112Duo8OBGLrBkw/IoncdK2XHsdC9dHz204m50xh3tzFq1zFqtzHXrfCw7OgDsqyNnZLszVijsmXgrmNcmGtS78lIoMX2aJz03fKO2sDJddPQSCDPiQ1DfWBycY6XtXstc2PQKuxgG2McmXTPb9/9vmuJYXKyJrWjbeg+3xPM4O73nWqvbyw7xgZZSJbEUBa157cNJjdr2vb+5iA1YV3HxYscj30PDCEHIgcjtfm8K8hSsmRotkwFk5s1TTghUAopB6xrjHMBBkI0YYTZ0dZlxwLpkiWDULpmy5gwqayZgZNkA7oKQQCxctByYg0XIIEQQuRitGVHblMTA2ShKGPDpC6wu+DEgJqg2rDGDBtAF4Q6RAojp1xXGmSMbImVcR+YWNY04eQCtUG1ofUJ2/uvcETIgUhhdAE5GAlkKShjwHTNmhhODKgJqQ2sC14uOgyfD0IbRF+MlQaZAiZWyn2yJsTJATqGnHQO2Jhh+xlsACFCG0QbRtdyzQFZCZSxYPpmTS7Q5cjJHYNBYIkZpu99HoUQ/o4QIYSIZUZfjJ4ZMjZI32wZBDMU5yhy8pZTULl4XYP5fagMyEVoy4oupTpGduwnkloSlKEwY+AcQU4MhRTD6ovXBRwFzwWgCSEF0QVjJUGmgEllTS5OLlCIlIN1mS9mx/cZ5eLDALpCTI2RAhkTZQqYoTgpoCPECbaBHQ2ETL3PUl98ECAXYijG0OyYAmQoTG7W5ODkAF1CnVgm2JQx4okPA+gCMTbGskBGgRmaOblAh5GTORIrfKFx4VH4EIAxIXIxlg2SBbMvECY3e7oApbDaIgQu5/2HmeEKEINYiwSRi7EQkLFgumZOCuggctKGI4ULZN/vMeSLj0AYMytWEqMLzFg4fYDaoKaC6wvOFR4FkIPQFaILxrJAOsHsc/zlfYDWXE8qF22s8Pz5KHxcgEVALBtjJXBSSEOwFhk1Zgy4hitCT4hVw+gFs8/zwxqIBbUgyK7fcyA0PD9XX4iVxhiC0xdof6STWCsoBmKF7+cVCWFXQYyBMxRpf+STX1b0x45AhN0OMSrOGEirhrY/dfQAdjvS7oy+WCF6r1RIFxXWvlTRg1YVqFWBmxZbD99ig9pt0YPQw9rD1nstVri9V+/Ve3XrS/wfim4P5fIFxLoAAAAASUVORK5CYII=";
//#endregion
export { SkeletonDebugRenderer$2 as $, ShapeRenderer$1 as A, Shader$1 as B, GLTexture as C, SceneRenderer$1 as D, ResizeMode$1 as E, Mesh$1 as F, Vector3$1 as G, Touch$1 as H, Position2Attribute$1 as I, ManagedWebGLRenderingContext$1 as J, AssetManager$1 as K, TexCoordAttribute$1 as L, PolygonBatcher$1 as M, Color2Attribute$1 as N, SkeletonRenderer$1 as O, ColorAttribute$1 as P, SkeletonRenderer$2 as Q, VertexAttribute$1 as R, AssetManager as S, LoadingScreen$1 as T, OrthoCamera$1 as U, Input$1 as V, Matrix4$1 as W, ResizeMode$2 as X, LoadingScreen$2 as Y, SceneRenderer$2 as Z, Input as _, GLTexture$2 as _t, SkeletonDebugRenderer as a, Mesh$2 as at, Matrix4 as b, PolygonBatcher as c, VertexAttribute$2 as ct, Mesh as d, Input$2 as dt, ShapeRenderer$2 as et, Position2Attribute as f, Touch$2 as ft, Shader as g, AssetManager$2 as gt, VertexAttributeType as h, Vector3$2 as ht, SkeletonRenderer as i, ColorAttribute$2 as it, ShapeType$1 as j, SkeletonDebugRenderer$1 as k, Color2Attribute as l, VertexAttributeType$2 as lt, VertexAttribute as m, Matrix4$2 as mt, ResizeMode as n, PolygonBatcher$2 as nt, ShapeRenderer as o, Position2Attribute$2 as ot, TexCoordAttribute as p, OrthoCamera$2 as pt, GLTexture$1 as q, SceneRenderer as r, Color2Attribute$2 as rt, ShapeType as s, TexCoordAttribute$2 as st, LoadingScreen as t, ShapeType$2 as tt, ColorAttribute as u, Shader$2 as ut, Touch as v, ManagedWebGLRenderingContext$2 as vt, ManagedWebGLRenderingContext as w, Vector3 as x, OrthoCamera as y, WebGLBlendModeConverter as yt, VertexAttributeType$1 as z };
